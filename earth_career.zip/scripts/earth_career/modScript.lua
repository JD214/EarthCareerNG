-- Earth Career: load the extensions when the mod is enabled.
-- "manual" unload mode keeps them running across level changes.
for _, name in ipairs({ "earthCareer_earth", "earthCareer_main", "earthCareer_garage", "earthCareer_jobs", "earthCareer_map", "earthCareer_bank", "earthCareer_achievements", "earthCareer_discovery" }) do
  load(name)
  setExtensionUnloadMode(name, "manual")
end
