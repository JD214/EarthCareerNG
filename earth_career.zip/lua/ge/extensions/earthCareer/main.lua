-- ============================================================================
-- Earth Career  -  main (save, money, XP, home town, settings, UI bridge)
-- Freeroam-only career layer for BeamNG.Earth.
--   earth.lua   talks to BeamNG.Earth (lat/lon, place names, GPS)
--   jobs.lua    the Freight Market and the active job
--   garage.lua  cars, fuel, damage, insurance, dealership, rentals
-- The HUD app (ui/modules/apps/EarthCareer) only displays what this sends.
--
-- Console helpers (open console with ~):
--   earthCareer_main.debugAddMoney(5000)
--   earthCareer_main.debugAddXp(500)
--   earthCareer_main.resetCareer()
-- ============================================================================

local M = {}

-- The mod's version, shown in the panel. Bump this when it's time for 1.1.
local VERSION = "1.1.5"
M.VERSION = VERSION

local LEGACY_SAVE     = "settings/earthCareer/save.json"        -- before profiles (kept as a backup)
local PROFILE_DIR     = "settings/earthCareer/profiles/"
local INDEX_PATH      = "settings/earthCareer/profiles.json"
local MAX_PROFILES    = 12
local SAVE_VER        = 4
local UI_INTERVAL     = 0.5   -- seconds between HUD refreshes
local AUTOSAVE_EVERY  = 60    -- seconds

local RELOCATE_LOW    = 500   -- move your home base, below level 10
local RELOCATE_HIGH   = 1000  -- ... level 10 and up
local RELOCATE_LEVEL  = 10
local VISIT_LOW       = 150   -- teleport but keep your home base, below level 10
local VISIT_HIGH      = 300   -- ... level 10 and up
local TELEPORT_MI     = 1.5   -- jumped at least this far ...
local TELEPORT_MPH    = 400   -- ... faster than this = a teleport, not driving
local AWAY_MI         = 25    -- loaded/resumed this far from where you left off = teleported meanwhile

local save = nil
local current = nil          -- id of the loaded profile (nil = the profile picker is up)
local index = { profiles = {}, last = nil }
local uiTimer = 0
local autosaveTimer = 0
local clock = 0
local lastFix = nil          -- { lat, lon, t } last position check
local expectHomeUntil = -1   -- our own "back home" teleport is under way until then
local settleUntil = 0        -- after a map load / resume: wait for Earth to place you first
local needAwayCheck = true   -- compare with where you left off once Earth has placed you
local sawLoading = false     -- Earth was loading ground since the last fix (a teleport in progress)
local graceUntil = -1        -- the mod moved the car itself (repair, recovery, swaps): not a teleport
local RETURN_MIN_MI = 1.0    -- this far from your last career spot = offer/do the trip back
local RETURN_WAIT_S = 60     -- how long to wait for BeamNG.Earth to be ready for it
local returnTrip = nil       -- { lat, lon, giveUpAt, sent, arriveBy }: taking you back to your last save

local function defaultGarage()
  return { cars = {}, activeId = nil, nextId = 1, insurance = { claims = 0, cleanJobs = 0 }, damageMeter = 0 }
end

local function defaultSettings()
  return { vehicleLock = true, crashPopups = true, teleportLock = true, cheapInsurance = false, returnToSave = true, modVehicles = true, cargoDamage = true }
end

local function defaultSave()
  return {
    version      = SAVE_VER,
    money        = 500,
    xp           = 0,      -- xp toward next level
    level        = 1,
    totalJobs    = 0,
    totalKm      = 0,
    careerActive = false,  -- false until a home town is set, and while "exited"
    -- homeTown  = { name = "Marshall, MI", lat = 42.27, lon = -84.96, setAt = "2026-10-30" }
    jobs         = { active = nil, stats = {}, report = nil },
    garage       = defaultGarage(),
    settings     = defaultSettings(),
  }
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
local function msg(text, ttl)
  ui_message(text, ttl or 5, "earthCareer")
end

local function getVeh()
  if be and be.getPlayerVehicle then return be:getPlayerVehicle(0) end
  if getPlayerVehicle then return getPlayerVehicle(0) end
  return nil
end

local function xpForNextLevel(level)
  return math.floor(100 * (level ^ 1.5))
end

local function isRunning()
  return save ~= nil and save.careerActive and save.homeTown ~= nil
end

local function garage() return earthCareer_garage end
local function jobs() return earthCareer_jobs end
local function earth() return earthCareer_earth end

-- ---------------------------------------------------------------------------
-- Save / load
-- ---------------------------------------------------------------------------
local function profilePath(id) return PROFILE_DIR .. id .. ".json" end

local function writeIndex() jsonWriteFile(INDEX_PATH, index, true) end

local function entryFor(id)
  for i, e in ipairs(index.profiles) do if e.id == id then return e, i end end
  return nil
end

-- the card shown in the profile picker
local function summarize(e, sv)
  if not (e and sv) then return end
  e.level, e.money, e.jobs = sv.level, sv.money, sv.totalJobs or 0
  e.home = sv.homeTown and sv.homeTown.name or nil
  local n = 0
  for _ in pairs(sv.statesVisited or {}) do n = n + 1 end
  e.states = n
end

local function writeSave()
  if not (save and current) then return end
  jsonWriteFile(profilePath(current), save, true)
  local e = entryFor(current)
  if e then summarize(e, save); e.lastPlayed = os.date("%Y-%m-%d %H:%M"); writeIndex() end
end

-- fill in anything an older save is missing
local function normalize(data)
  if type(data) ~= "table" or data.version == nil then return defaultSave() end
  local sv = data
  for k, v in pairs(defaultSave()) do if sv[k] == nil then sv[k] = v end end
  if type(sv.garage) ~= "table" or sv.garage.cars == nil then
    sv.garage = defaultGarage()
    if sv.homeTown then sv.garage.needsStarter = true end
  end
  for k, v in pairs(defaultGarage()) do if sv.garage[k] == nil then sv.garage[k] = v end end
  for k, v in pairs(defaultSettings()) do if sv.settings[k] == nil then sv.settings[k] = v end end
  -- v3 and older: jobs were stored in game coordinates, which BeamNG.Earth shifts; drop them
  if sv.activeJob ~= nil then sv.activeJob = nil end
  sv.version = SAVE_VER
  return sv
end

local function cleanName(name, fallback)
  name = tostring(name or ""):gsub("[^%w%s%-_'%.,&]", ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then name = fallback or "Career" end
  return name:sub(1, 30)
end

local function newId()
  return "p" .. os.time() .. math.random(100, 999)
end

-- the profile list; the first run moves the old single save into a profile
local function loadIndex()
  local data = jsonReadFile(INDEX_PATH)
  if type(data) == "table" and type(data.profiles) == "table" then
    index = data
    index.profiles = index.profiles or {}
    return
  end
  index = { profiles = {}, last = nil }
  local legacy = jsonReadFile(LEGACY_SAVE)
  if type(legacy) == "table" and legacy.version ~= nil then
    local sv = normalize(legacy)
    local id = newId()
    local name = cleanName(sv.homeTown and (sv.homeTown.name:gsub(",.*$", "") .. " career") or "My career")
    jsonWriteFile(profilePath(id), sv, true)
    local e = { id = id, name = name, created = os.date("%Y-%m-%d"), lastPlayed = os.date("%Y-%m-%d %H:%M") }
    summarize(e, sv)
    index.profiles[1] = e
    index.last = id
    log("I", "earthCareer", "Moved the old save into profile '" .. name .. "'")
  end
  writeIndex()
end

-- home towns from before lat/lon: look the name up in the towns list
local function migrateHome()
  local h = save and save.homeTown
  if not h or h.lat then return end
  local t = earth() and earth().findTown(h.name)
  if t then
    h.lat, h.lon = t.lat, t.lon
    h.pos = nil
    log("I", "earthCareer", "Home town pinned to " .. t.name .. ", " .. t.st)
    writeSave()
  else
    h.needsPin = true
  end
end

-- ---------------------------------------------------------------------------
-- Home town
-- ---------------------------------------------------------------------------
local function homeDistKm()
  local h = save and save.homeTown
  if not (h and h.lat and earth()) then return nil end
  local lat, lon = earth().playerLatLon()
  if not lat then return nil end
  return earth().miles(lat, lon, h.lat, h.lon) * 1.609344
end

-- a good default name for the setup box: Earth's place name, else the nearest town
local function suggestedHome()
  local e = earth()
  if not e then return nil end
  local loc = e.location()
  local lat, lon = e.playerLatLon()
  local t = lat and e.nearestTown(lat, lon) or nil
  if t and t._d and t._d < 15 then return t.name .. ", " .. t.st end
  if loc and loc.place and loc.place ~= "" then
    return loc.place .. ((loc.region and loc.region ~= "") and (", " .. loc.region) or "")
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- Moving your home base, and the teleport lock
-- ---------------------------------------------------------------------------
local function relocateFee()
  return (save.level >= RELOCATE_LEVEL) and RELOCATE_HIGH or RELOCATE_LOW
end

local function visitFee()
  return (save.level >= RELOCATE_LEVEL) and VISIT_HIGH or VISIT_LOW
end

local function teleportLockOn()
  return isRunning() and save.settings.teleportLock and save.homeTown and save.homeTown.lat ~= nil
end

local function placeName(lat, lon)
  local e = earth()
  local t = e and e.nearestTown(lat, lon) or nil
  if t and t._d and t._d < 15 then return t.name .. ", " .. t.st end
  local loc = e and e.location()
  if loc and loc.place and loc.place ~= "" then return loc.place end
  return string.format("%.3f, %.3f", lat, lon)
end

local function flagTeleport(lat, lon, why)
  save.pendingTeleport = { lat = lat, lon = lon, name = placeName(lat, lon), why = why }
  writeSave()
  msg("Teleporting is locked in career mode. Choose: go back home, or move your home base here.", 8)
  log("I", "earthCareer", "Teleport detected (" .. why .. ") to " .. save.pendingTeleport.name)
end

local function checkTeleport()
  if not teleportLockOn() or clock < settleUntil then return end
  local e = earth()
  if not (e and e.available()) then return end
  if not e.groundReady() then sawLoading = true return end   -- keep lastFix: compare after the load
  local lat, lon = e.playerLatLon()
  if not lat then return end
  if clock < graceUntil then
    -- our own move: just follow the car, no questions asked
    lastFix, sawLoading = { lat = lat, lon = lon, t = clock }, false
    if not returnTrip then save.lastPos = { lat = lat, lon = lon } end
    return
  end
  local h = save.homeTown

  -- loaded / resumed far from where you left off
  if needAwayCheck then
    needAwayCheck = false
    local last = save.lastPos
    if last and last.lat and not save.pendingTeleport
       and e.miles(lat, lon, last.lat, last.lon) > AWAY_MI then
      flagTeleport(lat, lon, "away")
    end
  end

  if lastFix and not save.pendingTeleport then
    local d = e.miles(lat, lon, lastFix.lat, lastFix.lon)
    local dt = math.max(0.05, clock - lastFix.t)
    if d > TELEPORT_MI and (sawLoading or d / dt * 3600 > TELEPORT_MPH) then
      local backHome = clock < expectHomeUntil and e.miles(lat, lon, h.lat, h.lon) < 3
      if backHome then
        expectHomeUntil = -1
        msg("Welcome home to " .. h.name .. ".", 4)
      else
        flagTeleport(lat, lon, "jump")
      end
    end
  end
  lastFix = { lat = lat, lon = lon, t = clock }
  sawLoading = false
  if not returnTrip then save.lastPos = { lat = lat, lon = lon } end
end

local function setHomeHere(lat, lon)
  local name = placeName(lat, lon)
  save.homeTown = { name = name, lat = lat, lon = lon, setAt = os.date("%Y-%m-%d") }
  return name
end

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------
-- stop everything the current profile has running in the world
local function unloadCurrent()
  if not save then return end
  if garage() then garage().storeActiveCarState() end
  writeSave()
  if jobs() then jobs().onCareerReset() end
  if earthCareer_map then pcall(earthCareer_map.onCareerReset) end
  if garage() then garage().onCareerPaused(); garage().onCareerReset() end
  save, current = nil, nil
  returnTrip = nil
end

local function pickerState()
  local list = {}
  for _, e in ipairs(index.profiles) do list[#list + 1] = e end
  table.sort(list, function(a, b) return tostring(a.lastPlayed or "") > tostring(b.lastPlayed or "") end)
  local last = index.last and entryFor(index.last) or nil
  return {
    picker = true,
    version = VERSION,
    profiles = (#list > 0) and list or nil,
    last = last and { id = last.id, name = last.name } or nil,
    maxProfiles = MAX_PROFILES,
    earth = earth() and earth().available() or false,
  }
end

-- ---------------------------------------------------------------------------
-- Back to your last save (after some freeroam)
-- ---------------------------------------------------------------------------
-- where you last were in career mode (kept while the career runs, any lock setting)
local function updateLastPos()
  if not isRunning() or returnTrip or save.pendingTeleport then return end
  local e = earth()
  if not (e and e.available() and e.groundReady()) then return end
  local lat, lon = e.playerLatLon()
  if lat then save.lastPos = { lat = lat, lon = lon } end
end

-- ask for the trip back; it happens once BeamNG.Earth is ready (a profile load
-- may run before the world has placed you)
local function startReturnTrip()
  local p = save and save.lastPos
  if not (p and p.lat) then return false end
  returnTrip = { lat = p.lat, lon = p.lon, giveUpAt = clock + RETURN_WAIT_S }
  needAwayCheck = false            -- no "you teleported" prompt for this one
  save.pendingTeleport = nil
  return true
end

local function updateReturnTrip()
  local r = returnTrip
  if not r then return end
  local e = earth()
  if r.sent then
    -- arrived (or Earth took long enough): back to normal, follow the car from here
    local lat, lon = e and e.playerLatLon()
    if (lat and e.groundReady() and e.miles(lat, lon, r.lat, r.lon) < 2) or clock > r.arriveBy then
      returnTrip = nil
      M.allowJump(5)
      if lat then save.lastPos = { lat = lat, lon = lon } end
    end
    return
  end
  if clock > r.giveUpAt then
    returnTrip = nil
    needAwayCheck = true             -- couldn't take you back: the usual rules apply
    msg("Couldn't take you back to your last save (is BeamNG.Earth's server connected?).", 7)
    return
  end
  if not (e and e.available() and e.groundReady()) then return end
  local lat, lon = e.playerLatLon()
  if not lat then return end
  if e.miles(lat, lon, r.lat, r.lon) < RETURN_MIN_MI then returnTrip = nil return end   -- already there
  local ok = e.teleport(r.lat, r.lon, "Last save")
  if ok then
    r.sent, r.arriveBy = true, clock + 90
    M.allowJump(95)
    msg("Taking you back to where you left off…", 5)
  end
end

-- how far you are from your last career spot (miles), for the paused screen
local function milesFromLastSave()
  local p = save and save.lastPos
  local e = earth()
  if not (p and p.lat and e) then return nil end
  local lat, lon = e.playerLatLon()
  if not lat then return nil end
  return e.miles(lat, lon, p.lat, p.lon)
end

-- ---------------------------------------------------------------------------
-- UI bridge
-- ---------------------------------------------------------------------------
local function buildState()
  local home = nil
  if save.homeTown then
    local fromHome = homeDistKm()
    home = { name = save.homeTown.name, setAt = save.homeTown.setAt, needsPin = save.homeTown.needsPin,
             lat = save.homeTown.lat, lon = save.homeTown.lon,
             fromHomeKm = fromHome and (math.floor(fromHome * 100 + 0.5) / 100) or nil }
  end
  local g, j, e = garage(), jobs(), earth()
  return {
    version   = VERSION,
    careerActive = isRunning(),
    tutorial  = save.homeTown and save.tutorial or nil,
    homeTown  = home,
    suggestedHome = (not save.homeTown) and suggestedHome() or nil,
    earth     = e and e.available() or false,
    hasCar    = getVeh() ~= nil,
    money     = save.money,
    level     = save.level,
    xp        = save.xp,
    xpNext    = xpForNextLevel(save.level),
    totalJobs = save.totalJobs,
    totalKm   = math.floor((save.totalKm or 0) * 10 + 0.5) / 10,
    settings  = save.settings,
    profile   = M.currentProfile(),
    returning = returnTrip ~= nil,
    fromLastSaveMi = (function() local m = milesFromLastSave(); return m and math.floor(m * 10 + 0.5) / 10 or nil end)(),
    relocateFee = relocateFee(),
    relocateLevel = RELOCATE_LEVEL,
    teleport  = save.pendingTeleport and {
      name = save.pendingTeleport.name, why = save.pendingTeleport.why,
      fee = relocateFee(), affordable = save.money >= relocateFee(),
      visitFee = visitFee(), visitAffordable = save.money >= visitFee(),
      onJob = save.jobs ~= nil and save.jobs.active ~= nil,
      going = clock < expectHomeUntil,
    } or nil,
    garage    = g and g.buildState() or nil,
    jobs      = j and j.buildState() or nil,
    bank      = earthCareer_bank and earthCareer_bank.buildState() or nil,
    achievements = earthCareer_achievements and earthCareer_achievements.buildState() or nil,
    discovery = earthCareer_discovery and earthCareer_discovery.buildState() or nil,
    achievementToast = earthCareer_achievements and earthCareer_achievements.toastState() or nil,
    nav       = (earthCareer_map and isRunning()) and earthCareer_map.navState() or nil,
    welcome   = earthCareer_map and earthCareer_map.welcomeState() or nil,
    statesVisited = earthCareer_map and earthCareer_map.statesVisited() or 0,
    statesList = (earthCareer_map and isRunning()) and earthCareer_map.statesVisitedList() or nil,
  }
end

local function pushState()
  guihooks.trigger("EarthCareerUpdate", save and buildState() or pickerState())
end

-- ---------------------------------------------------------------------------
-- Progression
-- ---------------------------------------------------------------------------
local LEVEL_UNLOCKS = {
  [5]  = "Regional jobs (75–250 mi) and semi/bus rentals unlocked!",
  [12] = "Long Haul jobs unlocked: coast to coast!",
}

local function addXp(amount)
  save.xp = save.xp + math.floor(amount or 0)
  while save.xp >= xpForNextLevel(save.level) do
    save.xp = save.xp - xpForNextLevel(save.level)
    save.level = save.level + 1
    msg("Level up! You're now level " .. save.level, 7)
    if LEVEL_UNLOCKS[save.level] then msg(LEVEL_UNLOCKS[save.level], 8) end
  end
end

-- ---------------------------------------------------------------------------
-- Shared API for the other modules
-- ---------------------------------------------------------------------------
M.getSave    = function() return save end
M.writeSave  = writeSave
M.pushState  = pushState
M.notify     = msg
M.isRunning  = isRunning
M.homeDistKm = homeDistKm
M.getVeh     = getVeh
M.addXp      = addXp
-- garage.lua calls this before it moves/respawns the car (repairs, recovery, vehicle swaps)
function M.allowJump(seconds)
  graceUntil = math.max(graceUntil, clock + (seconds or 8))
  lastFix = nil
end
M.teleportPending = function() return save ~= nil and save.pendingTeleport ~= nil end

function M.spend(amount)
  amount = math.floor(amount or 0)
  if save.money < amount then return false end
  save.money = save.money - amount
  return true
end

function M.earn(amount)
  save.money = save.money + math.floor(amount or 0)
end

-- ---------------------------------------------------------------------------
-- Public API (HUD buttons)
-- ---------------------------------------------------------------------------
function M.requestState()
  pushState()
end

function M.setHomeTown(name)
  if not getVeh() then msg("Spawn a vehicle first, then set your home town.") return end
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  if not lat then msg("Waiting for BeamNG.Earth to place you. Try again in a moment.", 5) return end
  name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then name = suggestedHome() or "Home Town" end
  save.homeTown = { name = name, lat = lat, lon = lon, setAt = os.date("%Y-%m-%d") }
  save.careerActive = true
  save.pendingTeleport, save.lastPos = nil, { lat = lat, lon = lon }
  lastFix, needAwayCheck = nil, false
  if garage() then garage().onCareerStarted() end
  save.tutorial = "radiator"   -- first-start tip: the beater Wendover has no radiator
  writeSave()
  pushState()
  msg("Welcome to " .. name .. "! Your Earth Career has started.", 7)
end

-- first-start tips (the radiator prompt): closed by a button, or on its own
-- once a radiator is fitted and paid for
function M.dismissTutorial()
  if save.tutorial == nil then return end
  save.tutorial = nil
  writeSave()
  pushState()
end

-- re-pin the home town to where you are now (keeps the name)
function M.repinHome()
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  if not (lat and save.homeTown) then msg("Can't read your position right now.") return end
  save.homeTown.lat, save.homeTown.lon, save.homeTown.needsPin, save.homeTown.pos = lat, lon, nil, nil
  save.pendingTeleport, save.lastPos = nil, { lat = lat, lon = lon }
  lastFix = nil
  writeSave()
  pushState()
  msg("Home town pinned here.", 4)
end

-- Home tab: move your home base to where you are now (after driving here)
function M.relocateHome()
  if not isRunning() then return end
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  if not lat then msg("Can't read your position right now.") return end
  if save.homeTown and save.homeTown.lat and e.miles(lat, lon, save.homeTown.lat, save.homeTown.lon) < 3 then
    msg("You're already at your home base.") return
  end
  local fee = relocateFee()
  if not M.spend(fee) then msg("Moving your home base costs $" .. fee .. ".") return end
  local name = setHomeHere(lat, lon)
  writeSave()
  pushState()
  msg(string.format("Home base moved to %s for $%d.", name, fee), 7)
end

-- teleport popup: pay to make this your new home base
function M.teleportRelocate()
  local p = save.pendingTeleport
  if not p then return end
  local fee = relocateFee()
  if not M.spend(fee) then msg("You can't afford the $" .. fee .. " move. Head back home instead.") return end
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  local name = setHomeHere(lat or p.lat, lon or p.lon)
  save.pendingTeleport = nil
  lastFix = nil
  writeSave()
  pushState()
  msg(string.format("Home base moved to %s for $%d.", name, fee), 7)
end

-- teleport popup: pay a small fee to stay where you landed; the home base doesn't move
function M.teleportVisit()
  local p = save.pendingTeleport
  if not p then return end
  if save.jobs and save.jobs.active then msg("Not during a job: go back home, or cancel the job first.") return end
  local fee = visitFee()
  if not M.spend(fee) then msg("You can't afford the $" .. fee .. " visit. Head back home instead.") return end
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  save.pendingTeleport = nil
  lastFix = nil
  if lat then save.lastPos = { lat = lat, lon = lon } end
  writeSave()
  pushState()
  msg(string.format("Visiting %s for $%d. Your home base is still %s.", p.name, fee, save.homeTown and save.homeTown.name or "where it was"), 7)
end

-- teleport popup: free trip back to the home base
function M.teleportHome()
  local h = save.homeTown
  if not (save.pendingTeleport and h and h.lat) then return end
  local e = earth()
  local ok, err = false, "BeamNG.Earth isn't loaded"
  if e then ok, err = e.teleport(h.lat, h.lon, h.name) end
  if not ok then msg("Couldn't teleport home: " .. tostring(err or "try again in a moment"), 6) return end
  save.pendingTeleport = nil
  expectHomeUntil = clock + 90
  lastFix = nil
  writeSave()
  pushState()
  msg("Heading home to " .. h.name .. "…", 5)
end

-- Home tab: skip the drive back after a long job
function M.goHome()
  local h = save.homeTown
  if not (isRunning() and h and h.lat) then return end
  if save.pendingTeleport then M.teleportHome() return end
  if save.jobs and save.jobs.active then msg("Finish or cancel your job before heading home.") return end
  local v = getVeh()
  if v and v:getVelocity():length() > 2 then msg("Come to a stop first.") return end
  local d = homeDistKm()
  if d and d < 3 then msg("You're already home.") return end
  local e = earth()
  local ok, err = false, "BeamNG.Earth isn't loaded"
  if e then ok, err = e.teleport(h.lat, h.lon, h.name) end
  if not ok then msg("Couldn't teleport home: " .. tostring(err or "try again in a moment"), 6) return end
  expectHomeUntil = clock + 90
  pushState()
  msg("Heading home to " .. h.name .. "…", 5)
end

local migrated = false

function M.loadProfile(id)
  local e = entryFor(id)
  if not e then msg("That profile doesn't exist anymore.") pushState() return end
  if save then unloadCurrent() end
  save = normalize(jsonReadFile(profilePath(id)))
  current = id
  index.last = id
  if earthCareer_discovery then earthCareer_discovery.onProfileChanged() end
  lastFix, needAwayCheck, settleUntil, migrated = nil, true, clock + 3, false
  returnTrip = nil
  autosaveTimer = 0
  if isRunning() and save.settings.returnToSave then startReturnTrip() end
  writeSave()
  if isRunning() then
    if garage() then garage().onCareerResumed() end
    if jobs() then jobs().onCareerResumed() end
  end
  pushState()
  msg("Profile loaded: " .. e.name, 4)
end

function M.newProfile(name)
  if #index.profiles >= MAX_PROFILES then msg("That's the most profiles (" .. MAX_PROFILES .. "). Delete one first.") return end
  local id = newId()
  local e = { id = id, name = cleanName(name, "Career " .. (#index.profiles + 1)), created = os.date("%Y-%m-%d") }
  index.profiles[#index.profiles + 1] = e
  jsonWriteFile(profilePath(id), defaultSave(), true)
  writeIndex()
  M.loadProfile(id)
end

function M.renameProfile(id, name)
  local e = entryFor(id or current)
  if not e then return end
  e.name = cleanName(name, e.name)
  writeIndex()
  pushState()
end

function M.deleteProfile(id)
  if id == current then msg("Switch to another profile before deleting this one.") return end
  local e, i = entryFor(id)
  if not e then return end
  -- keep a copy, just in case
  local data = jsonReadFile(profilePath(id))
  if type(data) == "table" then jsonWriteFile(PROFILE_DIR .. "deleted/" .. id .. ".json", data, true) end
  pcall(function() FS:removeFile(profilePath(id)) end)
  table.remove(index.profiles, i)
  if index.last == id then index.last = nil end
  writeIndex()
  pushState()
  msg("Deleted profile: " .. e.name, 4)
end

-- Settings: save and go back to the profile picker
function M.switchProfile()
  unloadCurrent()
  pushState()
  msg("Saved. Pick a profile.", 3)
end

function M.currentProfile()
  local e = current and entryFor(current) or nil
  return e and { id = e.id, name = e.name, created = e.created } or nil
end

function M.saveGame()
  if garage() then garage().storeActiveCarState() end
  writeSave()
  msg("Game saved.", 3)
end

function M.exitCareer()
  local e = earth()
  local lat, lon = nil, nil
  if e then lat, lon = e.playerLatLon() end
  if lat then save.lastPos = { lat = lat, lon = lon } end
  save.careerActive = false
  if jobs() then jobs().onCareerPaused() end
  if garage() then garage().onCareerPaused() end
  writeSave()
  pushState()
  msg("Earth Career paused. Your progress is saved.", 5)
end

function M.resumeCareer(mode)
  if not save.homeTown then return end
  save.careerActive = true
  lastFix, needAwayCheck, settleUntil = nil, true, clock + 3
  local back = (mode == "return") or (mode == nil and save.settings.returnToSave)
  if back then startReturnTrip() end
  if garage() then garage().onCareerResumed() end
  if jobs() then jobs().onCareerResumed() end
  writeSave()
  pushState()
  msg("Welcome back!", 3)
end

function M.setSetting(key, value)
  if save.settings[key] == nil then return end
  save.settings[key] = value and true or false
  if key == "teleportLock" then
    lastFix = nil
    if not value then save.pendingTeleport = nil end
  end
  if garage() then garage().onSettingChanged(key) end
  writeSave()
  pushState()
end

-- Settings: wipe everything and go back to setup. The old save is backed up.
function M.resetCareer()
  if save and current then jsonWriteFile(PROFILE_DIR .. current .. "_backup.json", save, true) end
  if jobs() then jobs().onCareerReset() end
  if earthCareer_map then pcall(earthCareer_map.onCareerReset) end
  if garage() then garage().onCareerPaused() end
  save = defaultSave()
  lastFix, needAwayCheck = nil, true
  if earthCareer_discovery then earthCareer_discovery.onProfileChanged() end
  if garage() then garage().onCareerReset() end
  writeSave()
  pushState()
  msg("Career reset. Pick a new home town to start over.", 6)
end
M.resetSave = M.resetCareer

-- debug helpers
function M.debugAddMoney(n) save.money = save.money + (n or 1000); writeSave(); pushState() end
function M.debugAddXp(n) addXp(n or 100); writeSave(); pushState() end

-- ---------------------------------------------------------------------------
-- Game hooks
-- ---------------------------------------------------------------------------
function M.onExtensionLoaded()
  math.randomseed(os.time())
  loadIndex()
  save, current = nil, nil   -- the profile picker asks which one to play
  log("I", "earthCareer", "Earth Career v" .. VERSION .. " loaded (" .. #index.profiles .. " profiles)")
end

function M.onClientPostStartMission()
  lastFix, needAwayCheck = nil, true
  settleUntil = clock + 12   -- Earth puts you back where you left off; give it time
end

function M.onUpdate(dtReal, dtSim, dtRaw)
  clock = clock + dtReal
  if not save then
    -- the profile picker is up
    uiTimer = uiTimer + dtReal
    if uiTimer >= 1 then uiTimer = 0; pushState() end
    return
  end
  if not migrated and earth() then migrated = true; migrateHome() end

  if isRunning() then
    autosaveTimer = autosaveTimer + dtReal
    if autosaveTimer >= AUTOSAVE_EVERY then
      autosaveTimer = 0
      if garage() then garage().storeActiveCarState() end
      writeSave()
    end
  end

  uiTimer = uiTimer + dtReal
  if uiTimer >= UI_INTERVAL then
    uiTimer = 0
    updateReturnTrip()
    updateLastPos()
    checkTeleport()
    pushState()
  end
end

return M
