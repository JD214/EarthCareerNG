-- ============================================================================
-- Earth Career  -  garage
-- Owned cars, dealership, fuel, damage/crashes, insurance, parts billing,
-- and the career vehicle lock.
--
-- How damage works: every car has a repair "bill" on the books. Crashing adds
-- to it. Resetting the car any other way (R, reload, recovery) fixes the
-- physics but NOT the bill. Paying or claiming insurance clears it.
-- ============================================================================

local M = {}

-- ---------------------------------------------------------------------------
-- Tuning
-- ---------------------------------------------------------------------------
local STARTER = {
  model  = "wendover",
  config = "vehicles/wendover/beamngearthcareerstartercar.pc",
  name   = "Soliad Wendover (beater)",
  value  = 1000,
}

-- Dealership: players pick any car in BeamNG's vehicle selector. The price
-- comes from the config's listed "Value". If a config has no value we use
-- this estimate and mark it as such.
local FALLBACK_PRICE = 12000

-- The economy runs hot on purpose: dealers mark cars up over what they're
-- actually worth, and resale/insurance only ever pays the real value.
local NEW_MARKUP     = 1.25    -- new cars (vehicle selector): listed value x this
local TRAILER_FALLBACK_PRICE = 9000  -- trailers with no listed value
local TRAILER_MODELS = { dryvan = true, flatbed = true, tanker = true, dolly = true, cargotrailer = true,
                         boxutility = true, boxutility_large = true, tsfb = true, frameless_dump = true, caravan = true }
local USED_MARKUP    = 1.30    -- used lot: depreciated value x this
local USED_STOCK     = 6       -- listings on the lot
local RESTOCK_JOBS   = 3       -- deliveries between new stock
local USED_SKIP      = { "police", "race", "drift", "rally", "track", "derby", "crawler", "prerunner", "safety", "ambulance", "fire" }
local USED_FALLBACK  = {       -- used only if the game's config list can't be read
  { model = "covet",    name = "Ibishu Covet",          value = 9000 },
  { model = "legran",   name = "Bruckell LeGran",       value = 11000 },
  { model = "fullsize", name = "Gavril Grand Marshal",  value = 14000 },
  { model = "pessima",  name = "Ibishu Pessima",        value = 16000 },
  { model = "pickup",   name = "Gavril D-Series",       value = 24000 },
  { model = "van",      name = "Gavril H-Series",       value = 26000 },
  { model = "roamer",   name = "Gavril Roamer",         value = 22000 },
  { model = "etk800",   name = "ETK 800-Series",        value = 42000 },
}
local SELLERS = { "Dave's Auto", "Route 99 Motors", "Cash for Cars", "Private seller", "Grandma's estate sale",
                  "Lot 7 Pre-Owned", "Honest Earl's", "Bank repo", "Fleet auction", "Kim's Car Corner" }

local FUEL_PRICE = { gasoline = 3.45, diesel = 3.95, electricEnergy = 0.18 }  -- $/gal, $/gal, $/kWh
local L_PER_GAL      = 3.78541
local SERVICE_FEE    = 25      -- mobile fuel delivery fee when away from home
local HOME_RADIUS_KM = 1.6     -- within 1 mi of home counts as "at home"

local DMG_TO_COST    = 0.45    -- $ per BeamNG damage unit, before the car-value factor
local TOTAL_RATIO    = 0.75    -- bill >= 75% of value ...
local TOTAL_MIN      = 1500    -- ... and at least $1,500 = totaled
local CRASH_MIN      = 150     -- a jump this big in a few seconds = crash popup
local RECOVERY_FEE   = 100
local SELL_RATIO     = 0.6
local SCRAP_RATIO    = 0.1
local CLEAN_JOBS_PER_CLAIM = 5 -- clean deliveries to forgive one insurance claim
local PARTS_RESALE   = 0.5     -- paid parts add this share to the car's value

-- Inputs blocked while the vehicle lock is on (missing names are ignored).
-- Parts changes are allowed anywhere because they get billed.
local BLOCKED_ACTIONS = {
  "reset_physics", "reset_all_physics", "reload_vehicle", "reload_all_vehicles",
  "loadHome", "saveHome", "recover_vehicle", "recover_vehicle_alt", "recover_to_last_road",
  "dropPlayerAtCamera", "dropPlayerAtCameraNoReset",
  "nodegrabberGrab", "nodegrabberAction", "nodegrabberStrength",
}
-- Spawning is blocked separately so it can open up while shopping
local SPAWN_ACTIONS = { "vehicle_selector" }

-- ---------------------------------------------------------------------------
-- Runtime state (not saved)
-- ---------------------------------------------------------------------------
local careerVehId   = nil   -- id of the spawned career car
local settleTimer   = 0     -- wait after a spawn before trusting readings
local spawning      = false
local mapGrace      = 0     -- wait after a map load before spawning
local fuel          = nil   -- { liters, cap, ratio, type }
local lastFuelRatio = nil
local fuelGrace     = 0     -- ignore fuel jumps while we're the ones changing it
local liveCost      = 0     -- repair cost implied by current physical damage
local crash         = nil   -- { cost, t, totaled }
local pendingParts  = nil   -- { cost, changes, parts, vars, mainPartName }
local lockApplied   = nil
local shopping      = false -- vehicle selector is open for buying
local shopSpawns    = {}    -- vid -> time spawned while shopping
local pendingBuy    = nil   -- { vid, model, config, name, price, value, estimated, listing }
local usedTest      = nil   -- used-lot listing being test-driven
local catalog       = nil   -- cached list of buyable configs for the used lot
local lowFuelWarned = 0
local tick1, tick2, tickLock = 0, 0, 0
local clock         = 0
local recentReset   = -100  -- when the car was last reset/respawned (so a full tank then isn't a pump fill-up)
local classCache    = {}
local trailerObjs   = {}    -- owned trailer id -> spawned object id
local jobTrailerVid = nil   -- the rental trailer that came with a job vehicle
local shopKind      = "car" -- what the selector was opened for: "car" | "trailer"
local couplings     = {}    -- objId -> { [otherObjId] = true } (BeamNG coupler hooks)

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
local function core() return earthCareer_main end
local function S() return core() and core().getSave() end
local function G() local s = S(); return s and s.garage end
local function msg(t, ttl) if core() then core().notify(t, ttl) end end
local function getVeh() return core() and core().getVeh() or nil end
local function clamp(x, a, b) return math.max(a, math.min(b, x)) end

local function activeCar()
  local g = G()
  if not g or not g.activeId then return nil end
  for _, c in ipairs(g.cars) do if c.id == g.activeId then return c end end
  return nil
end

local function carById(id)
  local g = G()
  if not g then return nil end
  for i, c in ipairs(g.cars) do if c.id == id then return c, i end end
  return nil
end

local function lockOn()
  local s = S()
  return s and s.settings and s.settings.vehicleLock and core().isRunning()
end

local function jobVeh() local g = G(); return g and g.jobVehicle or nil end

-- what kind of vehicle a model is: car / truck / semi / bus
local function classOf(model)
  model = tostring(model or "")
  if classCache[model] then return classCache[model] end
  local m = model:lower()
  local cls = "car"
  if TRAILER_MODELS[m] or m:find("trailer") then cls = "trailer"
  elseif m:find("bus") then cls = "bus"
  elseif m:find("semi") then cls = "semi"
  else
    local info = nil
    pcall(function() info = core_vehicles.getModel(model) end)
    local d = (type(info) == "table" and type(info.model) == "table") and info.model or {}
    local body = tostring(d["Body Style"] or d.BodyStyle or ""):lower()
    local typ = tostring(d.Type or ""):lower()
    if typ == "trailer" or body:find("trailer") then cls = "trailer"
    elseif body:find("bus") then cls = "bus"
    elseif body:find("semi") or body:find("tractor") then cls = "semi"
    elseif body:find("pickup") or body:find("truck") or typ == "truck" then cls = "truck" end
  end
  classCache[model] = cls
  return cls
end

local function inCareerCar()
  local v = getVeh()
  return v ~= nil and careerVehId ~= nil and v:getID() == careerVehId
end

-- BeamNG's on-foot mode is a small "unicycle" vehicle the player gets put in
local function isWalker(v)
  if not v then return false end
  local ok, m = pcall(function() return v:getJBeamFilename() end)
  return ok and m == "unicycle"
end

local wasWalking = false   -- last lock check had you on foot

-- for jobs: are you sitting in your car / job vehicle right now (not on foot)?
function M.inCareerCar() return inCareerCar() end
function M.onFoot() return isWalker(getVeh()) end

local function objById(id)
  if not id then return nil end
  local o = nil
  pcall(function() o = be:getObjectByID(id) end)
  if not o then pcall(function() o = scenetree.findObjectById(id) end) end
  return o
end

-- Vehicles are never deleted on the spot: deleting one in the same frame the
-- game switches you in/out of it, or deleting the car you're sitting in, can
-- crash the engine. They're queued and removed a moment later, if still safe.
local deleteQueue = {}   -- { id, at }
local function deleteVeh(o)
  if not o then return end
  local id = nil
  pcall(function() id = o:getID() end)
  if id then deleteQueue[#deleteQueue + 1] = { id = id, at = os.clock() + 0.3 } end
end

local function processDeletes()
  if #deleteQueue == 0 then return end
  local now = os.clock()
  local mine = nil
  local pv = (be and be.getPlayerVehicle) and be:getPlayerVehicle(0) or nil
  if pv then pcall(function() mine = pv:getID() end) end
  for i = #deleteQueue, 1, -1 do
    local d = deleteQueue[i]
    if now >= d.at then
      table.remove(deleteQueue, i)
      if d.id ~= mine then
        local o = nil
        pcall(function() o = be:getObjectByID(d.id) end)
        if o then pcall(function() o:delete() end) end
      else
        log("W", "earthCareer", "Skipped deleting the vehicle you're in (id " .. tostring(d.id) .. ")")
      end
    end
  end
end

local function vehModel(v)
  local m = nil
  if v then pcall(function() m = v:getJBeamFilename() end) end
  return m
end

local function isTrailerObj(v) return v ~= nil and classOf(vehModel(v)) == "trailer" end

-- spawned trailers we know about (owned, the job's rental, or one being bought)
local function knownTrailer(vid)
  if vid == jobTrailerVid then return true end
  if pendingBuy and pendingBuy.vid == vid then return true end
  for _, oid in pairs(trailerObjs) do if oid == vid then return true end end
  return false
end

-- spawn a trailer just behind a vehicle, facing the same way, without getting in it
local function spawnTrailerBehind(model, config, behindVeh)
  if not behindVeh then return nil end
  if core() and core().allowJump then core().allowJump(6) end
  local pos, dir, up = behindVeh:getPosition(), behindVeh:getDirectionVector(), behindVeh:getDirectionVectorUp()
  local big = (classOf(vehModel(behindVeh)) == "semi")
  local back = big and 13 or 7
  local p = pos - dir * back + vec3(0, 0, 0.4)
  local opts = { pos = p, autoEnterVehicle = false }
  pcall(function() opts.rot = quatFromDir(dir, up) end)
  if config then opts.config = config end
  local obj = nil
  local ok, err = pcall(function() obj = core_vehicles.spawnNewVehicle(model, opts) end)
  if not ok then log("E", "earthCareer", "Trailer spawn failed: " .. tostring(err)) return nil end
  -- if the game put us in the trailer, hop back into the truck
  pcall(function() be:enterVehicle(0, behindVeh) end)
  local id = nil
  if obj then pcall(function() id = obj:getID() end) end
  return id
end

-- model, config path, display name and listed price of a spawned vehicle
local function vehicleInfo(v)
  local info = { model = nil, config = nil, name = nil, price = nil }
  pcall(function() info.model = v:getJBeamFilename() end)
  pcall(function()
    local pc = v.partConfig
    if type(pc) == "string" and pc:match("%.pc$") then info.config = pc end
  end)
  if info.model then
    local cfgKey = info.config and info.config:match("([^/]+)%.pc$") or nil
    local data = nil
    pcall(function() data = core_vehicles.getConfig(info.model, cfgKey) end)
    if type(data) == "table" then
      info.price = tonumber(data.Value or data.value)
      local parts = {}
      if data.Brand then parts[#parts + 1] = data.Brand end
      if data.Name then parts[#parts + 1] = data.Name end
      if data.Configuration then parts[#parts + 1] = data.Configuration end
      if #parts > 0 then info.name = table.concat(parts, " ") end
    end
  end
  info.name = info.name or (info.model or "Mystery car")
  return info
end

local function speedOf(v) return v and v:getVelocity():length() or 0 end

local function valueFactor(value) return clamp((value or 1000) / 15000, 0.35, 3.0) end
local function costFromDamage(dmg, value) return math.floor((dmg or 0) * DMG_TO_COST * valueFactor(value)) end

local function isTotaled(car)
  return car and (car.bill or 0) >= math.max(TOTAL_MIN, car.value * TOTAL_RATIO)
end

local CHEAP_DEDUCTIBLE = 25    -- Settings → Cheap insurance: no claim ever costs more than this

local function deductible(car)
  local g = G()
  local base = 250 + math.floor((car and car.value or 1000) * 0.05)
  local full = base + 250 * (g and g.insurance.claims or 0)
  local s = S()
  if s and s.settings and s.settings.cheapInsurance then return math.min(CHEAP_DEDUCTIBLE, full) end
  return full
end

local function atHome()
  local d = core() and core().homeDistKm()
  return d ~= nil and d <= HOME_RADIUS_KM
end

local function prettySlot(slot, model)
  local s = tostring(slot or "")
  if model then s = s:gsub("^" .. model .. "_", "") end
  s = s:gsub("_", " ")
  return s
end

-- ---------------------------------------------------------------------------
-- Vehicle-side fuel helpers (run inside the car's Lua)
-- ---------------------------------------------------------------------------
local FUEL_TYPES_VLUA = "local ok = {gasoline=true, diesel=true, electricEnergy=true, kerosene=true, lpg=true}"

local function queryFuel(veh)
  veh:queueLuaCommand(FUEL_TYPES_VLUA .. [[
    local tot, cap, typ = 0, 0, "none"
    if energyStorage and energyStorage.getStorages then
      for _, s in pairs(energyStorage.getStorages()) do
        if ok[s.energyType] then
          if s.remainingVolume and s.capacity then
            tot = tot + s.remainingVolume; cap = cap + s.capacity
          elseif s.storedEnergy and s.energyCapacity then
            tot = tot + s.storedEnergy / 3600000; cap = cap + s.energyCapacity / 3600000
          end
          typ = s.energyType
        end
      end
    end
    local id = objectId or obj:getID()
    obj:queueGameEngineLua(string.format("earthCareer_garage.onFuelData(%d,%f,%f,%q)", id, tot, cap, typ))
  ]])
end

local function setFuelRatio(veh, r)
  r = clamp(r or 1, 0, 1)
  fuelGrace = 2.0
  lastFuelRatio = r
  veh:queueLuaCommand(FUEL_TYPES_VLUA .. string.format([[
    local r = %f
    if energyStorage and energyStorage.getStorages then
      for _, s in pairs(energyStorage.getStorages()) do
        if ok[s.energyType] then
          if s.setRemainingRatio then s:setRemainingRatio(r)
          elseif s.setRemainingVolume and s.capacity then s:setRemainingVolume(s.capacity * r) end
        end
      end
    end
  ]], r))
end

-- ---------------------------------------------------------------------------
-- Parts: read the car's current config, price changes
-- ---------------------------------------------------------------------------
local function flattenTree(node, out)
  if type(node) ~= "table" or type(node.children) ~= "table" then return end
  for slot, child in pairs(node.children) do
    out[slot] = child.chosenPartName or ""
    flattenTree(child, out)
  end
end

local function getCurrentConfig()
  local ok, vd = pcall(function() return core_vehicle_manager.getPlayerVehicleData() end)
  if not ok or type(vd) ~= "table" or type(vd.config) ~= "table" then return nil end
  local cfg = vd.config
  local parts = nil
  if type(cfg.parts) == "table" then
    parts = {}
    for k, v in pairs(cfg.parts) do parts[k] = v end
  elseif type(cfg.partsTree) == "table" then
    parts = {}
    flattenTree(cfg.partsTree, parts)
  end
  if not parts then return nil end
  return { parts = parts, vars = cfg.vars, mainPartName = cfg.mainPartName }
end

local function partPrice(slot, part, carValue)
  local s = (tostring(slot) .. " " .. tostring(part)):lower()
  local p = 150
  if s:find("mount") then p = 120
  elseif s:find("turbo") or s:find("supercharger") then p = 1800
  elseif s:find("n2o") then p = 1200
  elseif s:find("ecu") then p = 450
  elseif s:find("internals") then p = 900
  elseif s:find("engine") then p = 2800
  elseif s:find("transmission") then p = 1600
  elseif s:find("transfer") then p = 700
  elseif s:find("differential") or s:find("finaldrive") then p = 600
  elseif s:find("exhaust") or s:find("header") or s:find("intake") or s:find("radiator") or s:find("muffler") then p = 400
  elseif s:find("suspension") or s:find("strut") or s:find("spring") or s:find("coilover") or s:find("swaybar") or s:find("shock") or s:find("damper") then p = 550
  elseif s:find("brake") then p = 350
  elseif s:find("rollcage") then p = 900
  elseif s:find("tire") then p = 160
  elseif s:find("hubcap") then p = 40
  elseif s:find("wheel") then p = 200
  elseif s:find("bulb") or s:find("light") then p = 25
  elseif s:find("paint") or s:find("skin") then p = 450
  elseif s:find("cargo") or s:find("load") then p = 90
  elseif s:find("seat") or s:find("interior") or s:find("dash") then p = 180
  elseif s:find("bumper") or s:find("fender") or s:find("hood") or s:find("door") or s:find("trunk")
      or s:find("fascia") or s:find("tailgate") or s:find("skirt") or s:find("spoiler") or s:find("wing") then p = 220
  end
  return math.floor(p * clamp((carValue or 1000) / 15000, 0.5, 2.5))
end

local function diffParts(old, new)
  local changes, seen = {}, {}
  for k, v in pairs(new) do
    seen[k] = true
    if (old[k] or "") ~= (v or "") then changes[#changes + 1] = { slot = k, from = old[k] or "", to = v or "" } end
  end
  for k, v in pairs(old) do
    if not seen[k] and (v or "") ~= "" then changes[#changes + 1] = { slot = k, from = v, to = "" } end
  end
  return changes
end

local function saveCarConfig(car, cfg)
  local path = "vehicles/" .. car.model .. "/earthcareer_car" .. car.id .. ".pc"
  local ok = pcall(function()
    jsonWriteFile(path, {
      format = 2, model = car.model,
      mainPartName = cfg.mainPartName or car.model,
      parts = cfg.parts, vars = cfg.vars or {},
    }, true)
  end)
  if ok then car.config = path end
  return ok
end

-- ---------------------------------------------------------------------------
-- Spawning
-- ---------------------------------------------------------------------------
local spawnTimes = {}      -- recent spawn times (runaway guard)
local spawnBlockedUntil = 0
local function spawnCar(car, asNew)
  if not car then return end
  local now = os.clock()
  if now < spawnBlockedUntil then return end
  for i = #spawnTimes, 1, -1 do if now - spawnTimes[i] > 30 then table.remove(spawnTimes, i) end end
  if #spawnTimes >= 6 then
    -- something keeps failing: stop instead of spawning cars forever
    spawnBlockedUntil = now + 60
    spawnTimes = {}
    log("E", "earthCareer", "Too many vehicle spawns in 30 s; pausing respawns for a minute. Last: " .. tostring(car.model))
    msg("Earth Career paused respawning your car for a minute (something kept failing). Check the console.", 8)
    return
  end
  spawnTimes[#spawnTimes + 1] = now
  if core() and core().allowJump then core().allowJump(10) end   -- our own respawn, not a teleport
  local opts = {}
  if car.config then opts.config = car.config end
  spawning = true
  settleTimer = 2.5
  careerVehId = nil
  pendingParts = nil
  fuel = nil
  liveCost = 0
  local ok, err = pcall(function()
    if getVeh() and not asNew then core_vehicles.replaceVehicle(car.model, opts)
    else core_vehicles.spawnNewVehicle(car.model, opts) end
  end)
  if not ok then
    spawning = false
    log("E", "earthCareer", "Could not spawn " .. tostring(car.model) .. ": " .. tostring(err))
    msg("Couldn't spawn your " .. car.name .. ". Check the console.", 6)
  end
end

-- called once the spawned car has settled
local function onCareerCarReady()
  local v = getVeh()
  local car = activeCar()
  spawning = false
  recentReset = clock
  local jv = jobVeh()
  if v and jv then
    careerVehId = v:getID()
    liveCost, crash, pendingParts, fuel = 0, nil, nil, nil
    -- rental semis come with a trailer
    if jv.trailer and not (jobTrailerVid and objById(jobTrailerVid)) then
      jobTrailerVid = spawnTrailerBehind(jv.trailer, jv.trailerConfig, v)
      if jobTrailerVid then msg("Your rental trailer is behind you. Back up and press L to hitch.", 7) end
    end
    return
  end
  if not (v and car) then return end
  careerVehId = v:getID()
  liveCost = 0
  crash = nil
  -- a trailer you rented for this job (own semi): bring it back if it's gone
  local jt = G().jobTrailer
  if jt and not (jobTrailerVid and objById(jobTrailerVid)) then
    jobTrailerVid = spawnTrailerBehind(jt.model, jt.config, v)
    if jobTrailerVid then msg("Your rental trailer is back behind you. Back up and press L to hitch.", 7) end
  end
  if car.fuelRatio then setFuelRatio(v, car.fuelRatio) end
  local cfg = getCurrentConfig()
  if cfg then car.parts = cfg.parts end
end

-- ---------------------------------------------------------------------------
-- Vehicle lock: block reset/spawn inputs, keep the player in their car
-- ---------------------------------------------------------------------------
local function setActionGroups(lockGroup, spawnGroup)
  pcall(function()
    core_input_actionFilter.setGroup("earthCareerLock", BLOCKED_ACTIONS)
    core_input_actionFilter.addAction(0, "earthCareerLock", lockGroup)
  end)
  pcall(function()
    core_input_actionFilter.setGroup("earthCareerSpawn", SPAWN_ACTIONS)
    core_input_actionFilter.addAction(0, "earthCareerSpawn", spawnGroup)
  end)
end

local function applyLock()
  local on = lockOn() and true or false
  local spawnBlocked = on and not shopping and not pendingBuy
  local key = tostring(on) .. "/" .. tostring(spawnBlocked)
  if lockApplied == key then return end
  lockApplied = key
  setActionGroups(on, spawnBlocked)
end

local function enforceLock()
  if not lockOn() or spawning or mapGrace > 0 or shopping or pendingBuy then return end
  local car = jobVeh() or activeCar()
  if not car then return end
  local v = getVeh()
  if not v then return end
  if careerVehId == nil then
    spawnCar(car)
    return
  end
  if v:getID() ~= careerVehId and isTrailerObj(v) then
    -- "in" a trailer: hop back into the truck; unowned trailers go away
    local tid = v:getID()
    local ours = objById(careerVehId)
    if ours then pcall(function() be:enterVehicle(0, ours) end) else spawnCar(car, true) end
    if not knownTrailer(tid) then
      deleteVeh(objById(tid))
      msg("Career mode: buy trailers in Garage → Trailers.", 5)
    end
    return
  end
  -- on foot (walking mode): free to get out, walk around and get back in
  if v:getID() ~= careerVehId and isWalker(v) then wasWalking = true return end
  if v:getID() ~= careerVehId and wasWalking then
    -- walked up to someone else's car and got in: put you back on your feet
    wasWalking = false
    local out = false
    if gameplay_walk and type(gameplay_walk.setWalkingMode) == "function" then
      out = pcall(gameplay_walk.setWalkingMode, true)
    end
    if out then
      wasWalking = true
      msg(jobVeh() and "Not that one: walk back to your job vehicle." or "Career mode: you can only drive cars you own. Walk back to yours.", 5)
      return
    end
  end
  wasWalking = false
  if v:getID() ~= careerVehId then
    local ours = nil
    pcall(function() ours = be:getObjectByID(careerVehId) end)
    if ours then
      pcall(function() be:enterVehicle(0, ours) end)
    else
      spawnCar(car)
    end
    msg(jobVeh() and "Stay in your job vehicle until the job's done." or "Career mode: you can only drive cars you own. Buy cars in the Garage.", 5)
  end
end

-- ---------------------------------------------------------------------------
-- Car state bookkeeping
-- ---------------------------------------------------------------------------
function M.storeActiveCarState()
  local car = activeCar()
  if car and fuel and inCareerCar() then car.fuelRatio = fuel.ratio end
end

local function newCar(model, config, name, value)
  local g = G()
  local car = {
    id = g.nextId, model = model, config = config, name = name, value = value,
    bill = 0, odoKm = 0, fuelRatio = nil, boughtAt = os.date("%Y-%m-%d"),
  }
  g.nextId = g.nextId + 1
  g.cars[#g.cars + 1] = car
  return car
end

local function giveStarterCar()
  local car = newCar(STARTER.model, STARTER.config, STARTER.name, STARTER.value)
  G().activeId = car.id
  return car
end


-- after a car is removed (scrapped / insurance payout)
local function afterCarRemoved()
  local g = G()
  if #g.cars > 0 then
    g.activeId = g.cars[1].id
    spawnCar(g.cars[1])
    return
  end
  g.activeId = nil
  careerVehId = nil
  if S().money < STARTER.value then
    local c = giveStarterCar()
    c.name = "Junkyard Wendover"
    msg("You're out of cars and cash, so a buddy lent you a junker. Get back to work!", 8)
    spawnCar(c)
  else
    msg("You don't own a car anymore. Head to the Dealership tab to buy one.", 8)
  end
end

-- Fix the car where it stands, upright and facing the same way. (A plain
-- physics reset sends it back to where it was spawned, which on BeamNG.Earth
-- can be miles away.)
local function physicallyRepair(v)
  if not v then return end
  recentReset = clock
  if core() and core().allowJump then core().allowJump(10) end
  local pos = v:getPosition()
  local dir = v:getDirectionVector()
  local flat = vec3(dir.x, dir.y, 0)
  if flat:length() < 0.1 then flat = vec3(0, 1, 0) end
  flat = flat:normalized()
  local rot = nil
  pcall(function() rot = quatFromDir(flat, vec3(0, 0, 1)) end)
  local place = pos + vec3(0, 0, 0.5)
  -- the game's own "teleport + reset" puts it down safely on the ground
  local done = false
  if rot and spawn and spawn.safeTeleport then
    done = pcall(spawn.safeTeleport, v, place, rot)
  end
  if not done then
    v:queueLuaCommand("obj:requestReset(RESET_PHYSICS)")
    M._restorePose = { t = 0.25, pos = place, rot = rot }
  end
  if lastFuelRatio then
    local r = lastFuelRatio
    -- restore fuel after the reset refills the tank
    M._afterReset = { t = 0.6, ratio = r }
  end
end

local function clearBill(car)
  car.bill = 0
  crash = nil
end

local function requireStoppedInCar()
  local v = getVeh()
  if not inCareerCar() then msg("Get in your career car first.") return nil end
  if speedOf(v) > 2 then msg("Come to a stop first.") return nil end
  return v
end

-- ---------------------------------------------------------------------------
-- Public API (HUD buttons)
-- ---------------------------------------------------------------------------
function M.repair()
  local car = activeCar()
  if not car or (car.bill or 0) <= 0 then return end
  local v = requireStoppedInCar(); if not v then return end
  if not core().spend(car.bill) then msg("Not enough money. Try an insurance claim.") return end
  msg(string.format("Repaired for $%d.", car.bill), 5)
  clearBill(car)
  physicallyRepair(v)
  core().writeSave(); core().pushState()
end

function M.claim()
  local car = activeCar()
  if not car or (car.bill or 0) <= 0 then return end
  local ded = deductible(car)
  -- even a totaled car: insurance fixes it for the deductible (keep the car).
  -- Selling it for scrap is still there as a separate choice.
  local totaled = isTotaled(car)
  local v = requireStoppedInCar(); if not v then return end
  if ded >= car.bill then msg("The deductible is more than the repair. Just pay for it.") return end
  if not core().spend(ded) then msg("You can't cover the $" .. ded .. " deductible.") return end
  G().insurance.claims = G().insurance.claims + 1
  G().insurance.cleanJobs = 0
  if totaled then
    msg(string.format("Insurance covered the total loss: your %s is fixed. You paid the $%d deductible.", car.name, ded), 7)
  else
    msg(string.format("Claim filed. You paid the $%d deductible.", ded), 6)
  end
  clearBill(car)
  physicallyRepair(v)
  core().writeSave(); core().pushState()
end

function M.scrap()
  local car = activeCar()
  if not car then return end
  local g = G()
  local value = math.floor(car.value * SCRAP_RATIO)
  core().earn(value)
  local _, idx = carById(car.id)
  table.remove(g.cars, idx)
  crash = nil
  msg(string.format("Sold %s for scrap: +$%d", car.name, value), 6)
  afterCarRemoved()
  core().writeSave(); core().pushState()
end

-- Totaled-crash prompt, step 1: "me" -> the usual pay/claim/scrap choices;
-- "bug" (BeamNG.Earth terrain/road glitch) -> the car is fixed in place and
-- this crash's damage is wiped as if it never happened (bill, cargo damage).
function M.crashCause(cause)
  if not crash then return end
  if cause ~= "bug" then
    crash.cause = "me"
    core().pushState()
    return
  end
  local car = activeCar()
  local cost = crash.cost or 0
  if car then car.bill = math.max(0, (car.bill or 0) - cost) end
  G().damageMeter = math.max(0, (G().damageMeter or 0) - cost)   -- no cargo damage for this one either
  crash = nil
  local v = getVeh()
  if v and inCareerCar() then
    physicallyRepair(v)   -- (liveCost follows the reset on its own, without billing)
  end
  log("I", "earthCareer", "Crash marked as a map bug: $" .. tostring(cost) .. " of damage removed")
  msg("Map glitch: your car has been reset like nothing happened.", 6)
  core().writeSave(); core().pushState()
end

function M.dismissCrash()
  crash = nil
  core().pushState()
end

function M.recover()
  local v = requireStoppedInCar(); if not v then return end
  if not core().spend(RECOVERY_FEE) then msg("Roadside recovery costs $" .. RECOVERY_FEE .. ".") return end
  physicallyRepair(v)  -- bill stays on the books
  msg("Roadside recovery: $" .. RECOVERY_FEE .. ". Any damage is still on your repair bill.", 6)
  core().writeSave(); core().pushState()
end

function M.refuel(gallons)
  local v = getVeh()
  if not inCareerCar() or not fuel or fuel.cap <= 0 then msg("Get in your career car first.") return end
  if speedOf(v) > 1 then msg("Stop the car to refuel.") return end
  local electric = fuel.type == "electricEnergy"
  local missing = fuel.cap - fuel.liters                        -- liters or kWh
  local add = missing
  if gallons and gallons > 0 then add = math.min(missing, electric and gallons * 10 or gallons * L_PER_GAL) end
  if add <= 0.05 then msg("Tank's already full.") return end
  local unitPrice = FUEL_PRICE[fuel.type] or FUEL_PRICE.gasoline
  local cost = electric and add * unitPrice or (add / L_PER_GAL) * unitPrice
  if not atHome() then cost = cost + SERVICE_FEE end
  cost = math.ceil(cost)
  if not core().spend(cost) then msg("You can't afford that ($" .. cost .. ").") return end
  setFuelRatio(v, (fuel.liters + add) / fuel.cap)
  msg(string.format("Refueled for $%d%s.", cost, atHome() and "" or " (incl. $" .. SERVICE_FEE .. " delivery fee)"), 5)
  core().writeSave(); core().pushState()
end

function M.openParts()
  if not inCareerCar() then msg("Get in your career car first.") return end
  local ok = pcall(function() guihooks.trigger("ChangeState", { state = "menu.vehicleconfig.parts" }) end)
  if not ok then pcall(function() guihooks.trigger("ChangeState", "menu.vehicleconfig") end) end
  msg("Add or swap parts. Removing parts and tuning are free; new parts get billed.", 6)
end

function M.payParts()
  local car = activeCar()
  if not (car and pendingParts) then return end
  if not core().spend(pendingParts.cost) then msg("Not enough money. Revert the changes or earn more.") return end
  car.parts = pendingParts.parts
  car.value = car.value + math.floor(pendingParts.cost * PARTS_RESALE)
  saveCarConfig(car, pendingParts)
  msg(string.format("Parts paid: $%d. Your car is now worth $%d.", pendingParts.cost, car.value), 6)
  -- the first-start radiator tip is done once one is fitted
  for slot, part in pairs(pendingParts.parts or {}) do
    if tostring(slot):lower():find("radiator") and type(part) == "string" and part ~= "" then
      if core().dismissTutorial then core().dismissTutorial() end
      break
    end
  end
  pendingParts = nil
  core().writeSave(); core().pushState()
end

function M.revertParts()
  if jobVeh() then msg(jobVeh().kind == "rentcar" and "Return your rental car first (Garage)." or "Finish your job first: you're in a job vehicle.") return end
  local car = activeCar()
  if not car then return end
  M.storeActiveCarState()
  pendingParts = nil
  spawnCar(car)
  msg("Parts changes reverted.", 4)
end

-- ---------------------------------------------------------------------------
-- Car shopping through BeamNG's vehicle selector
-- ---------------------------------------------------------------------------
-- BeamNG 0.39+ has a new vehicle selector screen, opened through
-- ui_vehicleSelector_general; the old "menu.vehicles" page is the fallback
-- for older game versions.
local function openSelector()
  local vs = rawget(_G, "ui_vehicleSelector_general")
  if not vs and extensions and extensions.load then
    pcall(extensions.load, "ui_vehicleSelector_general")
    vs = rawget(_G, "ui_vehicleSelector_general")
  end
  if type(vs) == "table" then
    for _, fn in ipairs({ "openVehicleSelectorForFreeroam", "openFromPause", "openVehicleSelectorForFreeroamModal" }) do
      if type(vs[fn]) == "function" then
        local ok, err = pcall(vs[fn])
        if ok then return end
        log("W", "earthCareer", "Vehicle selector: " .. fn .. " failed: " .. tostring(err))
      end
    end
  end
  log("W", "earthCareer", "Vehicle selector: new selector not found, trying the old menu")
  pcall(function() guihooks.trigger("ChangeState", { state = "menu.vehicles" }) end)
end

-- ---------------------------------------------------------------------------
-- Used lot
-- ---------------------------------------------------------------------------
local function skipConfig(text)
  text = tostring(text or ""):lower()
  for _, w in ipairs(USED_SKIP) do if text:find(w, 1, true) then return true end end
  return false
end

local function buildCatalog()
  if catalog then return catalog end
  catalog = {}
  pcall(function()
    local list = core_vehicles.getConfigList()
    local configs = list and (list.configs or list) or {}
    for _, c in pairs(configs) do
      local model = c.model_key or c.model
      local key = c.key
      local value = tonumber(c.Value or c.value)
      local typ = c.Type or (c.aggregates and c.aggregates.Type and next(c.aggregates.Type))
      local okType = typ == nil or typ == "Car" or typ == "Truck"
      local label = table.concat({ tostring(c.Brand or ""), tostring(c.Name or ""), tostring(c.Configuration or "") }, " ")
      if model and key and value and value >= 1500 and value <= 150000 and okType
         and model ~= "unicycle" and not skipConfig(label .. " " .. key)
         and not tostring(c.Source or ""):lower():find("custom") and key:lower() ~= "custom" then
        local name = label:gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")
        catalog[#catalog + 1] = {
          model = model, config = "vehicles/" .. model .. "/" .. key .. ".pc",
          name = name ~= "" and name or model, value = value,
        }
      end
    end
  end)
  if #catalog == 0 then
    for _, f in ipairs(USED_FALLBACK) do
      catalog[#catalog + 1] = { model = f.model, config = nil, name = f.name, value = f.value }
    end
  end
  return catalog
end

-- pick from cheap / mid / pricey bands so there's always something to aim for
local BANDS = { { 0, 12000 }, { 0, 12000 }, { 12000, 30000 }, { 12000, 30000 }, { 30000, 1e9 }, { 0, 1e9 } }

local function makeListing(band)
  local cat = buildCatalog()
  local pool = {}
  for _, c in ipairs(cat) do
    if c.value >= band[1] and c.value < band[2] then pool[#pool + 1] = c end
  end
  if #pool == 0 then pool = cat end
  local c = pool[math.random(#pool)]
  local lot = G().usedLot
  local miles = math.floor((15000 + math.random() * 225000) / 100) * 100
  local wear = clamp(1 - miles / 320000, 0.3, 0.92)
  local value = math.floor(c.value * wear)
  local bill = 0
  if math.random() < 0.4 then bill = math.floor(value * (0.06 + math.random() * 0.22)) end
  -- dealer pricing: marked up, a little off for needing work, ends in 95
  local price = value * USED_MARKUP - bill * 0.5
  price = math.max(495, math.floor(price / 100) * 100 + 95)
  local l = {
    id = lot.nextId, model = c.model, config = c.config, name = c.name,
    miles = miles, value = value, bill = bill, price = price,
    seller = SELLERS[math.random(#SELLERS)],
  }
  lot.nextId = lot.nextId + 1
  return l
end

local function restockLot(full)
  local g = G()
  g.usedLot = g.usedLot or { listings = {}, jobsSince = 0, nextId = 1 }
  local lot = g.usedLot
  if full then lot.listings = {} end
  local i = #lot.listings
  while #lot.listings < USED_STOCK do
    i = i + 1
    lot.listings[#lot.listings + 1] = makeListing(BANDS[((i - 1) % #BANDS) + 1])
  end
  table.sort(lot.listings, function(a, b) return a.price < b.price end)
  lot.jobsSince = 0
end

function M.testDriveUsed(id)
  if core() and core().allowJump then core().allowJump(15) end
  if jobVeh() then msg(jobVeh().kind == "rentcar" and "Return your rental car first (Garage)." or "Finish your job first: you're in a job vehicle.") return end
  if not core().isRunning() then return end
  if pendingBuy then msg("Finish with the car you're test-driving first.") return end
  local lot = G().usedLot
  local l = nil
  for _, x in ipairs(lot and lot.listings or {}) do if x.id == id then l = x end end
  if not l then msg("That car just sold.") return end
  local v = getVeh()
  if v and speedOf(v) > 2 then msg("Stop before going car shopping.") return end
  M.storeActiveCarState()
  usedTest = l
  shopping = true
  shopSpawns = {}
  applyLock()
  local opts = {}
  if l.config then opts.config = l.config end
  local ok, err = pcall(function()
    if getVeh() then core_vehicles.replaceVehicle(l.model, opts) else core_vehicles.spawnNewVehicle(l.model, opts) end
  end)
  if not ok then
    usedTest, shopping = nil, false
    applyLock()
    log("E", "earthCareer", "Used car spawn failed: " .. tostring(err))
    msg("The seller couldn't bring that car around. Try another.", 6)
    if activeCar() then spawnCar(activeCar()) end
    return
  end
  msg("Test-driving the " .. l.name .. " from " .. l.seller .. ".", 5)
  core().pushState()
end

function M.startShopping(kind)
  if core() and core().allowJump then core().allowJump(15) end
  if jobVeh() then msg(jobVeh().kind == "rentcar" and "Return your rental car first (Garage)." or "Finish your job first: you're in a job vehicle.") return end
  shopKind = (kind == "trailer") and "trailer" or "car"
  if not core().isRunning() then return end
  local v = getVeh()
  if v and speedOf(v) > 2 then msg("Stop before going car shopping.") return end
  M.storeActiveCarState()
  shopping = true
  shopSpawns = {}
  applyLock()
  openSelector()
  msg(shopKind == "trailer" and "Pick a trailer and use \"Spawn new\" (not Replace). You'll get the bill once it spawns."
      or "Pick a car in the vehicle selector. You'll get the bill once it spawns.", 8)
  core().pushState()
end

function M.reopenSelector() openSelector() end

-- a vehicle spawned while shopping just became the player's car
local function considerForPurchase(v)
  local vid = v:getID()
  local info = vehicleInfo(v)
  local car = activeCar()
  -- same car reloaded (Ctrl+R etc): not a purchase
  if car and vid == careerVehId and info.model == car.model and (info.config or "") == (car.config or "") then return end
  -- a previous test car that's no longer driven goes away
  if pendingBuy and pendingBuy.vid ~= vid then
    local old = objById(pendingBuy.vid)
    if old and old:getID() ~= careerVehId then deleteVeh(old) end
  end
  if vid == careerVehId then careerVehId = nil end   -- "Replace" swapped our car out
  if classOf(info.model) == "trailer" then
    local estimated = not info.price or info.price <= 0
    local listed = estimated and TRAILER_FALLBACK_PRICE or info.price
    pendingBuy = {
      vid = vid, model = info.model, config = info.config, name = info.name, trailer = true,
      price = math.floor(listed * NEW_MARKUP / 50 + 0.5) * 50, value = math.floor(listed), estimated = estimated,
    }
    -- back into the truck while deciding
    local ours = objById(careerVehId)
    if ours then pcall(function() be:enterVehicle(0, ours) end) end
  elseif usedTest then
    local l = usedTest
    usedTest = nil
    pendingBuy = {
      vid = vid, model = l.model, config = l.config, name = l.name,
      price = l.price, value = l.value, listing = l,
    }
  else
    local estimated = not info.price or info.price <= 0
    local listed = estimated and FALLBACK_PRICE or info.price
    pendingBuy = {
      vid = vid, model = info.model, config = info.config, name = info.name,
      price = math.floor(listed * NEW_MARKUP / 50 + 0.5) * 50, value = math.floor(listed), estimated = estimated,
    }
  end
  shopping = false
  applyLock()
  core().pushState()
end

local function tradeInValue(car)
  if not car then return 0 end
  return math.max(0, math.floor(car.value * SELL_RATIO) - (car.bill or 0))
end

local function buyTrailer(p)
  if not core().spend(p.price) then msg("You can't afford this trailer. Revert, or earn more first.") return end
  local g = G()
  g.trailers = g.trailers or {}
  g.nextTrailerId = (g.nextTrailerId or 1)
  local t = { id = g.nextTrailerId, model = p.model, config = p.config, name = p.name, value = p.value or p.price,
              boughtAt = os.date("%Y-%m-%d") }
  g.nextTrailerId = g.nextTrailerId + 1
  g.trailers[#g.trailers + 1] = t
  trailerObjs[t.id] = p.vid
  pendingBuy, shopping, shopSpawns = nil, false, {}
  -- make sure we're in our truck (if "Replace" was used, bring it back next to the trailer)
  local ours = objById(careerVehId)
  if ours then pcall(function() be:enterVehicle(0, ours) end)
  elseif activeCar() then spawnCar(activeCar(), true) end
  applyLock()
  msg(string.format("Bought the %s for $%d! Back up to it and press L to hitch.", t.name, p.price), 8)
  core().writeSave(); core().pushState()
end

function M.buyPending(tradeIn)
  local p = pendingBuy
  if not p then return end
  if p.trailer then buyTrailer(p) return end
  local v = getVeh()
  if not v or v:getID() ~= p.vid then msg("Get back in the car you want to buy.") return end
  local old = activeCar()
  local credit = (tradeIn and old) and tradeInValue(old) or 0
  local cost = math.max(0, p.price - credit)
  if not core().spend(cost) then msg("You can't afford it. Revert, or earn more first.") return end
  M.storeActiveCarState()
  -- the old car goes back to the garage (or to the dealer, on a trade-in)
  local oldObj = objById(careerVehId)
  if oldObj and oldObj:getID() ~= p.vid then deleteVeh(oldObj) end
  if tradeIn and old then
    local _, idx = carById(old.id)
    table.remove(G().cars, idx)
  end
  local car = newCar(p.model, p.config, p.name, p.value or p.price)
  G().activeId = car.id
  if p.listing then
    -- used: comes with its miles and any existing repair bill
    car.odoKm = p.listing.miles * 1.609344
    car.bill = p.listing.bill or 0
    car.used = true
    local lot = G().usedLot
    for i, l in ipairs(lot.listings) do
      if l.id == p.listing.id then table.remove(lot.listings, i) break end
    end
  end
  -- adopt the spawned car as the career car
  careerVehId = p.vid
  liveCost, crash, pendingParts, fuel, lastFuelRatio = 0, nil, nil, nil, nil
  local cfg = getCurrentConfig()
  if cfg then car.parts = cfg.parts end
  pendingBuy = nil
  applyLock()
  if tradeIn and old then
    msg(string.format("Bought the %s for $%d after trading in your %s.", car.name, cost, old.name), 7)
  else
    msg(string.format("Bought the %s for $%d! Your old car is in your garage.", car.name, cost), 7)
  end
  core().writeSave(); core().pushState()
end

function M.revertPending()
  if core() and core().allowJump then core().allowJump(15) end
  local p = pendingBuy
  pendingBuy, shopping, shopSpawns, usedTest = nil, false, {}, nil
  local car = activeCar()
  local ours = objById(careerVehId)
  if ours and p then
    deleteVeh(objById(p.vid))
    pcall(function() be:enterVehicle(0, ours) end)
  elseif car then
    spawnCar(car)   -- replaces the test car with yours
  end
  applyLock()
  msg("Back in your own car.", 4)
  core().pushState()
end

function M.stopShopping()
  if pendingBuy then M.revertPending() return end
  shopping, shopSpawns = false, {}
  applyLock()
  core().pushState()
end

function M.driveCar(id)
  if jobVeh() then msg(jobVeh().kind == "rentcar" and "Return your rental car first (Garage)." or "Finish your job first: you're in a job vehicle.") return end
  local car = carById(id)
  if not car then return end
  local v = getVeh()
  if v and speedOf(v) > 2 then msg("Stop before switching cars.") return end
  M.storeActiveCarState()
  G().activeId = car.id
  spawnCar(car)
  core().writeSave(); core().pushState()
end

function M.sellCar(id)
  local car, idx = carById(id)
  if not car then return end
  if car.id == G().activeId then msg("You can't sell the car you're using. Switch cars first.") return end
  local price = math.max(0, math.floor(car.value * SELL_RATIO) - (car.bill or 0))
  core().earn(price)
  table.remove(G().cars, idx)
  msg(string.format("Sold %s for $%d.", car.name, price), 6)
  core().writeSave(); core().pushState()
end

-- a dealer/job vehicle from before the fleet fix may use a player-saved config: use a stock one of that model
local function cleanFleetVehicle(jv)
  if not jv or jv.kind == "rentcar" or not jv.config then return end
  local cfg = tostring(jv.config):lower()
  if not (cfg:find("/custom") or cfg:find("earthcareer_car")) then return end
  local swap = nil
  for _, kind in ipairs({ "car", "bus", "semi" }) do
    for _, o in ipairs(M.rentalOptions(kind)) do if o.model == jv.model then swap = o break end end
    if swap then break end
  end
  log("I", "earthCareer", "Dealer vehicle config " .. tostring(jv.config) .. " -> " .. tostring(swap and swap.config or "stock default"))
  jv.config = swap and swap.config or nil
end

function M.spawnMyCar()
  local jv = jobVeh()
  if jv then
    cleanFleetVehicle(jv)
    local v = getVeh()
    if v and speedOf(v) > 2 then msg("Stop first.") return end
    careerVehId, jobTrailerVid = nil, (jobTrailerVid and objById(jobTrailerVid)) and jobTrailerVid or nil
    spawnCar(jv)
    return
  end
  local car = activeCar()
  if not car then msg("You don't own a car. Visit the Dealership.") return end
  local v = getVeh()
  if v and speedOf(v) > 2 then msg("Stop first.") return end
  M.storeActiveCarState()
  spawnCar(car)
end

-- ---------------------------------------------------------------------------
-- Owned trailers
-- ---------------------------------------------------------------------------
local function trailerById(id)
  for i, t in ipairs(G().trailers or {}) do if t.id == id then return t, i end end
  return nil
end

local function trailerOut(id)
  local oid = trailerObjs[id]
  return oid ~= nil and objById(oid) ~= nil
end

function M.spawnTrailer(id)
  local t = trailerById(id)
  if not t then return end
  if not inCareerCar() then msg("Get in your truck first.") return end
  local v = getVeh()
  if speedOf(v) > 1 then msg("Stop first.") return end
  if trailerOut(id) then deleteVeh(objById(trailerObjs[id])) end
  local oid = spawnTrailerBehind(t.model, t.config, v)
  if not oid then msg("Couldn't spawn the trailer. Check the console.", 6) return end
  trailerObjs[id] = oid
  msg("Your " .. t.name .. " is behind you. Back up and press L to hitch.", 7)
  core().pushState()
end

function M.storeTrailer(id)
  if trailerOut(id) then deleteVeh(objById(trailerObjs[id])) end
  trailerObjs[id] = nil
  core().pushState()
end

function M.sellTrailer(id)
  local t, idx = trailerById(id)
  if not t then return end
  M.storeTrailer(id)
  local price = math.floor(t.value * SELL_RATIO)
  core().earn(price)
  table.remove(G().trailers, idx)
  msg(string.format("Sold the %s for $%d.", t.name, price), 6)
  core().writeSave(); core().pushState()
end

-- ---------------------------------------------------------------------------
-- Hitch detection (BeamNG fires onCouplerAttached / onCouplerDetached)
-- ---------------------------------------------------------------------------
local function link(a, b, on)
  if not (a and b) then return end
  couplings[a] = couplings[a] or {}
  couplings[b] = couplings[b] or {}
  couplings[a][b] = on or nil
  couplings[b][a] = on or nil
end

function M.onCouplerAttached(objId1, objId2) link(objId1, objId2, true) end
function M.onCouplerDetached(objId1, objId2) link(objId1, objId2, false) end

-- is a trailer hitched to the vehicle you're driving?
function M.trailerHitched()
  local v = getVeh()
  if not v then return false end
  local vid = v:getID()
  for other in pairs(couplings[vid] or {}) do
    local o = objById(other)
    if o and isTrailerObj(o) then return true end
  end
  -- fallback: the game's own trailer bookkeeping
  local hitched = false
  pcall(function()
    local d = core_trailerRespawn and core_trailerRespawn.getTrailerData and core_trailerRespawn.getTrailerData()
    local e = d and d[vid]
    if type(e) == "table" and (e.trailerId or e.id) then hitched = true end
  end)
  return hitched
end

-- rent just a trailer for your own semi (removed again by endJobTrailer)
function M.startJobTrailer(model, config)
  local v = getVeh()
  if not v then return false end
  if jobTrailerVid then deleteVeh(objById(jobTrailerVid)) end
  jobTrailerVid = spawnTrailerBehind(model, config, v)
  G().jobTrailer = { model = model, config = config }   -- saved: comes back after a quit / resume
  if jobTrailerVid then msg("Your rental trailer is behind you. Back up and press L to hitch.", 7) end
  return jobTrailerVid ~= nil
end

function M.endJobTrailer()
  if jobTrailerVid then deleteVeh(objById(jobTrailerVid)) end
  jobTrailerVid = nil
  G().jobTrailer = nil
end

function M.ownsTrailer() return #(G().trailers or {}) > 0 end

-- ---------------------------------------------------------------------------
-- Cargo boxes: courier and bed HotShot jobs need cargo-box parts on the vehicle
-- (BeamNG's cargo_load_box_* parts and the like). Counted from the parts list.
-- ---------------------------------------------------------------------------
local boxCache = { t = -100, n = 0, vid = nil }
function M.cargoBoxes()
  local v = getVeh()
  if not v then return 0 end
  if boxCache.vid == v:getID() and clock - boxCache.t < 1.5 then return boxCache.n end
  local n = 0
  local cfg = getCurrentConfig()
  if cfg and cfg.parts then
    for slot, part in pairs(cfg.parts) do
      local p = tostring(part or ""):lower()
      if p ~= "" and not p:find("floor") and (p:find("load_box") or p:find("cargo_box") or p:find("cargobox") or p:find("cargo_crate")) then
        -- "..._4M_..." style parts hold several boxes
        local multi = tonumber(p:match("_(%d)[smlx]+_")) or 1
        n = n + multi
      end
    end
  end
  boxCache = { t = clock, n = n, vid = v:getID() }
  return n
end

-- ---------------------------------------------------------------------------
-- Rental choices for jobs: the game's own semi / bus / trailer configs
-- ---------------------------------------------------------------------------
local rentalCatalog = nil   -- { stock = {kind -> list}, mods = {kind -> list} }

-- up to n entries spread across the price range
local function spread(b, n)
  table.sort(b, function(a, c) return a.value < c.value end)
  if #b <= n then return b end
  local keep = {}
  for i = 1, n do keep[i] = b[math.floor((i - 1) * (#b - 1) / (n - 1)) + 1] end
  return keep
end

local function buildRentalCatalog()
  if rentalCatalog then return rentalCatalog end
  local stock = { semi = {}, bus = {}, trailer = {}, car = {} }
  local mods  = { semi = {}, bus = {}, trailer = {}, car = {} }
  pcall(function()
    local list = core_vehicles.getConfigList()
    local configs = list and (list.configs or list) or {}
    for _, c in pairs(configs) do
      local model, key = c.model_key or c.model, c.key
      if model and key then
        local cls = classOf(model)
        local kind = (cls == "truck") and "car" or cls
        local ok = stock[kind] ~= nil
        local val = tonumber(c.Value or c.value) or 0
        if (cls == "car" or cls == "truck") and val < 3000 then ok = false end   -- dealers don't move junkers
        local label = table.concat({ tostring(c.Brand or ""), tostring(c.Name or ""), tostring(c.Configuration or "") }, " ")
        local lower = (label .. " " .. key):lower()
        -- never a config the player saved themselves (those can carry broken part combos)
        local src = tostring(c.Source or c.source or ""):lower()
        local playerMade = src:find("custom") ~= nil or key:lower() == "custom"
        local official = src:find("official") ~= nil
        if ok and not playerMade and not lower:find("police") and not lower:find("race") and not lower:find("derby") then
          local name = label:gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")
          if name == "" then name = model end
          local entry = { key = model .. "|" .. key, model = model, config = "vehicles/" .. model .. "/" .. key .. ".pc",
                          name = official and name or (name .. " · Mod"), mod = not official or nil, value = val }
          local t = official and stock[kind] or mods[kind]
          t[#t + 1] = entry
        end
      end
    end
  end)
  for kind in pairs(stock) do
    stock[kind] = spread(stock[kind], 14)
    mods[kind] = spread(mods[kind], 10)
  end
  rentalCatalog = { stock = stock, mods = mods }
  return rentalCatalog
end

local function modVehiclesOn()
  local s = core() and core().getSave()
  return not (s and s.settings and s.settings.modVehicles == false)
end

-- kind: "semi" | "bus" | "trailer" | "car"; each { key, model, config, name, value, mod }
-- stock configs first, then mod ones (Settings -> Mod vehicles in rentals)
function M.rentalOptions(kind)
  local cat = buildRentalCatalog()
  local st, md = cat.stock[kind] or {}, cat.mods[kind] or {}
  if #st > 0 and not modVehiclesOn() then return st end
  local out = {}
  for _, e in ipairs(st) do out[#out + 1] = e end
  for _, e in ipairs(md) do out[#out + 1] = e end
  return out
end

function M.rentalOption(kind, key)
  for _, o in ipairs(M.rentalOptions(kind)) do if o.key == key then return o end end
  return nil
end

-- ---------------------------------------------------------------------------
-- Rental cars (from the dealer bill): billed daily by the bank
-- ---------------------------------------------------------------------------
local RENT_PER_DAY_SHARE = 0.004   -- of the car's value, per career day
local RENT_MIN_PER_DAY   = 40

local function rentPerDay(value) return math.max(RENT_MIN_PER_DAY, math.floor((value or 10000) * RENT_PER_DAY_SHARE / 5 + 0.5) * 5) end

function M.rentPending()
  local p = pendingBuy
  if not p or p.trailer or p.listing then return end
  local v = getVeh()
  if not v or v:getID() ~= p.vid then msg("Get back in the car you want to rent.") return end
  if jobVeh() then msg("You already have a rental or job vehicle.") return end
  local perDay = rentPerDay(p.value or p.price)
  local bank = earthCareer_bank
  local contract = bank and bank.openRental(p.name, perDay)
  if not contract then msg("You need $" .. perDay .. " for the first day.") return end
  M.storeActiveCarState()
  -- your own car goes back to the garage; the rental becomes what you drive
  local oldObj = objById(careerVehId)
  if oldObj and oldObj:getID() ~= p.vid then deleteVeh(oldObj) end
  G().jobVehicle = { model = p.model, config = p.config, name = p.name, value = p.value or p.price,
                     kind = "rentcar", cls = classOf(p.model), cost = 0, perDay = perDay, contract = contract }
  careerVehId = p.vid
  liveCost, crash, pendingParts, fuel, lastFuelRatio = 0, nil, nil, nil, nil
  pendingBuy, shopping, shopSpawns = nil, false, {}
  applyLock()
  msg(string.format("Rented the %s: $%d/day. Return it from the Garage any time.", p.name, perDay), 8)
  core().writeSave(); core().pushState()
end

-- forced = repossessed by the bank
function M.returnRental(forced)
  local jv = jobVeh()
  if not jv or jv.kind ~= "rentcar" then return end
  local v = getVeh()
  if not forced and v and speedOf(v) > 2 then msg("Stop first to return the rental.") return end
  local dmg = math.floor(jv.cost or 0)
  if earthCareer_bank then earthCareer_bank.closeRental(jv.contract) end
  G().jobVehicle = nil
  if dmg > 0 then
    if core().spend(dmg) then msg("Rental returned. Damage charge: $" .. dmg .. ".", 6)
    elseif earthCareer_bank then earthCareer_bank.addOverdue(dmg, "rental damage") end
  elseif not forced then
    msg("Rental returned. Thanks for driving with us!", 5)
  end
  local car = activeCar()
  if car then spawnCar(car) end
  core().writeSave(); core().pushState()
end

-- ---------------------------------------------------------------------------
-- Job vehicles (rentals and dealer-provided buses), used by jobs.lua
-- ---------------------------------------------------------------------------
function M.startJobVehicle(spec)
  M.storeActiveCarState()
  G().jobVehicle = { model = spec.model, config = spec.config, name = spec.name, value = spec.value or 50000,
                     kind = spec.kind, cls = spec.cls, cost = 0, trailer = spec.trailer, trailerConfig = spec.trailerConfig }
  crash, pendingParts = nil, nil
  spawnCar(G().jobVehicle)
  applyLock()
end

-- returns the damage cost run up in the job vehicle
function M.endJobVehicle()
  local jv = jobVeh()
  if not jv then return 0 end
  local cost = math.floor(jv.cost or 0)
  if jobTrailerVid then deleteVeh(objById(jobTrailerVid)) end
  jobTrailerVid = nil
  G().jobVehicle = nil
  local car = activeCar()
  if car then spawnCar(car) end
  msg(car and ("Job vehicle returned. Your " .. car.name .. " is here.") or "Job vehicle returned.", 5)
  return cost
end

function M.isRentingCar() local jv = jobVeh(); return jv ~= nil and jv.kind == "rentcar" end

function M.currentClass()
  local jv = jobVeh()
  if jv and inCareerCar() then return jv.cls or "car" end
  local v = getVeh()
  local model = nil
  if v then pcall(function() model = v:getJBeamFilename() end) end
  if not model then local car = activeCar(); model = car and car.model end
  return classOf(model)
end

function M.damageMeter()
  local g = G()
  return g and g.damageMeter or 0
end

-- can the player take jobs right now?
function M.canWork()
  local car = activeCar()
  if lockOn() then
    if not car then return false, "You need a car. Buy one in the Garage." end
    if isTotaled(car) then return false, "Your car is totaled. Repair, claim or replace it in the Garage." end
    if pendingParts then return false, "Pay for or revert your parts changes first." end
    if pendingBuy or shopping then return false, "Finish shopping for a car first." end
  end
  return true
end

-- ---------------------------------------------------------------------------
-- Hooks from main.lua
-- ---------------------------------------------------------------------------
function M.onCareerStarted()
  local g = G()
  if #g.cars == 0 then giveStarterCar() end
  applyLock()
  spawnCar(activeCar())
end

function M.onCareerResumed()
  applyLock()
  local jv = jobVeh()
  cleanFleetVehicle(jv)
  if not inCareerCar() and (lockOn() or jv) then
    -- what you were last driving for work comes back: a rental, the dealer's vehicle, or your own car
    careerVehId, jobTrailerVid = nil, nil
    spawnCar(jv or activeCar())
    if jv then
      msg((jv.kind == "rentcar" and "Your rental " or (jv.kind == "rental" and "Your rental " or "The dealer's ")) .. jv.name .. " is back.", 6)
    end
  end
end

function M.onCareerPaused()
  M.storeActiveCarState()
  shopping, pendingBuy, shopSpawns = false, nil, {}
  setActionGroups(false, false)
  lockApplied = nil
end

function M.onCareerReset()
  careerVehId, crash, pendingParts, fuel = nil, nil, nil, nil
  jobTrailerVid = nil
  shopping, pendingBuy, shopSpawns = false, nil, {}
  setActionGroups(false, false)
  lockApplied = nil
end

function M.onSettingChanged(key)
  if key == "vehicleLock" then
    applyLock()
    if lockOn() and not inCareerCar() then spawnCar(activeCar()) end
  end
end

function M.onJobCompleted()
  local lot = G().usedLot
  if lot then
    lot.jobsSince = (lot.jobsSince or 0) + 1
    if lot.jobsSince >= RESTOCK_JOBS then
      restockLot(true)
      msg("New cars just landed on the used lot.", 5)
    end
  end
  local ins = G().insurance
  ins.cleanJobs = ins.cleanJobs + 1
  if ins.claims > 0 and ins.cleanJobs >= CLEAN_JOBS_PER_CLAIM then
    ins.claims = ins.claims - 1
    ins.cleanJobs = 0
    msg("Clean driving! Your insurance deductible went down.", 6)
  end
end

-- ---------------------------------------------------------------------------
-- Data coming back from the car
-- ---------------------------------------------------------------------------
function M.onFuelData(vid, liters, cap, typ)
  if vid ~= careerVehId then return end
  if not cap or cap <= 0 then fuel = nil return end
  local ratio = clamp(liters / cap, 0, 1)
  if jobVeh() then
    -- rentals and dealer vehicles: the company pays for fuel
    fuel = { liters = liters, cap = cap, ratio = ratio, type = typ }
    return
  end
  if lastFuelRatio and fuelGrace <= 0 and ratio > lastFuelRatio + 0.02 then
    local v = getVeh()
    if clock - recentReset < 6 then
      -- a reset/reload refilled the tank: put it back where it was
      if v and v:getID() == vid then setFuelRatio(v, lastFuelRatio) end
      return
    end
    -- a real fill-up at one of BeamNG.Earth's gas stations: bill it at pump price
    local electric = typ == "electricEnergy"
    local added = (ratio - lastFuelRatio) * cap
    local unitPrice = FUEL_PRICE[typ] or FUEL_PRICE.gasoline
    local cost = math.ceil(electric and added * unitPrice or added / L_PER_GAL * unitPrice)
    if core().spend(cost) then
      msg(string.format("Paid $%d at the pump (%.1f %s).", cost, electric and added or added / L_PER_GAL, electric and "kWh" or "gal"), 5)
      core().writeSave()
    else
      if v and v:getID() == vid then setFuelRatio(v, lastFuelRatio) end
      msg("Card declined at the pump: you can't afford that much fuel.", 6)
      return
    end
  end
  fuel = { liters = liters, cap = cap, ratio = ratio, type = typ }
  if fuelGrace <= 0 then lastFuelRatio = ratio end
  local car = activeCar()
  if car then car.fuelRatio = ratio end
  if ratio < 0.05 and lowFuelWarned < 2 then
    lowFuelWarned = 2; msg("You're nearly out of fuel! Refuel in the Garage tab.", 8)
  elseif ratio < 0.15 and lowFuelWarned < 1 then
    lowFuelWarned = 1; msg("Fuel is getting low.", 5)
  elseif ratio > 0.2 then
    lowFuelWarned = 0
  end
end

local function readDamage(v)
  local d = 0
  pcall(function()
    local o = map.objects and map.objects[v:getID()]
    if o and o.damage then d = o.damage end
  end)
  return d
end

local function updateJobDamage(v, jv)
  local cost = costFromDamage(readDamage(v), jv.value)
  if cost > liveCost then
    local inc = cost - liveCost
    jv.cost = (jv.cost or 0) + inc
    G().damageMeter = (G().damageMeter or 0) + inc
  elseif cost < liveCost - 20 then
    recentReset = clock
  end
  liveCost = cost
end

local function updateDamage(v, car)
  local cost = costFromDamage(readDamage(v), car.value)
  if cost < liveCost - 20 then recentReset = clock end
  if cost > liveCost then
    local inc = cost - liveCost
    car.bill = (car.bill or 0) + inc
    G().damageMeter = (G().damageMeter or 0) + inc
    local s = S()
    if crash and (crash.shown or (clock - crash.t) < 4) then
      crash.cost = crash.cost + inc
      crash.t = clock
    elseif inc > 5 then
      crash = { cost = inc, t = clock, shown = false }
    end
    if crash and crash.cost >= CRASH_MIN and s.settings.crashPopups then crash.shown = true end
  end
  liveCost = cost   -- a reset drops this back to 0 without touching the bill
end

local function updateParts(car)
  if not car.parts then return end
  local cfg = getCurrentConfig()
  if not cfg then return end
  local changes = diffParts(car.parts, cfg.parts)
  if #changes == 0 then pendingParts = nil return end
  local cost, list = 0, {}
  for _, ch in ipairs(changes) do
    local price = 0
    if ch.to ~= "" then price = partPrice(ch.slot, ch.to, car.value) end
    cost = cost + price
    list[#list + 1] = { slot = prettySlot(ch.slot, car.model), removed = ch.to == "", price = price }
  end
  if cost == 0 then
    -- only removals: free, accept straight away
    car.parts = cfg.parts
    saveCarConfig(car, cfg)
    pendingParts = nil
    core().writeSave()
    return
  end
  table.sort(list, function(a, b) return a.price > b.price end)
  pendingParts = { cost = cost, changes = list, parts = cfg.parts, vars = cfg.vars, mainPartName = cfg.mainPartName }
end

-- ---------------------------------------------------------------------------
-- UI state
-- ---------------------------------------------------------------------------
function M.buildState()
  local g = G()
  if not g then return nil end
  local s = S()
  local car = activeCar()
  local carState = nil
  if car then
    local ded = deductible(car)
    carState = {
      id = car.id, name = car.name, model = car.model, value = car.value,
      odoKm = math.floor((car.odoKm or 0) * 10 + 0.5) / 10,
      bill = car.bill or 0,
      condition = clamp(1 - (car.bill or 0) / math.max(1, car.value), 0, 1),
      totaled = isTotaled(car),
      deductible = ded,
      claimWorthIt = isTotaled(car) or ded < (car.bill or 0),
      payout = math.max(0, car.value - ded),
      scrapValue = math.floor(car.value * SCRAP_RATIO),
      tradeIn = math.max(0, math.floor(car.value * SELL_RATIO) - (car.bill or 0)),
    }
  end

  local fuelState = nil
  if fuel and inCareerCar() then
    local electric = fuel.type == "electricEnergy"
    local unitPrice = FUEL_PRICE[fuel.type] or FUEL_PRICE.gasoline
    local missing = math.max(0, fuel.cap - fuel.liters)
    local fee = atHome() and 0 or SERVICE_FEE
    local fillCost = (electric and missing * unitPrice or missing / L_PER_GAL * unitPrice)
    local addAmt = electric and math.min(missing, 50) or math.min(missing, 5 * L_PER_GAL)
    local addCost = (electric and addAmt * unitPrice or addAmt / L_PER_GAL * unitPrice)
    fuelState = {
      ratio = fuel.ratio, electric = electric,
      amount = electric and fuel.liters or fuel.liters / L_PER_GAL,
      capacity = electric and fuel.cap or fuel.cap / L_PER_GAL,
      unit = electric and "kWh" or "gal",
      unitPrice = unitPrice,
      fillCost = missing > 0.05 and math.ceil(fillCost + fee) or 0,
      addCost = missing > 0.05 and math.ceil(addCost + fee) or 0,
      addLabel = electric and "+50 kWh" or "+5 gal",
      fee = fee, atHome = fee == 0,
    }
  end

  local cars = {}
  for _, c in ipairs(g.cars) do
    cars[#cars + 1] = {
      id = c.id, name = c.name, value = c.value, bill = c.bill or 0,
      active = c.id == g.activeId, totaled = isTotaled(c),
      sellPrice = math.max(0, math.floor(c.value * SELL_RATIO) - (c.bill or 0)),
    }
  end

  local buy = nil
  if pendingBuy then
    local credit = tradeInValue(car)
    local v = getVeh()
    buy = {
      name = pendingBuy.name, price = pendingBuy.price, estimated = pendingBuy.estimated,
      affordable = s.money >= pendingBuy.price,
      tradeIn = car and credit or nil, tradeInName = car and car.name or nil,
      tradeCost = math.max(0, pendingBuy.price - credit),
      tradeAffordable = s.money >= math.max(0, pendingBuy.price - credit),
      inIt = pendingBuy.trailer or (v ~= nil and v:getID() == pendingBuy.vid),
      trailer = pendingBuy.trailer,
      oldName = car and car.name or nil,
      used = pendingBuy.listing ~= nil,
      miles = pendingBuy.listing and pendingBuy.listing.miles or nil,
      bill = pendingBuy.listing and pendingBuy.listing.bill or 0,
      seller = pendingBuy.listing and pendingBuy.listing.seller or nil,
      worth = pendingBuy.value,
      rentPerDay = (not pendingBuy.trailer and not pendingBuy.listing) and rentPerDay(pendingBuy.value or pendingBuy.price) or nil,
    }
  end

  if not g.usedLot or #g.usedLot.listings == 0 then restockLot(true) end
  local used = {}
  for _, l in ipairs(g.usedLot.listings) do
    used[#used + 1] = {
      id = l.id, name = l.name, miles = l.miles, price = l.price, bill = l.bill or 0,
      seller = l.seller, affordable = s.money >= l.price,
    }
  end

  local crashState = nil
  if crash and crash.shown and car then
    local tot = isTotaled(car)
    -- a total loss asks first whether it was your driving or a map glitch
    crashState = { cost = crash.cost, bill = car.bill, totaled = tot, askCause = (tot and not crash.cause) or nil }
  end

  return {
    lock = s.settings.vehicleLock,
    inCareerCar = inCareerCar(),
    spawning = spawning,
    car = carState,
    fuel = fuelState,
    cars = cars,
    shopping = shopping,
    trailers = (function()
      local out = {}
      for _, t in ipairs(G().trailers or {}) do
        out[#out + 1] = { id = t.id, name = t.name, value = t.value, out = trailerOut(t.id),
                          sellPrice = math.floor(t.value * SELL_RATIO) }
      end
      return out
    end)(),
    shopKind = shopKind,
    jobVehicle = jobVeh() and { name = jobVeh().name, kind = jobVeh().kind, cost = math.floor(jobVeh().cost or 0), perDay = jobVeh().perDay } or nil,
    cargoBoxes = M.cargoBoxes(),
    vehicleClass = M.currentClass(),
    used = used,
    restockIn = math.max(0, RESTOCK_JOBS - (g.usedLot.jobsSince or 0)),
    newMarkup = math.floor((NEW_MARKUP - 1) * 100 + 0.5),
    usedMarkup = math.floor((USED_MARKUP - 1) * 100 + 0.5),
    buy = buy,
    insurance = { claims = g.insurance.claims, cleanJobs = g.insurance.cleanJobs, cleanNeeded = CLEAN_JOBS_PER_CLAIM },
    crash = crashState,
    parts = pendingParts and { cost = pendingParts.cost, changes = pendingParts.changes } or nil,
    recoveryFee = RECOVERY_FEE,
    serviceFee = SERVICE_FEE,
  }
end

-- ---------------------------------------------------------------------------
-- Game hooks
-- ---------------------------------------------------------------------------
function M.onClientPostStartMission()
  couplings = {}
  careerVehId = nil
  spawning = false
  mapGrace = 4
  fuel = nil
  lockApplied = nil
end

-- the career car got respawned without us (Ctrl+R, parts change, etc)
function M.onVehicleSpawned(vid)
  if isWalker(objById(vid)) then return end   -- getting out to walk isn't buying a unicycle
  if (shopping or pendingBuy) and not spawning then
    shopSpawns[vid] = clock
    return
  end
  if vid == careerVehId and not spawning then
    recentReset = clock
    liveCost = 0
    fuelGrace = 0
    settleTimer = 1.5
  end
end

function M.onUpdate(dtReal, dtSim, dtRaw)
  processDeletes()
  if not (core() and S()) then return end
  clock = clock + dtReal
  if mapGrace > 0 then mapGrace = mapGrace - dtReal end
  if fuelGrace > 0 then fuelGrace = fuelGrace - dtReal end

  -- fallback repair: put the car back where it was after the reset
  if M._restorePose then
    M._restorePose.t = M._restorePose.t - dtReal
    if M._restorePose.t <= 0 then
      local rp, v = M._restorePose, getVeh()
      M._restorePose = nil
      if v then
        pcall(function()
          if rp.rot then v:setPositionRotation(rp.pos.x, rp.pos.y, rp.pos.z, rp.rot.x, rp.rot.y, rp.rot.z, rp.rot.w)
          else v:setPosition(rp.pos) end
        end)
      end
    end
  end

  if M._afterReset then
    M._afterReset.t = M._afterReset.t - dtReal
    if M._afterReset.t <= 0 then
      local v = getVeh()
      if v and inCareerCar() then setFuelRatio(v, M._afterReset.ratio) end
      M._afterReset = nil
    end
  end

  if not core().isRunning() then return end
  applyLock()

  -- careers started before the garage existed get their starter car here
  local g = G()
  if g.needsStarter and mapGrace <= 0 and getVeh() and not spawning then
    g.needsStarter = nil
    if #g.cars == 0 then giveStarterCar() end
    msg("Your starter car is here: a well-loved Soliad Wendover. Treat her nice.", 7)
    spawnCar(activeCar())
    core().writeSave()
    return
  end

  -- car shopping: once a freshly spawned car is the player's, show the bill
  if shopping or pendingBuy then
    local v = getVeh()
    for vid, t in pairs(shopSpawns) do
      if clock - t > 1.0 then
        shopSpawns[vid] = nil
        if not (pendingBuy and pendingBuy.vid == vid) then
          if v and v:getID() == vid then considerForPurchase(v)
          else
            -- trailers may spawn without the player getting in them
            local o = objById(vid)
            if o and isTrailerObj(o) then considerForPurchase(o) end
          end
        end
      end
    end
  end

  if settleTimer > 0 then
    settleTimer = settleTimer - dtReal
    if settleTimer <= 0 then
      if spawning then onCareerCarReady()
      elseif inCareerCar() then
        local car = activeCar()
        if car and lastFuelRatio then setFuelRatio(getVeh(), lastFuelRatio) end
      end
    end
    return
  end

  local v = getVeh()
  local car = activeCar()

  local jv = jobVeh()
  if jv then car = nil end   -- in a job vehicle: your own car isn't being driven

  -- odometer
  if v and car and inCareerCar() then
    local sp = speedOf(v)
    if sp > 0.5 and sp < 120 then car.odoKm = (car.odoKm or 0) + sp * dtSim / 1000 end
  end

  -- damage, every frame-ish (cheap)
  if v and car and inCareerCar() then updateDamage(v, car) end
  if v and jv and inCareerCar() then updateJobDamage(v, jv) end

  tick1 = tick1 + dtReal
  if tick1 >= 1 then
    tick1 = 0
    if v and inCareerCar() then queryFuel(v) end
  end

  tick2 = tick2 + dtReal
  if tick2 >= 2 then
    tick2 = 0
    if v and car and inCareerCar() then updateParts(car) end
  end

  tickLock = tickLock + dtReal
  if tickLock >= 0.5 then
    tickLock = 0
    enforceLock()
  end
end

return M
