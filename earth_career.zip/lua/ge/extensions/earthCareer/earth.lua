-- ============================================================================
-- Earth Career  -  BeamNG.Earth adapter
-- The ONLY place that talks to BeamNG.Earth. Read-only except for the GPS
-- destination. Every call is wrapped so an Earth update can't crash the career.
--
-- BeamNG.Earth (github.com/TecnaGamer/BeamNG.Earth) keeps a floating origin:
-- the world is re-centred ("rebased") as you drive, so game coordinates are
-- only good for a moment. Everything the career stores is latitude/longitude.
-- ============================================================================

local M = {}

local EARTH_R_MI = 3958.8

local function core() return rawget(_G, "beamngEarth_core") end
local function mod(name) return package.loaded["beamngEarth/" .. name] end

local function state()
  local c = core()
  if type(c) ~= "table" or type(c._state) ~= "function" then return nil end
  local ok, st = pcall(c._state)
  if ok and type(st) == "table" then return st end
  return nil
end

local function playerVeh()
  if be and be.getPlayerVehicle then return be:getPlayerVehicle(0) end
  if getPlayerVehicle then return getPlayerVehicle(0) end
  return nil
end

-- Is BeamNG.Earth loaded and running its level right now?
function M.available()
  local st = state()
  return st ~= nil and st.inOurLevel == true and type(st.anchor) == "table"
end

-- game position -> lat, lon
function M.toLatLon(pos)
  local st = state()
  if not (st and st.anchor and pos) then return nil end
  local ok, lat, lon = pcall(function() return st.anchor:enuToGeodetic(pos.x, pos.y, pos.z or 0) end)
  if ok and lat and lon and lat == lat and lon == lon then return lat, lon end
  return nil
end

-- lat, lon -> game x, y (z left to the caller); only valid until the next rebase
function M.toWorld(lat, lon)
  local st = state()
  if not (st and st.anchor and lat and lon) then return nil end
  local ok, x, y = pcall(function() return st.anchor:geodeticToEnu(lat, lon, 0) end)
  if ok and x and y then return x, y end
  return nil
end

-- the player's lat, lon (live vehicle position, else Earth's last known one)
function M.playerLatLon()
  local v = playerVeh()
  if v then
    local ok, pos = pcall(function() return v:getPosition() end)
    if ok and pos then
      local lat, lon = M.toLatLon(pos)
      if lat then return lat, lon end
    end
  end
  local st = state()
  local pl = st and st.player
  if pl and pl.lat and pl.lon then return pl.lat, pl.lon end
  return nil
end

-- { street, place, region, country } from Earth's status bar, or nil
function M.location()
  local sb = mod("statusbar")
  if type(sb) ~= "table" or type(sb.location) ~= "function" then return nil end
  local ok, loc = pcall(sb.location)
  if ok and type(loc) == "table" then return loc end
  return nil
end

-- Earth's GPS: plans the real road route on its server and drives the game's
-- route arrows the whole way, however far.
function M.gpsSet(lat, lon, name)
  local gps = mod("gps")
  if type(gps) ~= "table" or type(gps.setDestination) ~= "function" then return false end
  local ok, res = pcall(gps.setDestination, lat, lon, name)
  return ok and res ~= false
end

function M.gpsClear()
  local gps = mod("gps")
  if type(gps) == "table" and type(gps.clear) == "function" then pcall(gps.clear) end
end

-- { remaining (m), eta (s), planning, routeError, ... } or nil
function M.gpsStatus()
  local gps = mod("gps")
  if type(gps) ~= "table" or type(gps.status) ~= "function" then return nil end
  local ok, s = pcall(gps.status)
  if ok and type(s) == "table" then return s end
  return nil
end

-- Has Earth finished placing the player (no teleport/loading under way)?
function M.groundReady()
  local c = core()
  if type(c) ~= "table" or type(c.groundReady) ~= "function" then return M.available() end
  local ok, r = pcall(c.groundReady)
  return ok and r == true
end

-- Teleport through Earth's own "go to a place" (same checks as its map's Go button).
-- Returns ok, error message.
function M.teleport(lat, lon, name)
  local places = mod("places")
  if type(places) == "table" and type(places.goTo) == "function" then
    local ok, res, err = pcall(places.goTo, lat, lon, name)
    if ok then return res ~= false, err end
    return false, tostring(res)
  end
  local c = core()
  if type(c) == "table" and type(c.teleport) == "function" then
    local ok, res = pcall(c.teleport, lat, lon, name)
    return ok and res ~= false, (not ok) and tostring(res) or nil
  end
  return false, "BeamNG.Earth isn't loaded"
end

-- ---------------------------------------------------------------------------
-- Geometry
-- ---------------------------------------------------------------------------
function M.miles(lat1, lon1, lat2, lon2)
  local r = math.rad
  local dlat, dlon = r(lat2 - lat1), r(lon2 - lon1)
  local a = math.sin(dlat / 2) ^ 2 + math.cos(r(lat1)) * math.cos(r(lat2)) * math.sin(dlon / 2) ^ 2
  return 2 * EARTH_R_MI * math.asin(math.min(1, math.sqrt(a)))
end

-- lat/lon of a point `mi` miles from (lat, lon) toward `bearingDeg`
function M.offset(lat, lon, mi, bearingDeg)
  local d = mi / EARTH_R_MI
  local b = math.rad(bearingDeg)
  local la1, lo1 = math.rad(lat), math.rad(lon)
  local la2 = math.asin(math.sin(la1) * math.cos(d) + math.cos(la1) * math.sin(d) * math.cos(b))
  local lo2 = lo1 + math.atan2(math.sin(b) * math.sin(d) * math.cos(la1), math.cos(d) - math.sin(la1) * math.sin(la2))
  return math.deg(la2), math.deg(lo2)
end

-- ---------------------------------------------------------------------------
-- Towns (bundled): { name, st, lat, lon, pop } x ~30k US places
-- Data: kelvins/US-Cities-Database (MIT), populations of the 1,000 largest
-- from plotly/datasets.
-- ---------------------------------------------------------------------------
local towns = nil
local tgrid = nil        -- 1-degree cells: "lat:lon" -> { towns }, so lookups only touch nearby towns

function M.towns()
  if towns then return towns end
  towns = {}
  local ok, data = pcall(jsonReadFile, "/earthCareer/towns.json")
  if ok and type(data) == "table" then
    for _, t in ipairs(data) do
      towns[#towns + 1] = { name = t[1], st = t[2], lat = t[3], lon = t[4], pop = t[5] or 0 }
    end
  end
  tgrid = {}
  for _, t in ipairs(towns) do
    local k = math.floor(t.lat) .. ":" .. math.floor(t.lon)
    local c = tgrid[k]
    if not c then c = {}; tgrid[k] = c end
    c[#c + 1] = t
  end
  log("I", "earthCareer", "Loaded " .. #towns .. " towns")
  return towns
end

-- towns between minMi and maxMi of (lat, lon); quick box filter first
function M.townsWithin(lat, lon, minMi, maxMi, filter)
  local out = {}
  local all = M.towns()
  local dLat = maxMi / 69
  local dLon = math.min(180, maxMi / math.max(1, 69 * math.cos(math.rad(lat))))
  local function consider(t)
    if math.abs(t.lat - lat) <= dLat and math.abs(t.lon - lon) <= dLon and (not filter or filter(t)) then
      local d = M.miles(lat, lon, t.lat, t.lon)
      if d >= minMi and d <= maxMi then t._d = d; out[#out + 1] = t end
    end
  end
  local la0, la1 = math.floor(lat - dLat), math.floor(lat + dLat)
  local lo0, lo1 = math.floor(lon - dLon), math.floor(lon + dLon)
  if tgrid and (la1 - la0 + 1) * (lo1 - lo0 + 1) < 1500 then
    -- only the grid cells the search box touches
    for cy = la0, la1 do
      for cx = lo0, lo1 do
        local c = tgrid[cy .. ":" .. cx]
        if c then for i = 1, #c do consider(c[i]) end end
      end
    end
  else
    for i = 1, #all do consider(all[i]) end   -- coast-to-coast searches: everything anyway
  end
  return out
end

function M.nearestTown(lat, lon)
  local best, bestD = nil, math.huge
  for _, r in ipairs({ 15, 60, 300 }) do
    for _, t in ipairs(M.townsWithin(lat, lon, 0, r)) do
      if t._d < bestD then best, bestD = t, t._d end
    end
    if best then return best, bestD end
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- States (bundled): US Census state outlines (public domain, simplified to
-- ~300 m), so the state comes from your position, not Earth's location bar.
-- earthCareer/states.json: [ { n = name, st, p = { { b = {minLon,minLat,maxLon,maxLat}, r = { {lon,lat,...}, holes... } } } } ]
-- ---------------------------------------------------------------------------
local states = nil
local lastState = nil

local function inRing(r, x, y)
  local inside = false
  local n = #r
  local jx, jy = r[n - 1], r[n]
  for i = 1, n, 2 do
    local ix, iy = r[i], r[i + 1]
    if (iy > y) ~= (jy > y) and x < (jx - ix) * (y - iy) / (jy - iy) + ix then inside = not inside end
    jx, jy = ix, iy
  end
  return inside
end

local function inState(s, lon, lat)
  for _, p in ipairs(s.p) do
    local b = p.b
    if lon >= b[1] and lon <= b[3] and lat >= b[2] and lat <= b[4] and inRing(p.r[1], lon, lat) then
      local hole = false
      for h = 2, #p.r do if inRing(p.r[h], lon, lat) then hole = true break end end
      if not hole then return true end
    end
  end
  return false
end

-- the US state at (lat, lon): name, postal code; nil off the map (lakes, sea, abroad)
function M.stateAt(lat, lon)
  if not states then
    local ok, data = pcall(jsonReadFile, "/earthCareer/states.json")
    states = (ok and type(data) == "table") and data or {}
  end
  if not (lat and lon) then return nil end
  if lastState and inState(lastState, lon, lat) then return lastState.n, lastState.st end
  for _, s in ipairs(states) do
    if s ~= lastState and inState(s, lon, lat) then lastState = s; return s.n, s.st end
  end
  return nil
end

-- find a town by "Name, ST" or "Name" (used to migrate older saves)
function M.findTown(text)
  text = tostring(text or ""):lower()
  local name, st = text:match("^%s*(.-)%s*,%s*(%a%a)")
  name = name or text:gsub("^%s+", ""):gsub("%s+$", "")
  name = name:gsub("%s+township$", "")
  for _, t in ipairs(M.towns()) do
    if t.name:lower() == name and (not st or t.st:lower() == st) then return t end
  end
  return nil
end

return M
