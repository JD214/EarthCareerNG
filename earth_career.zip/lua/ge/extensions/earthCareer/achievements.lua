-- ============================================================================
-- Earth Career  -  achievements (Stats tab)
-- 25 achievements: distance, jobs, states, landmarks, career. Hidden ones show
-- "???" and a hint until unlocked. Each pays a little cash and XP.
-- Saved per profile in save.achievements = { unlocked = { id = date }, milesDriven }.
-- ============================================================================

local M = {}

-- reward tiers
local R = {
  easy     = { cash = 250,   xp = 50 },
  medium   = { cash = 1000,  xp = 200 },
  hard     = { cash = 5000,  xp = 800 },
  landmark = { cash = 750,   xp = 150 },
  legend   = { cash = 25000, xp = 3000 },
}

-- landmarks: lat, lon, radius (km) you need to drive within
local DEFS = {
  -- distance (miles you drive in career mode, any vehicle)
  { id = "first_mile",   group = "Distance", icon = "🛣️", name = "First Mile",     desc = "Drive 1 mile.",                stat = "miles", goal = 1,    reward = "easy" },
  { id = "road_tripper", group = "Distance", icon = "🗺️", name = "Road Tripper",   desc = "Drive 500 miles.",             stat = "miles", goal = 500,  reward = "medium" },
  { id = "iron_butt",    group = "Distance", icon = "🪑", name = "Iron Butt",      desc = "Drive 1,000 miles.",           stat = "miles", goal = 1000, reward = "medium" },
  { id = "long_hauler",  group = "Distance", icon = "🚚", name = "Long Hauler",    desc = "Drive 5,000 miles.",           stat = "miles", goal = 5000, reward = "hard" },

  -- jobs
  { id = "on_the_clock", group = "Jobs", icon = "📦", name = "On the Clock",       desc = "Complete your first job.",     stat = "jobs", goal = 1,  reward = "easy" },
  { id = "regular",      group = "Jobs", icon = "📋", name = "Regular",            desc = "Complete 25 jobs.",            stat = "jobs", goal = 25, reward = "medium" },
  { id = "hotshot",      group = "Jobs", icon = "🔥", name = "Hot Shot",           desc = "Deliver a HotShot load on a trailer.", event = true, reward = "medium" },
  { id = "big_rig",      group = "Jobs", icon = "🚛", name = "Big Rig",            desc = "Deliver a freight load.",      event = true, reward = "medium" },
  { id = "next_stop",    group = "Jobs", icon = "🚌", name = "Next Stop",          desc = "Finish a city bus or express route.", event = true, reward = "medium" },
  { id = "five_stars",   group = "Jobs", icon = "⭐", name = "Five Stars",         desc = "Finish a rideshare with 95%+ comfort.", event = true, reward = "medium",
    hidden = true, hint = "Your passengers barely noticed the ride." },
  { id = "coast2coast",  group = "Jobs", icon = "🌎", name = "Coast to Coast",     desc = "Complete a single 2,000+ mile delivery.", event = true, reward = "hard",
    hidden = true, hint = "One job. Two oceans." },
  { id = "beat_clock",   group = "Jobs", icon = "⏱️", name = "Beat the Clock",     desc = "Deliver an urgent job on time.", event = true, reward = "medium",
    hidden = true, hint = "Somebody needed it yesterday." },

  -- states
  { id = "state_line",   group = "States", icon = "🪧", name = "State Line",      desc = "Visit 2 states.",              stat = "states", goal = 2,  reward = "easy" },
  { id = "ten_states",   group = "States", icon = "🧭", name = "Ten-State Tour",  desc = "Visit 10 states.",             stat = "states", goal = 10, reward = "hard" },
  { id = "lower48",      group = "States", icon = "🇺🇸", name = "The Lower 48",   desc = "Visit all 48 contiguous states.", stat = "states48", goal = 48, reward = "legend" },

  -- landmarks
  { id = "golden_gate",  group = "Landmarks", icon = "🌉", name = "Golden Gate",          desc = "Cross the Golden Gate Bridge.",
    lat = 37.8199, lon = -122.4783, km = 1.5, hidden = true, hint = "Fog, cables and a famous shade of orange.", reward = "landmark" },
  { id = "hoover",       group = "Landmarks", icon = "🏞️", name = "Dam Good Drive",       desc = "Visit the Hoover Dam.",
    lat = 36.0161, lon = -114.7377, km = 1.5, hidden = true, hint = "Concrete holding back the Colorado.", reward = "landmark" },
  { id = "rushmore",     group = "Landmarks", icon = "🗿", name = "Faces in the Rock",    desc = "Visit Mount Rushmore.",
    lat = 43.8791, lon = -103.4591, km = 3.0, hidden = true, hint = "Four presidents in the Black Hills.", reward = "landmark" },
  { id = "gateway_arch", group = "Landmarks", icon = "🌈", name = "Gateway to the West",  desc = "Visit the Gateway Arch in St. Louis.",
    lat = 38.6247, lon = -90.1848, km = 1.5, hidden = true, hint = "630 feet of stainless steel on the Mississippi.", reward = "landmark" },
  { id = "times_sq",     group = "Landmarks", icon = "🗽", name = "The Big Apple",        desc = "Drive through Times Square.",
    lat = 40.7580, lon = -73.9855, km = 0.8, hidden = true, hint = "Bright lights, no parking.", reward = "landmark" },
  { id = "mackinac",     group = "Landmarks", icon = "🌁", name = "Mighty Mac",           desc = "Cross the Mackinac Bridge.",
    lat = 45.8172, lon = -84.7278, km = 2.5, hidden = true, hint = "Where the two peninsulas shake hands.", reward = "landmark" },
  { id = "key_west",     group = "Landmarks", icon = "🌴", name = "Southernmost",         desc = "Reach the Southernmost Point in Key West.",
    lat = 24.5465, lon = -81.7975, km = 1.0, hidden = true, hint = "90 miles to Cuba.", reward = "landmark" },
  { id = "pikes_peak",   group = "Landmarks", icon = "🏔️", name = "Above the Clouds",     desc = "Drive to the summit of Pikes Peak.",
    lat = 38.840612, lon = -105.044051, km = 1.0, hidden = true, hint = "14,115 feet. Mind your brakes.", reward = "landmark" },

  -- career
  { id = "making_bank",  group = "Career", icon = "💰", name = "Making Bank",  desc = "Have $100,000 in the bank.", stat = "money", goal = 100000, reward = "hard" },
  { id = "fleet_owner",  group = "Career", icon = "🔑", name = "Fleet Owner",  desc = "Own 3 cars.",                stat = "cars",  goal = 3,      reward = "medium" },
}

local NOT_LOWER48 = { Alaska = true, Hawaii = true, ["District of Columbia"] = true }

local tick, landmarkTick, clock = 0, 0, 0
local toast = nil   -- { id, name, icon, cash, xp, untilT }

local function core() return earthCareer_main end
local function E() return earthCareer_earth end
local function S() return core() and core().getSave() end
local function msg(t, ttl) if core() then core().notify(t, ttl) end end

local function A()
  local s = S()
  if not s then return nil end
  s.achievements = s.achievements or {}
  local a = s.achievements
  a.unlocked = a.unlocked or {}
  a.milesDriven = a.milesDriven or 0
  return a
end

local function defById(id) for _, d in ipairs(DEFS) do if d.id == id then return d end end return nil end

local function statValue(stat)
  local s, a = S(), A()
  if stat == "miles" then return a.milesDriven end
  if stat == "jobs" then return s.totalJobs or 0 end
  if stat == "money" then return s.money or 0 end
  if stat == "cars" then return #((s.garage and s.garage.cars) or {}) end
  if stat == "states" or stat == "states48" then
    local n = 0
    for name in pairs(s.statesVisited or {}) do
      if stat == "states" or not NOT_LOWER48[name] then n = n + 1 end
    end
    return n
  end
  return 0
end

local function unlock(id)
  local a = A()
  local d = defById(id)
  if not (a and d) or a.unlocked[id] then return false end
  a.unlocked[id] = os.date("%Y-%m-%d")
  local r = R[d.reward] or R.easy
  core().earn(r.cash)
  core().addXp(r.xp)
  toast = { id = id, name = d.name, icon = d.icon, desc = d.desc, cash = r.cash, xp = r.xp, untilT = clock + 7 }
  msg(string.format("🏆 Achievement: %s  (+$%d, +%d XP)", d.name, r.cash, r.xp), 8)
  core().writeSave()
  return true
end

-- jobs.lua calls this when a delivery completes
-- info = { cat, kind, hotshotMode, comfort, miles, urgent, onTime }
function M.onJobCompleted(info)
  if type(info) ~= "table" then return end
  if info.cat == "hotshot" and info.hotshotMode == "trailer" then unlock("hotshot") end
  if info.cat == "freight" then unlock("big_rig") end
  if info.kind == "cityBus" or info.kind == "express" then unlock("next_stop") end
  if info.kind == "rideshare" and (tonumber(info.comfort) or 0) >= 95 then unlock("five_stars") end
  if (tonumber(info.miles) or 0) >= 2000 then unlock("coast2coast") end
  if info.urgent and info.onTime then unlock("beat_clock") end
end

function M.toastState()
  if toast and clock < toast.untilT then return toast end
  return nil
end

function M.buildState()
  local a = A()
  if not a then return nil end
  local list, done = {}, 0
  for _, d in ipairs(DEFS) do
    local got = a.unlocked[d.id]
    if got then done = done + 1 end
    local r = R[d.reward] or R.easy
    local item = { id = d.id, group = d.group, unlocked = got ~= nil, date = got, cash = r.cash, xp = r.xp }
    if got or not d.hidden then
      item.name, item.icon, item.desc = d.name, d.icon, d.desc
    else
      item.name, item.icon, item.desc, item.secret = "???", "❔", d.hint, true
    end
    if d.stat and not got then
      local v = statValue(d.stat)
      item.progress = math.min(1, v / d.goal)
      item.progressText = (d.stat == "money" and ("$" .. math.floor(v)) or tostring(math.floor(v))) .. " / " ..
                          (d.stat == "money" and ("$" .. d.goal) or tostring(d.goal))
    end
    list[#list + 1] = item
  end
  return { list = list, done = done, total = #DEFS, milesDriven = math.floor(a.milesDriven) }
end

function M.onUpdate(dtReal, dtSim)
  clock = clock + dtReal
  if not (core() and core().isRunning()) or core().teleportPending() then return end
  local a = A()
  if not a then return end

  -- miles actually driven (no teleports: those are paused above)
  local v = core().getVeh()
  if v then
    local sp = v:getVelocity():length()
    if sp > 0.5 and sp < 120 then a.milesDriven = a.milesDriven + sp * dtSim / 1609.34 end
  end

  tick = tick + dtReal
  if tick >= 1 then
    tick = 0
    for _, d in ipairs(DEFS) do
      if d.stat and not a.unlocked[d.id] and statValue(d.stat) >= d.goal then unlock(d.id) end
    end
  end

  landmarkTick = landmarkTick + dtReal
  if landmarkTick >= 2 and E() then
    landmarkTick = 0
    local lat, lon = E().playerLatLon()
    if lat then
      for _, d in ipairs(DEFS) do
        if d.lat and not a.unlocked[d.id] and E().miles(lat, lon, d.lat, d.lon) * 1.609344 <= d.km then unlock(d.id) end
      end
    end
  end
end

-- console helper: earthCareer_achievements.list()
function M.list()
  local a = A()
  if not a then return end
  for _, d in ipairs(DEFS) do log("I", "earthCareer", (a.unlocked[d.id] and "[x] " or "[ ] ") .. d.name) end
end

return M
