-- ============================================================================
-- Earth Career  -  jobs (the Freight Market)
-- Real towns, real lat/lon, BeamNG.Earth's GPS for routing.
--
-- Categories:  cars (courier, rideshare) · hotshot · freight (semi) · bus
-- Tiers:       Local 0-75 mi · Regional 75-250 mi · Long Haul 250+ mi
-- Flow:        drive to the pickup town -> load (stop there) -> GPS to the
--              destination -> stop within half a mile -> Deliver
-- Buses:       a list of stops served in order, passengers board at each.
-- ============================================================================

local M = {}

-- ---------------------------------------------------------------------------
-- Tuning
-- ---------------------------------------------------------------------------
local TIERS = {
  { id = "local",    name = "Local",     minLevel = 1,  minMi = 3,   maxMi = 75,   mult = 1.00, weight = 6 },
  { id = "regional", name = "Regional",  minLevel = 5,  minMi = 75,  maxMi = 250,  mult = 1.10, weight = 3 },
  { id = "long",     name = "Long Haul", minLevel = 12, minMi = 250, maxMi = 3200, mult = 1.20, weight = 2 },
}

-- pay = (base + perMile * road miles) * tier mult * flag bonuses
local RATES = {
  courier   = { base = 90,  perMile = 5.5 },
  rideshare = { base = 12,  perMile = 2.6 },
  hotshot   = { base = 220, perMile = 8.5 },
  freight   = { base = 450, perMile = 13.0 },
  cityBus   = { base = 100, perStop = 45 },
  express   = { base = 150, perMile = 9.0, perStop = 25 },
  coach     = { base = 250, perMile = 10.0 },
  transfer  = { base = 150, perMile = 7.0 },
  carTransfer = { base = 110, perMile = 4.8 },
}

local ROAD_FACTOR     = 1.22   -- straight-line miles -> estimated road miles
local PICKUP_RADIUS_M = 805    -- 0.5 mi: pickup / delivery zone around a town
local LOAD_SECONDS    = 2.5    -- stopped this long in the pickup zone = loaded
local STOP_SECONDS    = 2.0    -- stopped this long at a bus stop = served
local STOP_SPEED      = 2.5    -- m/s, "stopped"
local RENT_LEVEL      = 5      -- rent a semi / bus from this level
local RENT_SHARE      = 0.22   -- rental fee = this share of the pay (min $150)
local CANCEL_SHARE    = 0.10
local LATE_PENALTY    = 0.25
local URGENT_BONUS, FRAGILE_BONUS, HEAVY_BONUS = 0.30, 0.20, 0.15
local HARSH_G         = 0.42   -- a jolt this hard upsets passengers
local MARKET_MOVE_MI  = 20     -- drove this far from the market's centre: new market
local PER_CATEGORY    = { cars = 7, hotshot = 5, freight = 6, bus = 5 }
local HOTSHOT_TRAILER = 1.25   -- HotShot with a trailer hitched: full load, pays more
local HOTSHOT_BED     = 0.65   -- ... with just a pickup/truck bed: partial load, pays less
local HOTSHOT_BED_LOAD = 0.35  -- share of the cargo that fits in a bed
local TRAILER_RENT_SHARE = 0.08 -- rent just a trailer for your own semi (min $100)
local FREIGHT_TRAILERS = { "dryvan", "flatbed", "tanker" }

local CATEGORIES = {
  { id = "cars",    name = "Cars" },
  { id = "hotshot", name = "HotShot Trucking" },
  { id = "freight", name = "Freight" },
  { id = "bus",     name = "Bus" },
}

local NEEDS = {
  any   = "Any vehicle",
  car   = "Car, SUV or pickup",
  truck = "Pickup/truck, or any vehicle + trailer",
  semi  = "Semi + trailer",
  bus   = "Bus",
}

local COMPANIES = {
  courier  = { "Swift Courier", "Parcel Pals", "Hirochi Express", "Belasco Medical Supply", "Corner Florist Co.", "Gavril Parts Network", "Metro Same-Day" },
  hotshot  = { "Lone Star Hot Shot", "Bruckell Equipment", "Soliad Ag Supply", "Rapid Oilfield Services", "Atlas Machinery", "Prairie Hot Shot" },
  freight  = { "Gavril Logistics", "Ibishu Distribution", "Coast2Coast Freight", "Belasco Foods", "ETK Industrial", "Great Lakes Steel", "Heartland Grain Co.", "Hirochi Electronics" },
  transfer = { "Wentward Bus Sales", "Great Lakes Coach Sales", "Sunbelt Transit Supply", "Interstate Bus & Coach" },
  carTransfer = { "Gavril Auto Group", "Ibishu Motors", "ETK Certified", "Bruckell Dealer Network", "Hirochi Auto Mall",
                  "Soliad Pre-Owned", "Civetta Imports", "Route 66 Auto Sales" },
}

-- { name, weight lb, fragile, urgentChance, heavy }
local CARGO = {
  courier = {
    { "Parcels", 120 }, { "Auto parts", 250 }, { "Legal documents", 10, false, 0.7 },
    { "Pharmacy order", 40, true, 0.6 }, { "Catering trays", 180, true, 0.5 }, { "Laptop shipment", 90, true },
    { "Flower arrangements", 60, true, 0.6 }, { "Lab samples", 20, true, 0.8 }, { "Office supplies", 300 },
  },
  hotshot = {
    { "Generator", 4200, false, 0.2, true }, { "Oilfield valves", 3100, false, 0.5 }, { "Pallets of tile", 5200, true, 0, true },
    { "Tractor parts", 2600 }, { "Hay bales", 3800, false, 0, true }, { "HVAC unit", 1900, true }, { "Lumber bundle", 4600, false, 0, true },
    { "Welding rig", 2900, false, 0.3 }, { "Replacement axle", 1400, false, 0.6 },
  },
  freight = {
    { "Dry van · Groceries", 38000, false, 0.2 }, { "Reefer · Frozen food", 41000, false, 0.4 }, { "Flatbed · Steel coils", 44000, false, 0, true },
    { "Dry van · Electronics", 22000, true, 0.2 }, { "Tanker · Diesel fuel", 43000, true }, { "Car hauler · New cars", 36000, true },
    { "Flatbed · Lumber", 42000, false, 0, true }, { "Dry van · Paper goods", 30000 }, { "Reefer · Fresh produce", 39000, false, 0.6 },
    { "Dry van · Bus parts", 26000, false, 0.3 },
  },
}

local RIDERS = { "Jordan", "Priya", "Marcus", "Elena", "Dave", "Aisha", "Tom", "Keiko", "Luis", "Brianna", "Sam", "Nora", "Hank", "Mei" }

local RENTALS = {
  semi = { models = { "us_semi", "semi" },  name = "Rental semi + trailer", value = 90000,
           trailers = { "dryvan", "flatbed", "tanker" } },
  bus  = { models = { "citybus", "bus" },   name = "Rental bus",   value = 120000 },
}
local TRANSFER_BUS = { models = { "citybus", "bus" }, name = "Dealer bus", value = 120000 }
local TRANSFER_CAR = { models = { "etk800", "covet", "pessima" }, name = "Dealer car", value = 30000 }

-- what a provided-vehicle job lends you: "car" or "bus"
local function providedWhat(o) return (o.kind == "carTransfer") and "car" or "bus" end

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------
local market = {}          -- current offers
local marketCenter = nil   -- { lat, lon, level }
local nextOfferId = 1
local lastAutoGen = -100
local clock = 0
local tick = 0
local stillTimer = 0
local lastVel = nil
local harshCooldown = 0
local notice = nil         -- why the market is empty, for the UI

local function core() return earthCareer_main end
local function E() return earthCareer_earth end
local function garage() return earthCareer_garage end
local function S() return core() and core().getSave() end
local function msg(t, ttl) if core() then core().notify(t, ttl) end end
local function J()
  local s = S()
  if not s then return nil end
  s.jobs = s.jobs or { active = nil, stats = {}, report = nil }
  s.jobs.stats = s.jobs.stats or {}
  return s.jobs
end

local function clamp(x, a, b) return math.max(a, math.min(b, x)) end
local function pick(list) return list[math.random(#list)] end
local function round(x) return math.floor(x + 0.5) end
local function tierById(id) for _, t in ipairs(TIERS) do if t.id == id then return t end end return TIERS[1] end
local function level() local s = S(); return s and s.level or 1 end

local function weightedPick(list, weightFn)
  local total = 0
  for _, x in ipairs(list) do total = total + weightFn(x) end
  if total <= 0 then return nil end
  local r = math.random() * total
  for _, x in ipairs(list) do
    r = r - weightFn(x)
    if r <= 0 then return x end
  end
  return list[#list]
end

local function townWeight(t) return t.pop > 0 and (2 + math.sqrt(t.pop) / 60) or 1 end
local function place(t) return { name = t.name, st = t.st, lat = t.lat, lon = t.lon } end

local function modelExists(m)
  local ok, info = pcall(function() return core_vehicles.getModel(m) end)
  return ok and type(info) == "table" and info.model ~= nil
end

local function firstModel(spec)
  for _, m in ipairs(spec.models) do if modelExists(m) then return m end end
  return spec.models[1]
end

local function speedOf(v) return v and v:getVelocity():length() or 0 end
local function getVeh() return core() and core().getVeh() or nil end

-- ---------------------------------------------------------------------------
-- Offer building
-- ---------------------------------------------------------------------------
local destCache = {}

local function destinations(origin, tier)
  local key = string.format("%.3f,%.3f,%s", origin.lat, origin.lon, tier.id)
  if destCache[key] then return destCache[key] end
  -- no driving to Hawaii; long trips go to name-brand cities
  local filter = function(t) return t.st ~= "HI" and t.st ~= "PR" and (tier.id == "local" or t.st ~= "AK") end
  if tier.id ~= "local" then
    filter = function(t) return t.pop > 0 and t.st ~= "HI" and t.st ~= "AK" and t.st ~= "PR" end
  end
  local list = E().townsWithin(origin.lat, origin.lon, tier.minMi, tier.maxMi, filter)
  local copy = {}
  for _, t in ipairs(list) do copy[#copy + 1] = t end
  destCache[key] = copy
  return copy
end

local function pickTier(allowed)
  local list = {}
  for _, t in ipairs(TIERS) do
    if not allowed or allowed[t.id] then list[#list + 1] = t end
  end
  return weightedPick(list, function(t)
    -- unlocked tiers show up more; a few locked ones tease what's next
    return level() >= t.minLevel and t.weight or t.weight * 0.35
  end)
end

local function pickOrigin(here, playerLL)
  if here and math.random() < 0.65 then return place(here) end
  local near = E().townsWithin(playerLL.lat, playerLL.lon, 3, 25)
  local t = (#near > 0) and weightedPick(near, townWeight) or nil
  if t then return place(t) end
  if here then return place(here) end
  return { name = "Your location", st = "", lat = playerLL.lat, lon = playerLL.lon }
end

local function finishOffer(o, playerLL)
  local tier = tierById(o.tier)
  o.id = nextOfferId; nextOfferId = nextOfferId + 1
  o.tierName = tier.name
  o.locked = level() < tier.minLevel
  o.minLevel = tier.minLevel
  o.pickupMi = math.floor(E().miles(playerLL.lat, playerLL.lon, o.from.lat, o.from.lon) * ROAD_FACTOR * 10 + 0.5) / 10
  o.xp = math.max(15, round(12 + o.miles * 2.2 * (o.cat == "freight" and 1.3 or 1)))
  o.perMile = o.miles > 0 and math.floor(o.pay / o.miles * 100 + 0.5) / 100 or 0
  o.needLabel = NEEDS[o.need] or o.need
  return o
end

local function flagsOf(cargo)
  local f = {}
  if cargo[3] then f.fragile = true end
  if cargo[4] and math.random() < cargo[4] then f.urgent = true end
  if cargo[5] then f.heavy = true end
  return f
end

local function priced(base, f)
  local m = 1
  if f.urgent then m = m + URGENT_BONUS end
  if f.fragile then m = m + FRAGILE_BONUS end
  if f.heavy then m = m + HEAVY_BONUS end
  return round(base * m / 5) * 5
end

local function deadlineFor(miles, tierId, f)
  if not f.urgent then return nil end
  local mph = tierId == "local" and 38 or (tierId == "regional" and 52 or 58)
  return round((miles / mph) * 3600 * 1.4 + 300)   -- seconds, with slack
end

-- point-to-point cargo job
local function cargoOffer(cat, kind, here, playerLL, need, allowedTiers)
  local tier = pickTier(allowedTiers)
  if not tier then return nil end
  local origin = pickOrigin(here, playerLL)
  local dests = destinations(origin, tier)
  if #dests == 0 then return nil end
  local d = weightedPick(dests, townWeight)
  local miles = round(E().miles(origin.lat, origin.lon, d.lat, d.lon) * ROAD_FACTOR)
  local cargo = pick(CARGO[kind])
  local f = flagsOf(cargo)
  local r = RATES[kind]
  local pay = priced((r.base + r.perMile * miles) * tier.mult, f)
  return finishOffer({
    cat = cat, kind = kind, tier = tier.id, company = pick(COMPANIES[kind]),
    title = cargo[1], weight = cargo[2], flags = f,
    from = origin, to = place(d), miles = miles, pay = pay,
    deadline = deadlineFor(miles, tier.id, f), need = need,
  }, playerLL)
end

local function rideshareOffer(here, playerLL)
  local near = E().townsWithin(playerLL.lat, playerLL.lon, 0, 6)
  local origin = (#near > 0) and place(weightedPick(near, townWeight)) or (here and place(here)) or nil
  if not origin then return nil end
  local dests = E().townsWithin(origin.lat, origin.lon, 3, 30)
  if #dests == 0 then return nil end
  local d = weightedPick(dests, townWeight)
  local miles = round(E().miles(origin.lat, origin.lon, d.lat, d.lon) * ROAD_FACTOR)
  local rating = 4.2 + math.random() * 0.8
  local f = {}
  if math.random() < 0.25 then f.urgent = true end
  local r = RATES.rideshare
  return finishOffer({
    cat = "cars", kind = "rideshare", tier = "local", company = "RideNow",
    title = string.format("Rider: %s (%.1f★)", pick(RIDERS), rating), flags = f,
    from = origin, to = place(d), miles = miles, pay = priced(r.base + r.perMile * miles, f),
    deadline = deadlineFor(miles, "local", f), need = "car", passengers = true,
  }, playerLL)
end

-- city bus stops: spread around a real city's centre, or on the loaded roads
local function cityStops(here, playerLL)
  local city = nil
  for _, t in ipairs(E().townsWithin(playerLL.lat, playerLL.lon, 0, 15, function(t) return t.pop > 0 end)) do
    if not city or t.pop > city.pop then city = t end
  end
  local stops = {}
  if city then
    local n = math.random(5, 7)
    local start = math.random() * 360
    for i = 1, n do
      local bearing = start + (i - 1) * (360 / n) + (math.random() - 0.5) * 30
      local mi = 0.3 + math.random() * 2.2
      local lat, lon = E().offset(city.lat, city.lon, mi, bearing)
      stops[#stops + 1] = { name = "Stop " .. i, lat = lat, lon = lon, radius = 200 }
    end
    return stops, city
  end
  -- small town: use the road graph Earth has loaded around the player
  local ok, m = pcall(function() return map.getMap() end)
  if not ok or not m or not m.nodes then return nil end
  local pos = getVeh() and getVeh():getPosition()
  if not pos then return nil end
  local pts = {}
  for _, n in pairs(m.nodes) do
    if n.pos then
      local d = pos:distance(n.pos)
      if d > 120 and d < 900 then pts[#pts + 1] = n.pos end
    end
  end
  if #pts < 6 then return nil end
  -- farthest-point sampling for a spread-out loop
  local chosen = { pts[math.random(#pts)] }
  while #chosen < 5 do
    local best, bestD = nil, -1
    for _, p in ipairs(pts) do
      local dmin = math.huge
      for _, c in ipairs(chosen) do dmin = math.min(dmin, p:distance(c)) end
      if dmin > bestD then best, bestD = p, dmin end
    end
    if bestD < 120 then break end
    chosen[#chosen + 1] = best
  end
  if #chosen < 4 then return nil end
  local cx, cy = 0, 0
  for _, c in ipairs(chosen) do cx = cx + c.x; cy = cy + c.y end
  cx, cy = cx / #chosen, cy / #chosen
  table.sort(chosen, function(a, b) return math.atan2(a.y - cy, a.x - cx) < math.atan2(b.y - cy, b.x - cx) end)
  for i, c in ipairs(chosen) do
    local lat, lon = E().toLatLon(c)
    if lat then stops[#stops + 1] = { name = "Stop " .. i, lat = lat, lon = lon, radius = 40 } end
  end
  if #stops < 4 then return nil end
  return stops, here
end

local function routeMiles(stops)
  local mi = 0
  for i = 2, #stops do mi = mi + E().miles(stops[i - 1].lat, stops[i - 1].lon, stops[i].lat, stops[i].lon) end
  return mi * ROAD_FACTOR
end

local function cityBusOffer(here, playerLL)
  local stops, city = cityStops(here, playerLL)
  if not stops then return nil end
  local town = city or here
  local r = RATES.cityBus
  local miles = round(routeMiles(stops) * 10) / 10
  local num = math.random(2, 48)
  return finishOffer({
    cat = "bus", kind = "cityBus", tier = "local",
    company = (town and town.name or "City") .. " Area Transit",
    title = string.format("Route %d · %s loop", num, town and town.name or "Town"), flags = {},
    from = { name = stops[1].name, st = "", lat = stops[1].lat, lon = stops[1].lon },
    to = { name = stops[#stops].name, st = "", lat = stops[#stops].lat, lon = stops[#stops].lon },
    stops = stops, miles = miles, pay = round((r.base + r.perStop * #stops) / 5) * 5,
    need = "bus", passengers = true,
  }, playerLL)
end

local function expressOffer(here, playerLL)
  if not here then return nil end
  local near = E().townsWithin(here.lat, here.lon, 6, 40)
  if #near < 3 then return nil end
  local stops = { { name = here.name, st = here.st, lat = here.lat, lon = here.lon, radius = PICKUP_RADIUS_M } }
  local used = {}
  local cur = here
  for _ = 1, math.random(3, 4) do
    local best, bestD = nil, math.huge
    for _, t in ipairs(near) do
      if not used[t] then
        local d = E().miles(cur.lat, cur.lon, t.lat, t.lon) / townWeight(t)
        if d < bestD and math.random() < 0.6 then best, bestD = t, d end
      end
    end
    if not best then break end
    used[best] = true
    stops[#stops + 1] = { name = best.name, st = best.st, lat = best.lat, lon = best.lon, radius = PICKUP_RADIUS_M }
    cur = best
  end
  if #stops < 3 then return nil end
  local r = RATES.express
  local miles = round(routeMiles(stops))
  return finishOffer({
    cat = "bus", kind = "express", tier = "local", company = here.name .. " Commuter Express",
    title = "Express · " .. #stops .. " towns", flags = {},
    from = place(here), to = { name = stops[#stops].name, st = stops[#stops].st, lat = stops[#stops].lat, lon = stops[#stops].lon },
    stops = stops, miles = miles, pay = round((r.base + r.perMile * miles + r.perStop * #stops) / 5) * 5,
    need = "bus", passengers = true,
  }, playerLL)
end

local function coachOffer(here, playerLL)
  local tier = pickTier()
  local origin = pickOrigin(here, playerLL)
  local dests = destinations(origin, tier)
  if #dests == 0 then return nil end
  local d = weightedPick(dests, townWeight)
  local miles = round(E().miles(origin.lat, origin.lon, d.lat, d.lon) * ROAD_FACTOR)
  local r = RATES.coach
  return finishOffer({
    cat = "bus", kind = "coach", tier = tier.id, company = "Interstate Coachways",
    title = "Intercity coach to " .. d.name, flags = {},
    from = origin, to = place(d), miles = miles, pay = round((r.base + r.perMile * miles) * tier.mult / 5) * 5,
    need = "bus", passengers = true,
  }, playerLL)
end

local function transferOffer(here, playerLL)
  local tier = pickTier()
  local origin = pickOrigin(here, playerLL)
  local dests = destinations(origin, tier)
  if #dests == 0 then return nil end
  local d = weightedPick(dests, townWeight)
  local miles = round(E().miles(origin.lat, origin.lon, d.lat, d.lon) * ROAD_FACTOR)
  local r = RATES.transfer
  local f = {}
  if math.random() < 0.3 then f.urgent = true end
  return finishOffer({
    cat = "bus", kind = "transfer", tier = tier.id, company = pick(COMPANIES.transfer),
    title = "Dealer transfer · deliver a bus", flags = f,
    from = origin, to = place(d), miles = miles, pay = priced((r.base + r.perMile * miles) * tier.mult, f),
    deadline = deadlineFor(miles, tier.id, f), need = "any", provided = true,
  }, playerLL)
end

-- ---------------------------------------------------------------------------
-- Hot towns: a demand surge somewhere = boosted pay and/or XP to deliver there
-- ---------------------------------------------------------------------------
local HOT_COUNT        = 2      -- hot towns at a time (plus the occasional nearby one)
local HOT_NEARBY_CHANCE = 0.15  -- per market refresh: a town near you heats up
local HOT_JOBS_EACH    = 2
local HOT_REASONS = {
  "Hospital supply shortage", "Storm cleanup underway", "Factory restarting the line", "Festival this weekend",
  "Grocery shelves empty", "Bridge closure: no other carriers", "New store grand opening", "Harvest season rush",
  "Holiday rush", "Construction boom", "Plant shutdown: parts needed fast", "Stadium event tonight",
}
local hotTowns = {}     -- { name, st, lat, lon, money, xp, reason, untilT, nearby }

local function tierOf(mi)
  if mi < 75 then return tierById("local") elseif mi < 250 then return tierById("regional") end
  return tierById("long")
end

local function rollBoost()
  -- always both, balanced: a big pay boost with a small XP boost, or the other way round
  if math.random() < 0.5 then return 1.75, 1.25 end   -- +75% pay, +25% XP
  return 1.25, 1.75                                    -- +25% pay, +75% XP
end

local function addHot(t, nearby)
  for _, h in ipairs(hotTowns) do if h.name == t.name and h.st == t.st then return nil end end
  local money, xp = rollBoost()
  local h = { name = t.name, st = t.st, lat = t.lat, lon = t.lon, money = money, xp = xp,
              reason = pick(HOT_REASONS), untilT = clock + (25 + math.random() * 35) * 60, nearby = nearby }
  hotTowns[#hotTowns + 1] = h
  return h
end

local function boostText(h)
  local parts = {}
  if h.money > 1 then parts[#parts + 1] = "+" .. round((h.money - 1) * 100) .. "% pay" end
  if h.xp > 1 then parts[#parts + 1] = "+" .. round((h.xp - 1) * 100) .. "% XP" end
  return table.concat(parts, " · ")
end

local function refreshHotTowns(playerLL)
  for i = #hotTowns, 1, -1 do if clock >= hotTowns[i].untilT then table.remove(hotTowns, i) end end
  local tries = 0
  local regular = 0
  for _, h in ipairs(hotTowns) do if not h.nearby then regular = regular + 1 end end
  while regular < HOT_COUNT and tries < 10 do
    tries = tries + 1
    local tier = pickTier()
    if tier and level() >= tier.minLevel then
      local pool = E().townsWithin(playerLL.lat, playerLL.lon, math.max(10, tier.minMi), math.min(tier.maxMi, 1500),
        function(t) return t.pop > 0 and t.st ~= "HI" and t.st ~= "AK" and t.st ~= "PR" end)
      if #pool > 0 and addHot(weightedPick(pool, townWeight), false) then regular = regular + 1 end
    end
  end
  -- the rare one: a town right around you
  local hasNearby = false
  for _, h in ipairs(hotTowns) do if h.nearby then hasNearby = true end end
  if not hasNearby and math.random() < HOT_NEARBY_CHANCE then
    local near = E().townsWithin(playerLL.lat, playerLL.lon, 5, 30)
    if #near > 0 then
      local h = addHot(weightedPick(near, townWeight), true)
      if h then msg(string.format("🔥 %s needs deliveries: %s for a while! Check Jobs → Hot jobs.", h.name, boostText(h)), 9) end
    end
  end
end

-- a job to a hot town, with the boost baked in
local HOT_KINDS = { { "cars", "courier", "any" }, { "hotshot", "hotshot", "truck" }, { "freight", "freight", "semi" }, { "cars", "carTransfer", "any" } }
local function hotOffer(h, here, playerLL)
  local k = pick(HOT_KINDS)
  local origin = pickOrigin(here, playerLL)
  if E().miles(origin.lat, origin.lon, h.lat, h.lon) < 3 then
    origin = { name = "Your location", st = "", lat = playerLL.lat, lon = playerLL.lon }
    if E().miles(origin.lat, origin.lon, h.lat, h.lon) < 3 then return nil end
  end
  local miles = round(E().miles(origin.lat, origin.lon, h.lat, h.lon) * ROAD_FACTOR)
  local tier = tierOf(miles)
  local r = RATES[k[2]]
  local f, title, weight = {}, nil, nil
  if k[2] == "carTransfer" then
    title = "Dealer transfer · deliver a car"
  else
    local cargo = pick(CARGO[k[2]])
    f = flagsOf(cargo)
    title, weight = cargo[1], cargo[2]
  end
  if math.random() < 0.5 then f.urgent = true end   -- they need it soon
  local o = finishOffer({
    cat = k[1], kind = k[2], tier = tier.id,
    company = (k[2] == "carTransfer") and pick(COMPANIES.carTransfer) or pick(COMPANIES[k[2]]),
    title = title, weight = weight, flags = f,
    from = origin, to = { name = h.name, st = h.st, lat = h.lat, lon = h.lon }, miles = miles,
    pay = round(priced((r.base + r.perMile * miles) * tier.mult, f) * h.money / 5) * 5,
    deadline = deadlineFor(miles, tier.id, f), need = k[3], provided = (k[2] == "carTransfer") or nil,
  }, playerLL)
  o.xp = round(o.xp * h.xp)
  o.perMile = o.miles > 0 and math.floor(o.pay / o.miles * 100 + 0.5) / 100 or 0
  o.hot = { money = h.money, xp = h.xp, reason = h.reason, text = boostText(h), nearby = h.nearby }
  return o
end

-- dealership to dealership: the dealer lends you the car you're delivering
local function carTransferOffer(here, playerLL)
  local tier = pickTier()
  local origin = pickOrigin(here, playerLL)
  local dests = destinations(origin, tier)
  if #dests == 0 then return nil end
  local d = weightedPick(dests, townWeight)
  local miles = round(E().miles(origin.lat, origin.lon, d.lat, d.lon) * ROAD_FACTOR)
  local r = RATES.carTransfer
  local f = {}
  if math.random() < 0.3 then f.urgent = true end
  return finishOffer({
    cat = "cars", kind = "carTransfer", tier = tier.id, company = pick(COMPANIES.carTransfer),
    title = "Dealer transfer · deliver a car", flags = f,
    from = origin, to = place(d), miles = miles, pay = priced((r.base + r.perMile * miles) * tier.mult, f),
    deadline = deadlineFor(miles, tier.id, f), need = "any", provided = true,
  }, playerLL)
end

local function generateMarket()
  local keep = {}
  for _, o in ipairs(market) do if o.custom then keep[#keep + 1] = o end end
  market, destCache = keep, {}
  notice = nil
  if not E().available() then notice = "Load BeamNG.Earth to see real jobs." return end
  local lat, lon = E().playerLatLon()
  if not lat then notice = "Waiting for your position…" return end
  local playerLL = { lat = lat, lon = lon }
  local here = E().nearestTown(lat, lon)
  if here and here._d and here._d > 25 then here = nil end
  marketCenter = { lat = lat, lon = lon, level = level(), here = here and place(here) or nil }

  local function add(o) if o then market[#market + 1] = o end end
  for _ = 1, PER_CATEGORY.cars do
    if math.random() < 0.4 then add(rideshareOffer(here, playerLL))
    else add(cargoOffer("cars", "courier", here, playerLL, "any")) end   -- all tiers, coast to coast at Lv 12
  end
  for _ = 1, 2 do add(carTransferOffer(here, playerLL)) end
  for _ = 1, PER_CATEGORY.hotshot do add(cargoOffer("hotshot", "hotshot", here, playerLL, "truck")) end
  for _ = 1, PER_CATEGORY.freight do add(cargoOffer("freight", "freight", here, playerLL, "semi")) end
  add(cityBusOffer(here, playerLL))
  add(expressOffer(here, playerLL))
  for _ = 1, PER_CATEGORY.bus - 3 do add(coachOffer(here, playerLL)) end
  add(transferOffer(here, playerLL))
  -- hot jobs
  refreshHotTowns(playerLL)
  for _, h in ipairs(hotTowns) do
    for _ = 1, HOT_JOBS_EACH do add(hotOffer(h, here, playerLL)) end
  end
  lastAutoGen = clock
  if #market == 0 then
    notice = "No towns found nearby. Try somewhere in the US."
    lastAutoGen = clock + 55   -- don't rescan every few seconds
  end
end

-- ---------------------------------------------------------------------------
-- Vehicle requirements
-- ---------------------------------------------------------------------------
local function hitched()
  local g = garage()
  return g ~= nil and g.trailerHitched() == true
end

local function meets(need, cls, hitch)
  if need == "any" then return true end
  if need == "car" then return cls == "car" or cls == "truck" end
  -- HotShot: a pickup/truck bed, or any vehicle towing a trailer
  if need == "truck" then return cls == "truck" or (hitch and cls ~= "bus") end
  -- Freight: a semi with a trailer hitched
  if need == "semi" then return cls == "semi" and hitch end
  if need == "bus" then return cls == "bus" end
  return false
end

local function currentClass()
  local g = garage()
  return g and g.currentClass() or "car"
end

local function rentalFor(o)
  if o.need == "semi" then return RENTALS.semi end
  if o.need == "bus" then return RENTALS.bus end
  return nil
end

local function rentFee(o) return math.max(150, round(o.pay * RENT_SHARE / 5) * 5) end

-- ---------------------------------------------------------------------------
-- Custom dispatch (level 15): you book the load. Same pay formulas as the
-- market, so it's about choice, not about printing money.
-- ---------------------------------------------------------------------------
local DISPATCH_LEVEL = 15
local MAX_CUSTOM     = 3
local DISPATCH_KINDS = {
  courier  = { cat = "cars",    need = "any",   maxLb = 1500,  heavyAt = 800,   label = "Car courier" },
  hotshot  = { cat = "hotshot", need = "truck", maxLb = 16000, heavyAt = 9000,  label = "HotShot" },
  freight  = { cat = "freight", need = "semi",  maxLb = 45000, heavyAt = 40000, label = "Freight" },
  coach    = { cat = "bus",     need = "bus",   label = "Intercity coach", passengers = true },
  transfer = { cat = "bus",     need = "any",   label = "Dealer bus transfer", provided = true },
  carTransfer = { cat = "cars", need = "any",   label = "Dealer car transfer", provided = true },
}

local function cleanText(t, n)
  t = tostring(t or ""):gsub("[^%w%s%-_'%.,&/#()]", ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")
  return t:sub(1, n or 40)
end

local function validPlace(p)
  if type(p) ~= "table" then return nil end
  local lat, lon = tonumber(p.lat), tonumber(p.lon)
  if not (lat and lon and lat >= -90 and lat <= 90 and lon >= -180 and lon <= 180) then return nil end
  return { name = cleanText(p.name, 40) ~= "" and cleanText(p.name, 40) or string.format("%.3f, %.3f", lat, lon),
           st = cleanText(p.st, 3), lat = lat, lon = lon }
end

local function tierForMiles(mi)
  if mi < 75 then return tierById("local") elseif mi < 250 then return tierById("regional") end
  return tierById("long")
end

-- the level gate, or the secret override (saved per profile)
local function dispatchOpen()
  local j = J()
  return level() >= DISPATCH_LEVEL or (j ~= nil and j.dispatchOverride == true)
end

-- spec: { kind, cargo, weight, fragile, urgent, from = {name, st, lat, lon}, to = {...} }
-- returns the offer (not posted) or nil, error
local function buildCustom(spec)
  if not dispatchOpen() then return nil, "Custom dispatch unlocks at level " .. DISPATCH_LEVEL .. "." end
  if type(spec) ~= "table" then return nil, "Fill in the load." end
  local k = DISPATCH_KINDS[spec.kind]
  if not k then return nil, "Pick a job type." end
  local from, to = validPlace(spec.from), validPlace(spec.to)
  if not from then return nil, "Pick a pickup." end
  if not to then return nil, "Pick a drop-off." end
  local straight = E().miles(from.lat, from.lon, to.lat, to.lon)
  if straight < 3 then return nil, "Pickup and drop-off need to be at least 3 miles apart." end
  if straight > 3200 then return nil, "That's farther than coast to coast." end
  local miles = round(straight * ROAD_FACTOR)
  local tier = tierForMiles(miles)
  local f = {}
  if spec.urgent then f.urgent = true end
  if spec.fragile and not k.passengers then f.fragile = true end
  local weight = nil
  if k.maxLb then
    weight = math.floor(tonumber(spec.weight) or 0)
    if weight <= 0 then return nil, "Enter the cargo weight." end
    if weight > k.maxLb then return nil, string.format("%s loads max out at %s lb.", k.label, tostring(k.maxLb)) end
    if weight >= k.heavyAt then f.heavy = true end
  end
  local r = RATES[spec.kind]
  local base = (r.base + r.perMile * miles) * tier.mult
  -- heavier loads pay a little more (0.85x empty-ish to 1.15x at the limit)
  if weight then base = base * (0.85 + 0.3 * weight / k.maxLb) end
  local title = cleanText(spec.cargo, 40)
  if title == "" then title = k.passengers and "Charter coach" or (k.provided and ("Dealer transfer · deliver a " .. (spec.kind == "carTransfer" and "car" or "bus")) or "Custom load") end
  local o = {
    cat = k.cat, kind = spec.kind, tier = tier.id, company = "Your dispatch",
    title = title, weight = weight, flags = f,
    from = from, to = to, miles = miles,
    pay = k.passengers and round(base / 5) * 5 or priced(base, f),
    deadline = deadlineFor(miles, tier.id, f), need = k.need,
    provided = k.provided, passengers = k.passengers, custom = true,
  }
  return o
end

local function playerLLorFrom(o)
  local lat, lon = E().playerLatLon()
  return lat and { lat = lat, lon = lon } or { lat = o.from.lat, lon = o.from.lon }
end
local function trailerRentFee(o) return math.max(100, round(o.pay * TRAILER_RENT_SHARE / 5) * 5) end

-- Courier loads and HotShot loads in the bed ride in cargo boxes
local function boxes() local g = garage(); return g and g.cargoBoxes() or 0 end
local function needsBoxes(o, hitch)
  if o.kind == "courier" then return true end
  if o.cat == "hotshot" then return not hitch end
  return false
end

-- rental prices scale with what you pick (a bigger rig costs more)
local function scaled(fee, value, ref)
  local f = math.max(0.6, math.min(1.8, (tonumber(value) or 0) / ref))
  if (tonumber(value) or 0) <= 0 then f = 1 end
  return math.max(100, round(fee * f / 5) * 5)
end

-- what the rental picker offers for a job: { kind, vehicles = {...}, trailers = {...} }
local function quoteFor(o)
  local g = garage()
  if not g then return nil end
  local cls = currentClass()
  local q = { jobId = o.id, vehicles = {}, trailers = {} }
  if o.provided then
    -- the dealer lends the bus: pick any, no charge
    q.kind = "provided"
    q.what = providedWhat(o)
    for _, opt in ipairs(g.rentalOptions(q.what)) do
      q.vehicles[#q.vehicles + 1] = { key = opt.key, name = opt.name, fee = 0 }
    end
    return q
  end
  if o.need == "semi" and cls == "semi" and not hitched() then
    q.kind = "trailer"
  elseif o.need == "semi" then
    q.kind = "rig"
  elseif o.need == "bus" then
    q.kind = "bus"
  else
    return nil
  end
  if q.kind ~= "trailer" then
    local ref = (q.kind == "bus") and RENTALS.bus.value or RENTALS.semi.value
    for _, opt in ipairs(g.rentalOptions(q.kind == "bus" and "bus" or "semi")) do
      q.vehicles[#q.vehicles + 1] = { key = opt.key, name = opt.name, fee = scaled(rentFee(o), opt.value, ref) }
    end
  end
  if q.kind ~= "bus" then
    for _, opt in ipairs(g.rentalOptions("trailer")) do
      q.trailers[#q.trailers + 1] = { key = opt.key, name = opt.name, fee = scaled(trailerRentFee(o), opt.value, 30000) }
    end
  end
  return q
end

-- HotShot pay for the two ways of hauling it
local function hotshotPays(o)
  return round(o.pay * HOTSHOT_TRAILER / 5) * 5, round(o.pay * HOTSHOT_BED / 5) * 5
end

-- Load at the pickup: checks the rig and locks in HotShot pay. Returns ok.
local function loadCargo(a)
  local hitch = hitched()
  if a.cat == "freight" and not hitch then
    msg("Hitch your trailer to load (back up and press L).", 5)
    return false
  end
  if needsBoxes(a, hitch) and boxes() < 1 then
    msg("No cargo boxes on this vehicle: add some in the parts shop (Garage) to load.", 6)
    return false
  end
  if a.cat == "hotshot" then
    local cls = currentClass()
    local trailerPay, bedPay = hotshotPays({ pay = a.basePay or a.pay })
    a.basePay = a.basePay or a.pay
    if hitch and cls ~= "bus" then
      a.hotshotMode, a.pay = "trailer", trailerPay
    elseif cls == "truck" then
      a.hotshotMode, a.pay = "bed", bedPay
      if a.weight then a.weight = round(a.weight * HOTSHOT_BED_LOAD) end
    else
      msg("HotShot needs a pickup/truck, or a trailer hitched.", 5)
      return false
    end
  end
  return true
end

-- ---------------------------------------------------------------------------
-- Active job
-- ---------------------------------------------------------------------------
local function target(a)
  if a.stage == "pickup" then return { name = a.from.name, lat = a.from.lat, lon = a.from.lon, radius = PICKUP_RADIUS_M } end
  if a.stage == "route" then return a.stops[a.stopIndex] end
  return { name = a.to.name, lat = a.to.lat, lon = a.to.lon, radius = PICKUP_RADIUS_M }
end

local function gpsToTarget(a)
  -- the map's trip stops go first; it routes to them and hands back afterwards
  if earthCareer_map then
    local ok, routedToStop = pcall(earthCareer_map.jobRouted)
    if ok and routedToStop then return end
  end
  local t = target(a)
  if t and E().gpsSet(t.lat, t.lon, t.name) then return end
  -- no Earth GPS: fall back to the game's markers
  if t and core_groundMarkers then
    local x, y = E().toWorld(t.lat, t.lon)
    if x then pcall(function() core_groundMarkers.setPath(vec3(x, y, 0)) end) end
  end
end

local function setStage(a, stage)
  a.stage = stage
  stillTimer = 0
  gpsToTarget(a)
end

local function stat(cat)
  local st = J().stats
  st[cat] = st[cat] or { jobs = 0, miles = 0, earned = 0 }
  return st[cat]
end

local function endJobVehicle(a)
  local g = garage()
  if a.trailerRental and g then g.endJobTrailer() end
  if a.vehicleMode == "own" then return 0 end
  return g and g.endJobVehicle() or 0
end

local function complete()
  local jobs = J()
  local a = jobs.active
  if not a then return end
  local g = garage()
  local report = { title = a.title, from = a.from.name, to = a.to.name, cat = a.cat, lines = {} }
  local function line(label, amount) report.lines[#report.lines + 1] = { label = label, amount = amount } end

  a.flags = a.flags or {}
  local pay = a.pay
  line("Job pay", pay)
  if a.hot then line("🔥 Hot job: " .. a.hot.text .. " included", 0) end
  -- cargo damage: crash damage during the job eats the pay (fragile: all of it)
  local dmg = g and math.max(0, g.damageMeter() - (a.damageStart or 0)) or 0
  local sv = core() and core().getSave()
  local cargoDmgOn = not (sv and sv.settings and sv.settings.cargoDamage == false)   -- Settings -> Cargo damage
  if dmg > 0 and cargoDmgOn and not a.passengers and not a.provided then
    local share = clamp(dmg / math.max(500, a.pay), 0, 1) * (a.flags.fragile and 1.0 or 0.5)
    local cut = round(pay * share)
    if cut > 0 then line(a.flags.fragile and "Fragile cargo damaged" or "Cargo damage", -cut); pay = pay - cut end
  end
  -- deadline
  if a.deadline and (a.elapsed or 0) > a.deadline then
    local cut = round(a.pay * LATE_PENALTY)
    line("Late delivery", -cut); pay = pay - cut
  elseif a.deadline then
    line("On time ✓", 0)
  end
  -- passengers: comfort tips and fares
  if a.passengers then
    local comfort = clamp(a.comfort or 100, 0, 100)
    report.comfort = comfort
    if a.fares and a.fares > 0 then line("Fares (" .. (a.riders or 0) .. " riders)", a.fares); pay = pay + a.fares end
    local tip = round(a.pay * clamp((comfort - 55) / 100, 0, 0.35))
    if tip > 0 then line("Tips for a smooth ride", tip); pay = pay + tip end
    if dmg > 0 then
      local cut = round(math.min(a.pay * 0.5, dmg * 0.2))
      if cut > 0 then line("Passengers shaken up (crash)", -cut); pay = pay - cut end
    end
  end
  -- job vehicle back
  local vehFee = endJobVehicle(a)
  if vehFee > 0 then line(a.vehicleMode == "rental" and "Rental damage" or ("Damage to the dealer's " .. providedWhat(a)), -vehFee); pay = pay - vehFee end
  if a.rentPaid then report.rentPaid = a.rentPaid end

  pay = math.max(0, pay)
  if earthCareer_bank then
    local taken = earthCareer_bank.garnish(pay)
    if taken > 0 then line("Overdue payments (bank)", -taken); pay = pay - taken end
  end
  core().earn(pay)
  core().addXp(a.xp)
  local s = S()
  s.totalJobs = (s.totalJobs or 0) + 1
  s.totalKm = (s.totalKm or 0) + a.miles * 1.609344
  local st = stat(a.cat)
  st.jobs, st.miles, st.earned = st.jobs + 1, st.miles + a.miles, st.earned + pay
  report.total, report.xp = pay, a.xp
  if earthCareer_achievements then
    pcall(earthCareer_achievements.onJobCompleted, {
      cat = a.cat, kind = a.kind, hotshotMode = a.hotshotMode, comfort = report.comfort, miles = a.miles,
      urgent = a.flags.urgent, onTime = a.deadline ~= nil and (a.elapsed or 0) <= a.deadline,
    })
  end
  jobs.report = report
  jobs.active = nil
  E().gpsClear()
  if g then g.onJobCompleted() end
  msg(string.format("Delivered! +$%d  +%d XP", pay, a.xp), 7)
  core().writeSave()
  generateMarket()   -- backhaul: fresh jobs from where you are now
  core().pushState()
end

-- ---------------------------------------------------------------------------
-- Public API (HUD buttons)
-- ---------------------------------------------------------------------------
function M.refreshMarket()
  if J().active then msg("Finish or cancel your current job first.") return end
  generateMarket()
  core().pushState()
end

-- secret: earthCareer_jobs.iAmTheDispatcher() toggles dispatch for this profile at any level
function M.iAmTheDispatcher()
  local j = J()
  if not j then log("W", "earthCareer", "Load a profile first.") return end
  j.dispatchOverride = not j.dispatchOverride
  msg(j.dispatchOverride and "🎧 Dispatch radio on. Book any load you like." or "🎧 Dispatch radio off. Back to the level 15 requirement.", 6)
  core().writeSave()
  core().pushState()
  return j.dispatchOverride
end

function M.dispatchQuote(spec)
  local o, err = buildCustom(spec)
  if not o then return { error = err } end
  finishOffer(o, playerLLorFrom(o))
  nextOfferId = nextOfferId - 1   -- a quote doesn't use up an id
  return { pay = o.pay, miles = o.miles, tierName = o.tierName, perMile = o.perMile, xp = o.xp,
           heavy = o.flags.heavy or false, deadlineMin = o.deadline and round(o.deadline / 60) or nil,
           needLabel = o.needLabel }
end

function M.dispatchPost(spec)
  local o, err = buildCustom(spec)
  if not o then return { error = err } end
  local n = 0
  for _, x in ipairs(market) do if x.custom then n = n + 1 end end
  if n >= MAX_CUSTOM then return { error = "You already have " .. MAX_CUSTOM .. " custom loads posted. Take or wait on those first." } end
  finishOffer(o, playerLLorFrom(o))
  table.insert(market, 1, o)
  msg("Load posted: " .. o.title .. ", " .. o.from.name .. " → " .. o.to.name .. ".", 5)
  core().pushState()
  return { id = o.id }
end

-- town search for the dispatcher (bundled list, works offline)
function M.findPlaces(q)
  q = tostring(q or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local name, st = q:match("^(.-)%s*,%s*(%a%a)$")
  name = name or q
  if #name < 2 then return {} end
  local lat, lon = E().playerLatLon()
  local hits = {}
  for _, t in ipairs(E().towns()) do
    local tn = t.name:lower()
    if (not st or t.st:lower() == st) and tn:sub(1, #name) == name then
      local d = lat and E().miles(lat, lon, t.lat, t.lon) or 0
      hits[#hits + 1] = { name = t.name, st = t.st, lat = t.lat, lon = t.lon, pop = t.pop, mi = round(d),
                          score = (tn == name and 0 or 1) * 1e7 - (t.pop or 0) + d }
    end
  end
  table.sort(hits, function(a, b) return a.score < b.score end)
  local out = {}
  for i = 1, math.min(8, #hits) do hits[i].score = nil; out[i] = hits[i] end
  return out
end

function M.rentQuote(id)
  for _, o in ipairs(market) do
    if o.id == tonumber(id) then
      local q = quoteFor(o)
      if q and #q.vehicles == 0 then q.vehicles = nil end
      if q and #q.trailers == 0 then q.trailers = nil end
      return q or { error = "Nothing to rent for this job." }
    end
  end
  return { error = "That job was taken." }
end

function M.accept(id, rent, vKey, tKey)
  local jobs = J()
  if core().teleportPending() then msg("Sort out your teleport first (go home or move your base).") return end
  if jobs.active then msg("You already have a job.") return end
  local o = nil
  for _, x in ipairs(market) do if x.id == id then o = x end end
  if not o then msg("That job was taken.") return end
  if o.locked then msg(o.tierName .. " jobs unlock at level " .. o.minLevel .. ".") return end
  local g = garage()
  if g then
    local ok, reason = g.canWork()
    if not ok then msg(reason, 6) return end
  end
  local v = getVeh()
  local mode, rentPaid = "own", nil
  local chosenV, chosenT = nil, nil
  if (rent or o.provided) and g and g.isRentingCar() then msg("Return your rental car first (Garage).") return end
  if not o.provided and not rent and needsBoxes(o, hitched()) and boxes() < 1 then
    msg("This load rides in cargo boxes: add some to your vehicle in the Garage parts shop" .. (o.cat == "hotshot" and ", or hitch a trailer." or "."), 7)
    return
  end
  -- the picked rental truck/bus/trailer (keys from rentQuote)
  if (rent or o.provided) and g then
    if vKey and vKey ~= "" then chosenV = g.rentalOption(o.provided and providedWhat(o) or (o.need == "bus" and "bus" or "semi"), vKey) end
    if tKey and tKey ~= "" then chosenT = g.rentalOption("trailer", tKey) end
  end
  if o.provided then
    if v and speedOf(v) > 2 then msg("Stop first: the dealer brings the " .. providedWhat(o) .. " to you.") return end
    mode = "provided"
  elseif o.need == "semi" and currentClass() == "semi" and not hitched() then
    -- own semi, no trailer hitched: rent just a trailer
    if not rent then msg("Hitch a trailer first (Garage → Trailers), or rent one.", 6) return end
    if v and speedOf(v) > 2 then msg("Stop first so the trailer can be dropped off.") return end
    local fee = chosenT and scaled(trailerRentFee(o), chosenT.value, 30000) or trailerRentFee(o)
    if not core().spend(fee) then msg("You can't afford the $" .. fee .. " trailer rental.") return end
    mode, rentPaid = "own", fee
    o._rentTrailer = true
  elseif not meets(o.need, currentClass(), hitched()) then
    local spec = rentalFor(o)
    if not (rent and spec) then msg("This job needs: " .. (NEEDS[o.need] or o.need) .. ".", 6) return end
    if level() < RENT_LEVEL then msg("Rentals unlock at level " .. RENT_LEVEL .. ".") return end
    if v and speedOf(v) > 2 then msg("Stop first so the rental can be dropped off.") return end
    local ref = (o.need == "bus") and RENTALS.bus.value or RENTALS.semi.value
    local fee = chosenV and scaled(rentFee(o), chosenV.value, ref) or rentFee(o)
    if o.need == "semi" and chosenT then fee = fee + scaled(trailerRentFee(o), chosenT.value, 30000) end
    if not core().spend(fee) then msg("You can't afford the $" .. fee .. " rental.") return end
    mode, rentPaid = "rental", fee
  end

  local a = {}
  for k, val in pairs(o) do a[k] = val end
  a.vehicleMode, a.rentPaid = mode, rentPaid
  a.trailerRental, o._rentTrailer, a._rentTrailer = o._rentTrailer, nil, nil
  a.flags = a.flags or {}
  if a.cat == "hotshot" then a.basePay = o.pay end
  a.elapsed, a.comfort, a.fares, a.riders, a.aboard = 0, 100, 0, 0, 0
  a.stopIndex = 1
  jobs.active = a
  jobs.report = nil

  if mode ~= "own" and g then
    local spec = (mode == "provided") and (providedWhat(o) == "car" and TRANSFER_CAR or TRANSFER_BUS) or rentalFor(o)
    local wantTrailer = mode == "rental" and o.need == "semi"
    g.startJobVehicle({
      model = chosenV and chosenV.model or firstModel(spec), config = chosenV and chosenV.config or nil,
      name = chosenV and ((mode == "provided" and "Dealer's " or "Rental ") .. chosenV.name) or spec.name, value = chosenV and chosenV.value > 0 and chosenV.value or spec.value,
      kind = mode, cls = (mode == "provided" and providedWhat(o) == "car") and "car" or ((o.need == "semi") and "semi" or "bus"),
      trailer = wantTrailer and (chosenT and chosenT.model or (spec.trailers and firstModel({ models = spec.trailers }))) or nil,
      trailerConfig = wantTrailer and chosenT and chosenT.config or nil,
    })
  end
  if a.trailerRental and g then
    g.startJobTrailer(chosenT and chosenT.model or firstModel({ models = FREIGHT_TRAILERS }), chosenT and chosenT.config or nil)
  end
  a.damageStart = g and g.damageMeter() or 0

  -- start: at the pickup already? then straight to the next leg
  local lat, lon = E().playerLatLon()
  local atPickup = lat and E().miles(lat, lon, o.from.lat, o.from.lon) * 1609.34 <= PICKUP_RADIUS_M
  if o.stops then setStage(a, "route")
  elseif atPickup and mode == "own" and not a.trailerRental and loadCargo(a) then setStage(a, "deliver")
  else setStage(a, "pickup") end

  local how = mode == "rental" and string.format(" Rental: $%d.", rentPaid) or (mode == "provided" and (" The dealer's " .. providedWhat(o) .. " is here.") or "")
  msg(string.format("Accepted: %s. Follow the GPS.%s", o.title, how), 7)
  core().writeSave()
  core().pushState()
end

function M.deliver()
  if core().teleportPending() then return end
  local a = J().active
  if not a or a.stage ~= "deliver" then return end
  local lat, lon = E().playerLatLon()
  if not lat then return end
  if E().miles(lat, lon, a.to.lat, a.to.lon) * 1609.34 > PICKUP_RADIUS_M then msg("You're not at the drop-off yet.") return end
  if garage() and garage().onFoot and garage().onFoot() then msg("Get back in your vehicle to deliver.") return end
  if speedOf(getVeh()) >= STOP_SPEED then msg("Come to a stop to deliver.") return end
  if (a.cat == "freight" or a.hotshotMode == "trailer") and not hitched() then
    msg("Your load is on the trailer: hitch it up to deliver.", 5) return
  end
  complete()
end

function M.cancel()
  local jobs = J()
  local a = jobs.active
  if not a then return end
  local fee = round(a.pay * CANCEL_SHARE)
  local s = S()
  s.money = math.max(0, s.money - fee)
  endJobVehicle(a)
  jobs.active = nil
  E().gpsClear()
  msg("Job cancelled. Fee: $" .. fee, 6)
  core().writeSave()
  core().pushState()
end

function M.dismissReport()
  J().report = nil
  core().pushState()
end

function M.regps()
  local a = J().active
  if a then gpsToTarget(a); msg("GPS route refreshed.", 3) end
end

-- can a non-own vehicle be swapped right now? (garage asks before switching cars)
function M.hasJobVehicle()
  local a = J() and J().active
  return a ~= nil and a.vehicleMode ~= "own"
end

-- ---------------------------------------------------------------------------
-- UI state
-- ---------------------------------------------------------------------------
local function offerView(o, cls, hitch, boxCount)
  local can = meets(o.need, cls, hitch) or o.provided
  local noBoxes = (not o.provided) and needsBoxes(o, hitch) and boxCount < 1
  local semiNoTrailer = (o.need == "semi" and cls == "semi" and not hitch)
  local rentable = not can and not semiNoTrailer and rentalFor(o) ~= nil
  local hsTrailer, hsBed = nil, nil
  if o.cat == "hotshot" then hsTrailer, hsBed = hotshotPays(o) end
  return {
    id = o.id, cat = o.cat, kind = o.kind, title = o.title, company = o.company,
    from = o.from, to = o.to, stops = o.stops, miles = o.miles, tier = o.tier, tierName = o.tierName,
    pay = o.pay, xp = o.xp, perMile = o.perMile, flags = o.flags, weight = o.weight,
    deadlineMin = o.deadline and round(o.deadline / 60) or nil, pickupMi = o.pickupMi,
    need = o.need, needLabel = o.needLabel, canDo = can, provided = o.provided,
    rentable = rentable, rentFee = rentable and rentFee(o) or nil,
    rentLocked = rentable and level() < RENT_LEVEL,
    locked = o.locked, minLevel = o.minLevel,
    trailerRentable = semiNoTrailer, trailerRentFee = semiNoTrailer and trailerRentFee(o) or nil,
    ownsTrailer = semiNoTrailer and garage() and garage().ownsTrailer() or false,
    payTrailer = hsTrailer, payBed = hsBed,
    noBoxes = noBoxes, needsBoxes = needsBoxes(o, hitch), custom = o.custom, hot = o.hot,
    hotshotNow = (o.cat == "hotshot") and ((hitch and cls ~= "bus") and "trailer" or (cls == "truck" and "bed" or nil)) or nil,
  }
end

function M.buildState()
  local jobs = J()
  if not jobs then return nil end
  local cls = currentClass()
  local hitch = hitched()
  local lat, lon = E().playerLatLon()
  local out = {
    rig = { cls = cls, hitched = hitch, boxes = boxes() },
    earth = E().available(),
    notice = notice,
    player = lat and { lat = lat, lon = lon } or nil,
    here = marketCenter and marketCenter.here or nil,
    vehicleClass = cls,
    rentLevel = RENT_LEVEL,
    categories = CATEGORIES,
    dispatch = {
      unlocked = dispatchOpen(), level = DISPATCH_LEVEL,
      presets = { courier = {}, hotshot = {}, freight = {} },
      maxLb = { courier = DISPATCH_KINDS.courier.maxLb, hotshot = DISPATCH_KINDS.hotshot.maxLb, freight = DISPATCH_KINDS.freight.maxLb },
    },
    tiers = {},
    market = {},
    report = jobs.report,
    stats = jobs.stats,
  }
  local hl = {}
  local plat, plon = E().playerLatLon()
  for _, h in ipairs(hotTowns) do
    if clock < h.untilT then
      hl[#hl + 1] = { name = h.name, st = h.st, text = boostText(h), reason = h.reason, nearby = h.nearby,
                      minsLeft = math.max(1, round((h.untilT - clock) / 60)),
                      mi = plat and round(E().miles(plat, plon, h.lat, h.lon)) or nil, lat = h.lat, lon = h.lon }
    end
  end
  out.hotTowns = (#hl > 0) and hl or nil
  for kind, list in pairs(CARGO) do
    for _, c in ipairs(list) do
      local p = out.dispatch.presets[kind]
      if p then p[#p + 1] = { name = c[1], lb = c[2], fragile = c[3] or false } end
    end
  end
  for _, t in ipairs(TIERS) do
    out.tiers[#out.tiers + 1] = { id = t.id, name = t.name, minLevel = t.minLevel, unlocked = level() >= t.minLevel,
                                  range = t.id == "long" and "250+ mi" or (t.minMi == 3 and "0" or t.minMi) .. "–" .. t.maxMi .. " mi" }
  end
  if not jobs.active then
    local bx = boxes()
    for _, o in ipairs(market) do out.market[#out.market + 1] = offerView(o, cls, hitch, bx) end
  end

  local a = jobs.active
  if a then
    local t = target(a)
    local distMi = (lat and t) and E().miles(lat, lon, t.lat, t.lon) or nil
    local v = getVeh()
    local gps = E().gpsStatus()
    out.active = {
      cat = a.cat, kind = a.kind, title = a.title, company = a.company, from = a.from, to = a.to, stops = a.stops,
      stopIndex = a.stopIndex, stopCount = a.stops and #a.stops or 0,
      miles = a.miles, pay = a.pay, xp = a.xp, flags = a.flags, stage = a.stage,
      target = t, distMi = distMi and math.floor(distMi * 100 + 0.5) / 100 or nil,
      roadMi = (gps and gps.remaining) and math.floor(gps.remaining / 1609.34 * 10 + 0.5) / 10 or nil,
      etaMin = (gps and gps.eta) and round(gps.eta / 60) or nil,
      gpsPlanning = gps and gps.planning or false,
      inRange = distMi ~= nil and distMi * 1609.34 <= (t.radius or PICKUP_RADIUS_M),
      stopped = speedOf(v) < STOP_SPEED,
      elapsed = round(a.elapsed or 0),
      deadline = a.deadline, late = a.deadline ~= nil and (a.elapsed or 0) > a.deadline,
      comfort = a.passengers and round(a.comfort or 100) or nil,
      aboard = a.aboard, riders = a.riders, fares = a.fares,
      cargoDamage = (not a.passengers and garage() and ((core().getSave() or {}).settings or {}).cargoDamage ~= false) and math.max(0, garage().damageMeter() - (a.damageStart or 0)) or 0,
      vehicleMode = a.vehicleMode, rentPaid = a.rentPaid, passengers = a.passengers,
      hotshotMode = a.hotshotMode, needsTrailer = (a.cat == "freight" or a.hotshotMode == "trailer"), hitched = hitch,
      trailerRental = a.trailerRental,
    }
  end
  return out
end

-- ---------------------------------------------------------------------------
-- Hooks
-- ---------------------------------------------------------------------------
function M.onCareerPaused()
  E().gpsClear()
end

function M.onCareerResumed()
  local a = J() and J().active
  if a then gpsToTarget(a) end
end

function M.onCareerReset()
  market, marketCenter, notice = {}, nil, nil
  E().gpsClear()
end

function M.onClientPostStartMission()
  market, marketCenter = {}, nil
  lastAutoGen = clock - 2   -- give Earth a few seconds to place you
end

local function serveStop(a)
  local t = a.stops[a.stopIndex]
  -- passengers off and on
  local off = (a.stopIndex == #a.stops) and a.aboard or math.min(a.aboard, math.random(0, 6))
  local on = (a.stopIndex == #a.stops) and 0 or math.random(1, (a.kind == "express") and 12 or 8)
  a.aboard = a.aboard - off + on
  a.riders = a.riders + on
  local fare = (a.kind == "express") and 4.5 or 2.5
  a.fares = round(a.fares + on * fare)
  msg(string.format("%s: %d off, %d on. %d aboard.", t.name, off, on, a.aboard), 4)
  a.stopIndex = a.stopIndex + 1
  if a.stopIndex > #a.stops then
    complete()
  else
    setStage(a, "route")
  end
end

function M.onUpdate(dtReal, dtSim)
  clock = clock + dtReal
  if not (core() and S() and core().isRunning()) then return end
  if core().teleportPending() then return end   -- everything waits for the teleport decision
  local jobs = J()
  local a = jobs.active

  -- market upkeep
  if not a and clock - lastAutoGen > 5 then
    local lat, lon = E().playerLatLon()
    local stale = #market == 0
      or (marketCenter and lat and E().miles(lat, lon, marketCenter.lat, marketCenter.lon) > MARKET_MOVE_MI)
      or (marketCenter and marketCenter.level ~= level())
    if stale and E().available() then generateMarket() end
    lastAutoGen = clock
  end
  if not a then return end

  a.elapsed = (a.elapsed or 0) + dtSim
  local v = getVeh()

  -- target marker: a tall green pillar (position refreshed every check below)
  local mk = a._marker
  if mk then
    pcall(function()
      local base = vec3(mk.x, mk.y, mk.z)
      debugDrawer:drawCylinder(base, base + vec3(0, 0, 30), 2.5, ColorF(0.2, 0.9, 0.4, 0.35))
    end)
  end

  -- passenger comfort: hard braking / launches / cornering
  if a.passengers and v and a.stage ~= "pickup" then
    local vel = v:getVelocity()
    if lastVel and dtSim > 0 then
      local dx, dy = vel.x - lastVel.x, vel.y - lastVel.y
      local g = math.sqrt(dx * dx + dy * dy) / dtSim / 9.81
      harshCooldown = harshCooldown - dtSim
      if g > HARSH_G and g < 6 and harshCooldown <= 0 then
        a.comfort = math.max(0, (a.comfort or 100) - 4)
        harshCooldown = 1.0
      end
    end
    lastVel = vec3(vel.x, vel.y, vel.z)
  else
    lastVel = nil
  end

  tick = tick + dtReal
  if tick < 0.25 then return end
  local dt = tick
  tick = 0

  local lat, lon = E().playerLatLon()
  if not lat then return end
  local t = target(a)
  local d = E().miles(lat, lon, t.lat, t.lon) * 1609.34
  local inRange = d <= (t.radius or PICKUP_RADIUS_M)
  local stopped = speedOf(v) < STOP_SPEED
  -- on foot (walking mode) doesn't load, unload or serve stops: get back in
  if garage() and garage().onFoot and garage().onFoot() then stopped = false end

  if inRange and stopped then stillTimer = stillTimer + dt else stillTimer = 0 end

  if a.stage == "pickup" and stillTimer >= LOAD_SECONDS and not loadCargo(a) then
    stillTimer = 0   -- waiting for the right rig; try again
  elseif a.stage == "pickup" and stillTimer >= LOAD_SECONDS then
    if a.hotshotMode then
      msg(a.hotshotMode == "trailer" and "Full load on the trailer: $" .. a.pay .. "." or "Partial load in the bed: $" .. a.pay .. ". A trailer pays more.", 6)
    end
    msg(a.passengers and "Passengers aboard. Head to " .. a.to.name .. "." or "Loaded up. Head to " .. a.to.name .. ".", 6)
    if a.passengers then a.aboard = (a.kind == "rideshare") and 1 or math.random(12, 40); a.riders = a.aboard end
    setStage(a, "deliver")
    core().writeSave()
  elseif a.stage == "route" and stillTimer >= STOP_SECONDS then
    stillTimer = 0
    serveStop(a)
    core().writeSave()
  end

  -- a tall marker over the target when close (re-placed every check: Earth rebases)
  if d < 2500 and v then
    local x, y = E().toWorld(t.lat, t.lon)
    if x then
      local pz = v:getPosition().z
      local z = pz
      pcall(function()
        local h = be:getSurfaceHeightBelow(vec3(x, y, pz + 300))
        if h and h > -1e6 then z = h end
      end)
      a._marker = { x = x, y = y, z = z, r = math.min(t.radius or 40, 60) }
    end
  else
    a._marker = nil
  end
end

return M
