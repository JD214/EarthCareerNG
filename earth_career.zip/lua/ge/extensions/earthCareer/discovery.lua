-- ============================================================================
-- Earth Career  -  town discovery
-- Drive into a town to discover it: 5-10 XP by size. Saved per profile in
-- save.discovered = { ["Name|ST"] = "date" }, the latest few in save.discoveredRecent.
-- The Map tab draws discovered towns as dots (points()).
-- ============================================================================

local M = {}

local GRID = 0.5          -- degrees per grid cell for the town lookup
local CHECK_S = 2
local RECENT_MAX = 8

local grid = nil          -- "cy:cx" -> { towns }
local byKey = {}          -- "Name|ST" -> town
local tick, version = 0, 1

local function core() return earthCareer_main end
local function E() return earthCareer_earth end
local function S() return core() and core().getSave() end
local function msg(t, ttl) if core() then core().notify(t, ttl) end end

local function keyOf(t) return t.name .. "|" .. t.st end
local function cell(lat, lon) return math.floor(lat / GRID) .. ":" .. math.floor(lon / GRID) end

local function buildGrid()
  if grid then return end
  grid = {}
  for _, t in ipairs(E().towns()) do
    local c = cell(t.lat, t.lon)
    grid[c] = grid[c] or {}
    table.insert(grid[c], t)
    byKey[keyOf(t)] = t
  end
end

-- size class 0..3: town / city / big city / metro
local function sizeOf(t)
  local p = t.pop or 0
  if p >= 500000 then return 3 elseif p >= 100000 then return 2 elseif p > 0 then return 1 end
  return 0
end

local function radiusKm(t) return ({ 1.5, 3, 4.5, 6 })[sizeOf(t) + 1] end

local function xpFor(t)
  local p = t.pop or 0
  if p >= 500000 then return 10 elseif p >= 200000 then return 9 elseif p >= 100000 then return 8
  elseif p >= 50000 then return 7 elseif p > 0 then return 6 end
  return 5
end

local function D()
  local s = S()
  if not s then return nil end
  s.discovered = s.discovered or {}
  s.discoveredRecent = s.discoveredRecent or {}
  return s
end

local function discover(t)
  local s = D()
  local k = keyOf(t)
  if s.discovered[k] then return end
  s.discovered[k] = os.date("%Y-%m-%d")
  local xp = xpFor(t)
  table.insert(s.discoveredRecent, 1, { name = t.name, st = t.st, xp = xp, size = sizeOf(t) })
  while #s.discoveredRecent > RECENT_MAX do table.remove(s.discoveredRecent) end
  if sizeOf(t) > (s.biggestDiscovered and s.biggestDiscovered.size or -1)
     or (sizeOf(t) == (s.biggestDiscovered and s.biggestDiscovered.size) and (t.pop or 0) > (s.biggestDiscovered.pop or 0)) then
    s.biggestDiscovered = { name = t.name, st = t.st, size = sizeOf(t), pop = t.pop or 0 }
  end
  core().addXp(xp)
  version = version + 1
  msg(string.format("📍 Discovered %s, %s  (+%d XP)", t.name, t.st, xp), 4)
end

function M.onUpdate(dtReal)
  tick = tick + dtReal
  if tick < CHECK_S then return end
  tick = 0
  if not (core() and core().isRunning() and E()) or core().teleportPending() then return end
  local s = D()
  if not s then return end
  local lat, lon = E().playerLatLon()
  if not lat then return end
  buildGrid()
  local cy, cx = math.floor(lat / GRID), math.floor(lon / GRID)
  local found = false
  for dy = -1, 1 do
    for dx = -1, 1 do
      for _, t in ipairs(grid[(cy + dy) .. ":" .. (cx + dx)] or {}) do
        if not s.discovered[keyOf(t)] and E().miles(lat, lon, t.lat, t.lon) * 1.609344 <= radiusKm(t) then
          discover(t)
          found = true
        end
      end
    end
  end
  if found then core().writeSave() end
end

function M.count()
  local s = S()
  local n = 0
  for _ in pairs(s and s.discovered or {}) do n = n + 1 end
  return n
end

function M.buildState()
  local s = S()
  if not s then return nil end
  local recent = s.discoveredRecent or {}
  return { count = M.count(), recent = (#recent > 0) and recent or nil, biggest = s.biggestDiscovered }
end

-- for the Map tab: { version, pts = { {lat, lon, size, name}, ... } } (only when it changed)
function M.points(have)
  if have == version then return { version = version, same = true } end
  local s = S()
  if not s then return { version = version } end
  buildGrid()
  local pts = {}
  for k in pairs(s.discovered or {}) do
    local t = byKey[k]
    if t then pts[#pts + 1] = { t.lat, t.lon, sizeOf(t), t.name } end
  end
  return { version = version, pts = (#pts > 0) and pts or nil }
end

function M.version() return version end

-- a different profile / a reset: redraw
function M.onProfileChanged() version = version + 1 end

return M
