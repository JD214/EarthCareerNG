-- ============================================================================
-- Earth Career  -  map bridge (the Map tab)
-- Everything the Map tab asks for, through BeamNG.Earth:
--   tiles   beamngEarth_settings.mapTiles: files its companion server writes
--           into /temp/beamngEarth/maptiles/ (the game's UI can't do http)
--   route   beamngEarth/gps: the real road route, ETA, remaining distance
--   search  beamngEarth_core.requestGeocode / takeGeocode (Photon, OSM data)
-- The UI polls poll() a few times a second while the Map tab is open.
-- ============================================================================

local M = {}

local MAX_ROUTE_POINTS = 4000   -- thinned beyond this (a coast-to-coast route has many more)

local searchId = 7000
local freeNav = false           -- the player set the GPS themselves (not the job)

local function E() return earthCareer_earth end
local function core() return earthCareer_main end
local function jobs() return earthCareer_jobs end
local function mod(name) return package.loaded["beamngEarth/" .. name] end

local function earthCore() return rawget(_G, "beamngEarth_core") end

local function earthState()
  local c = earthCore()
  if type(c) ~= "table" or type(c._state) ~= "function" then return nil end
  local ok, st = pcall(c._state)
  return ok and st or nil
end

local function playerVeh()
  if be and be.getPlayerVehicle then return be:getPlayerVehicle(0) end
  if getPlayerVehicle then return getPlayerVehicle(0) end
  return nil
end

-- heading in degrees clockwise from true north (same correction Earth's map uses)
-- the speed limit (mph) of the road you're on: BeamNG.Earth puts real limits
-- on its road graph's edges; the game's map finds the closest edge
local function speedLimitMph(v)
  if not v then return nil end
  local limit = nil
  pcall(function()
    local pos = v:getPosition()
    local n1, n2, dist = map.findClosestRoad(pos)
    if not (n1 and n2) or (dist and dist > 25) then return end
    local m = map.getMap()
    local node = m and m.nodes and m.nodes[n1]
    local link = node and node.links and node.links[n2]
    local sl = link and tonumber(link.speedLimit)
    if sl and sl > 0 then limit = math.floor(sl * 2.23694 / 5 + 0.5) * 5 end   -- m/s -> mph, to the nearest 5
  end)
  return limit
end

local function heading(v)
  if not v then return nil end
  local ok, dir = pcall(function() return v:getDirectionVector() end)
  if not ok or not dir or math.abs(dir.x) + math.abs(dir.y) < 1e-6 then return nil end
  local h = math.deg(math.atan2(dir.x, dir.y))
  local st = earthState()
  local a = st and st.anchor
  if a and a.northAt then
    local okP, p = pcall(function() return v:getPosition() end)
    local okN, nx, ny = pcall(a.northAt, a, okP and p and p.x or 0, okP and p and p.y or 0)
    if okN and tonumber(nx) and tonumber(ny) then h = h - math.deg(math.atan2(nx, ny)) end
  end
  return (h + 360) % 360
end

-- ---------------------------------------------------------------------------
-- Tiles: list = { {z, x, y, layer}, ... } -> keys "layer/z/x/y" that are ready
-- ---------------------------------------------------------------------------
function M.tiles(list)
  local s = rawget(_G, "beamngEarth_settings")
  if type(s) ~= "table" or type(s.mapTiles) ~= "function" then return {} end
  local ok, ready = pcall(s.mapTiles, list)
  return (ok and type(ready) == "table") and ready or {}
end

-- ---------------------------------------------------------------------------
-- Fast poll: you, the GPS, the job's markers
-- ---------------------------------------------------------------------------
function M.poll()
  local out = { earth = E() and E().available() or false }
  local st = earthState()
  out.tilesOk = st ~= nil and st.mapPort ~= nil
  local v = playerVeh()
  local lat, lon = nil, nil
  if E() then lat, lon = E().playerLatLon() end
  if lat then
    out.player = { lat = lat, lon = lon, heading = heading(v),
                   mph = v and math.floor(v:getVelocity():length() * 2.23694 + 0.5) or 0,
                   limitMph = speedLimitMph(v) }
  end
  local g = E() and E().gpsStatus() or nil
  if g then
    out.gps = {
      lat = g.lat, lon = g.lon, name = g.name,
      remainingMi = g.remaining and math.floor(g.remaining / 1609.34 * 10 + 0.5) / 10 or nil,
      straightMi = g.dist and math.floor(g.dist / 1609.34 * 10 + 0.5) / 10 or nil,
      etaMin = g.eta and math.floor(g.eta / 60 + 0.5) or nil,
      version = g.routeVersion or 0, planning = g.planning or false, error = g.routeError,
    }
  end
  out.freeNav = freeNav
  local s = core() and core().getSave()
  local a = s and s.jobs and s.jobs.active
  if a then
    out.job = { cat = a.cat, title = a.title, stage = a.stage, from = a.from, to = a.to,
                stops = a.stops, stopIndex = a.stopIndex }
  end
  out.nav = out.gps and M.navState() or nil
  out.trip = M.tripState()
  out.discVersion = earthCareer_discovery and earthCareer_discovery.version() or nil
  if s and s.homeTown and s.homeTown.lat then out.home = { lat = s.homeTown.lat, lon = s.homeTown.lon, name = s.homeTown.name } end
  return out
end

-- the planned route's points ({lat, lon} pairs), only when it changed
function M.route(haveVersion)
  local gps = mod("gps")
  if type(gps) ~= "table" or type(gps.route) ~= "function" then return { version = -1 } end
  local ok, r = pcall(gps.route)
  if not ok or type(r) ~= "table" or type(r.points) ~= "table" then return { version = -1 } end
  if r.version == haveVersion then return { version = r.version, same = true } end
  local pts = r.points
  local n = #pts
  local step = math.max(1, math.ceil(n / MAX_ROUTE_POINTS))
  local out = {}
  for i = 1, n, step do out[#out + 1] = { pts[i][1], pts[i][2] } end
  if n > 0 and (n - 1) % step ~= 0 then out[#out + 1] = { pts[n][1], pts[n][2] } end
  return { version = r.version, points = out,
           miles = r.dist and math.floor(r.dist / 1609.34 * 10 + 0.5) / 10 or nil,
           minutes = r.dur and math.floor(r.dur / 60 + 0.5) or nil }
end

-- ---------------------------------------------------------------------------
-- Turn-by-turn. Earth's router sends the road path without instructions, so
-- the turns are read from the route's shape: bends within MERGE_M of each
-- other are one maneuver, judged by the net change of direction; going round
-- a circle is a roundabout. Tested against grids, ramps, highway curves,
-- sharp turns, U-turns, roundabouts and jogs (see README).
-- ---------------------------------------------------------------------------
local R_M = 6371000
local LOOK_M, MIN_TURN, MERGE_M = 20, 28, 40
local nav = { version = nil }

local function hav(a1, o1, a2, o2)
  local r = math.rad
  local h = math.sin(r(a2 - a1) / 2) ^ 2 + math.cos(r(a1)) * math.cos(r(a2)) * math.sin(r(o2 - o1) / 2) ^ 2
  return 2 * R_M * math.asin(math.min(1, math.sqrt(h)))
end
local function brg(a1, o1, a2, o2)
  local r = math.rad
  local y = math.sin(r(o2 - o1)) * math.cos(r(a2))
  local x = math.cos(r(a1)) * math.sin(r(a2)) - math.sin(r(a1)) * math.cos(r(a2)) * math.cos(r(o2 - o1))
  return (math.deg(math.atan2(y, x)) + 360) % 360
end
local function wrap(d) return (d + 540) % 360 - 180 end

local function buildNav(r)
  local pts, n = r.points, #r.points
  local cum = { 0 }
  for i = 2, n do cum[i] = cum[i - 1] + hav(pts[i - 1][1], pts[i - 1][2], pts[i][1], pts[i][2]) end
  local seg = {}
  for i = 1, n - 1 do seg[i] = brg(pts[i][1], pts[i][2], pts[i + 1][1], pts[i + 1][2]) end
  -- candidate bends
  local cands = {}
  for i = 2, n - 1 do
    local j = i - 1
    while j > 1 and cum[i] - cum[j] < LOOK_M do j = j - 1 end
    local k = i + 1
    while k < n and cum[k] - cum[i] < LOOK_M do k = k + 1 end
    if cum[i] - cum[j] >= 5 and cum[k] - cum[i] >= 5 and cum[i] > 15 then
      local d = wrap(brg(pts[i][1], pts[i][2], pts[k][1], pts[k][2]) - brg(pts[j][1], pts[j][2], pts[i][1], pts[i][2]))
      if math.abs(d) >= MIN_TURN then cands[#cands + 1] = i end
    end
  end
  -- group them, judge each group by its net turn
  local groups = {}
  for _, i in ipairs(cands) do
    local g = groups[#groups]
    if g and cum[i] - cum[g[#g]] < MERGE_M then g[#g + 1] = i else groups[#groups + 1] = { i } end
  end
  local man = {}
  for _, g in ipairs(groups) do
    local a, b = g[1], g[#g]
    local j = a
    while j > 1 and cum[a] - cum[j] < LOOK_M do j = j - 1 end
    local k = b
    while k < n and cum[k] - cum[b] < LOOK_M do k = k + 1 end
    local total = 0
    for q = j, math.min(k, n - 1) - 1 do total = total + wrap(seg[q + 1] - seg[q]) end
    local net = wrap(total)
    local rb = math.abs(total) > 200 or (math.abs(total) - math.abs(net) > 150)
    local A = math.abs(net)
    local kind = nil
    if rb then kind = "roundabout"
    elseif A >= MIN_TURN then
      kind = (A >= 160 and "uturn") or (A >= 120 and "sharp") or (A >= 50 and "turn") or "slight"
    end
    if kind then
      local at = rb and cum[a] or cum[g[math.floor(#g / 2) + 1]]
      local p = pts[rb and a or g[math.floor(#g / 2) + 1]]
      man[#man + 1] = { s = at, kind = kind, dir = net > 0 and "right" or "left", deg = math.floor(net + 0.5), lat = p[1], lon = p[2] }
    end
  end
  man[#man + 1] = { s = cum[n], kind = "arrive", dir = "", deg = 0, lat = pts[n][1], lon = pts[n][2] }
  nav = { version = r.version, pts = pts, cum = cum, man = man, idx = 1, n = n }
end

-- where along the route the player is (metres from its start) and how far off it
local function progress(lat, lon)
  local pts, cum, n = nav.pts, nav.cum, nav.n
  local kx = 111320 * math.cos(math.rad(lat))
  local function nearest(i0, i1)
    local best, bi, bt = math.huge, nil, 0
    for i = math.max(1, i0), math.min(n - 1, i1) do
      local ax, ay = (pts[i][2] - lon) * kx, (pts[i][1] - lat) * 111320
      local bx, by = (pts[i + 1][2] - lon) * kx, (pts[i + 1][1] - lat) * 111320
      local dx, dy = bx - ax, by - ay
      local L2 = dx * dx + dy * dy
      local t = L2 > 0 and math.max(0, math.min(1, -(ax * dx + ay * dy) / L2)) or 0
      local px, py = ax + t * dx, ay + t * dy
      local d = px * px + py * py
      if d < best then best, bi, bt = d, i, t end
    end
    return math.sqrt(best), bi, bt
  end
  local d, i, t = nearest(nav.idx - 20, nav.idx + 600)
  if not i or d > 150 then d, i, t = nearest(1, n - 1) end   -- lost: search the whole route
  if not i then return 0, math.huge end
  nav.idx = i
  return cum[i] + t * (cum[i + 1] - cum[i]), d
end

-- the turn-by-turn banner: next maneuver, the one after, current street
function M.navState()
  local gps = mod("gps")
  if type(gps) ~= "table" or type(gps.route) ~= "function" then return nil end
  local ok, r = pcall(gps.route)
  if not ok or type(r) ~= "table" or type(r.points) ~= "table" or #r.points < 2 then return nil end
  if r.version ~= nav.version then
    local okB = pcall(buildNav, r)
    if not okB then return nil end
  end
  local lat, lon = nil, nil
  if E() then lat, lon = E().playerLatLon() end
  if not lat then return nil end
  local s, off = progress(lat, lon)
  local nxt, after = nil, nil
  for _, m in ipairs(nav.man) do
    if m.s > s + 8 then
      if not nxt then nxt = m elseif not after then after = m break end
    end
  end
  if not nxt then nxt = nav.man[#nav.man] end
  local loc = E() and E().location() or nil
  local st = E() and E().gpsStatus() or nil
  local out = {
    kind = nxt.kind, dir = nxt.dir, deg = nxt.deg, distM = math.max(0, math.floor(nxt.s - s + 0.5)),
    street = (loc and loc.street ~= "" and loc.street) or nil,
    toward = st and st.name or nil,
    offRoute = off > 60,
    remainingMi = st and st.remaining and math.floor(st.remaining / 1609.34 * 10 + 0.5) / 10 or nil,
    etaMin = st and st.eta and math.floor(st.eta / 60 + 0.5) or nil,
  }
  if after and (after.s - nxt.s) < 400 then
    out["then"] = { kind = after.kind, dir = after.dir, deg = after.deg }
  end
  return out
end

-- ---------------------------------------------------------------------------
-- Free navigation
-- ---------------------------------------------------------------------------
-- The trip: stops in order, then the final destination (a free one, or the
-- job's next target). Earth's GPS takes one destination, so it gets one leg
-- at a time; reaching a stop moves it on to the next.
local STOP_REACHED_M = 120
local MAX_STOPS = 8
local trip = { stops = {}, final = nil }
local tripTimer = 0

local function msg(t, ttl) if core() then core().notify(t, ttl) end end
local function jobActive()
  local s = core() and core().getSave()
  return s and s.jobs and s.jobs.active ~= nil
end

local function setGps(p)
  if not (E() and E().gpsSet(p.lat, p.lon, p.name)) then
    msg("Couldn't set the GPS: is BeamNG.Earth's server connected?", 5)
    return false
  end
  return true
end

-- point the GPS at the next leg of the trip
local function routeNext()
  if #trip.stops > 0 then return setGps(trip.stops[1]) end
  if trip.final then return setGps(trip.final) end
  if jobActive() and jobs() then jobs().regps() return true end   -- back to the job (it calls jobRouted)
  if E() then E().gpsClear() end
  return true
end

function M.navigate(lat, lon, name)
  lat, lon = tonumber(lat), tonumber(lon)
  if not (lat and lon and E()) then return false end
  trip.final = { lat = lat, lon = lon, name = name }
  freeNav = true
  local ok = routeNext()
  if ok and jobActive() then
    msg("GPS set. Your job route is paused: tap \"Back to job route\" on the map when you're ready.", 6)
  end
  return ok
end

function M.addStop(lat, lon, name)
  lat, lon = tonumber(lat), tonumber(lon)
  if not (lat and lon) then return false end
  if #trip.stops >= MAX_STOPS then msg("That's plenty of stops (max " .. MAX_STOPS .. ").") return false end
  trip.stops[#trip.stops + 1] = { lat = lat, lon = lon, name = tostring(name or "Stop") }
  if #trip.stops == 1 then routeNext() end
  msg("Stop added: " .. trip.stops[#trip.stops].name .. (#trip.stops > 1 and (" (#" .. #trip.stops .. ")") or ""), 4)
  return true
end

function M.removeStop(i)
  i = tonumber(i)
  if not (i and trip.stops[i]) then return false end
  table.remove(trip.stops, i)
  if i == 1 then routeNext() end
  return true
end

function M.clearStops()
  trip.stops = {}
  routeNext()
  return true
end

function M.clearNav()
  freeNav = false
  trip.stops, trip.final = {}, nil
  routeNext()   -- the job's route, or nothing
  return true
end

-- the job wants the GPS (accepted / next leg). Stops go first: returns true
-- when the map is routing to a stop instead.
function M.jobRouted()
  freeNav = false
  trip.final = nil
  if #trip.stops > 0 then setGps(trip.stops[1]) return true end
  return false
end

function M.tripState()
  if #trip.stops == 0 and not trip.final then return nil end
  -- (an empty Lua table reaches the UI as {} not [], so leave it out)
  return { stops = (#trip.stops > 0) and trip.stops or nil, final = trip.final }
end

-- ---------------------------------------------------------------------------
-- "Welcome to [state]": the state comes from your position (bundled Census
-- outlines, earth.lua stateAt), Earth's location bar as a fallback; a new one
-- seen on two checks in a row (no flicker along a border) gets a welcome.
-- ---------------------------------------------------------------------------
local NICKNAMES = {
  Alabama = "The Heart of Dixie", Alaska = "The Last Frontier", Arizona = "The Grand Canyon State",
  Arkansas = "The Natural State", California = "The Golden State", Colorado = "The Centennial State",
  Connecticut = "The Constitution State", Delaware = "The First State", Florida = "The Sunshine State",
  Georgia = "The Peach State", Hawaii = "The Aloha State", Idaho = "The Gem State",
  Illinois = "The Prairie State", Indiana = "The Crossroads of America", Iowa = "The Hawkeye State",
  Kansas = "The Sunflower State", Kentucky = "The Bluegrass State", Louisiana = "The Pelican State",
  Maine = "The Pine Tree State", Maryland = "The Old Line State", Massachusetts = "The Bay State",
  Michigan = "The Great Lakes State", Minnesota = "The Land of 10,000 Lakes", Mississippi = "The Magnolia State",
  Missouri = "The Show-Me State", Montana = "Big Sky Country", Nebraska = "The Cornhusker State",
  Nevada = "The Silver State", ["New Hampshire"] = "The Granite State", ["New Jersey"] = "The Garden State",
  ["New Mexico"] = "The Land of Enchantment", ["New York"] = "The Empire State", ["North Carolina"] = "The Tar Heel State",
  ["North Dakota"] = "The Peace Garden State", Ohio = "The Buckeye State", Oklahoma = "The Sooner State",
  Oregon = "The Beaver State", Pennsylvania = "The Keystone State", ["Rhode Island"] = "The Ocean State",
  ["South Carolina"] = "The Palmetto State", ["South Dakota"] = "Mount Rushmore State", Tennessee = "The Volunteer State",
  Texas = "The Lone Star State", Utah = "The Beehive State", Vermont = "The Green Mountain State",
  Virginia = "Virginia Is for Lovers", Washington = "The Evergreen State", ["West Virginia"] = "Wild and Wonderful",
  Wisconsin = "America's Dairyland", Wyoming = "The Equality State", ["District of Columbia"] = "The Nation's Capital",
}
local STATE_XP = 150     -- first visit to a state
local regionNow, regionSeen, regionSeenCount = nil, nil, 0
local welcome = nil      -- { name, nickname, country, until }
local regionTimer = 0
local clock = 0

local function checkRegion()
  if not E() then return end
  if core().teleportPending and core().teleportPending() then return end
  -- your position against the bundled state outlines; Earth's location bar only
  -- when that has no answer (outside the US, or the bundled data missing)
  local r, loc = nil, nil
  local lat, lon = E().playerLatLon()
  if lat and E().stateAt then r = E().stateAt(lat, lon) end
  if not r then
    if lat and E().stateAt and E().stateAt(25.76, -80.19) then return end   -- outlines loaded: just a lake or the sea
    loc = E().location()
    r = loc and loc.region
  end
  if type(r) ~= "string" or r == "" then return end
  if r == regionNow then regionSeen, regionSeenCount = nil, 0 return end
  if r == regionSeen then regionSeenCount = regionSeenCount + 1 else regionSeen, regionSeenCount = r, 1 end
  if regionSeenCount < 2 then return end
  local first = regionNow == nil
  regionNow, regionSeen, regionSeenCount = r, nil, 0
  -- remember every state/province you've driven in
  local s = core() and core().getSave()
  local isNew = false
  if s then
    s.statesVisited = s.statesVisited or {}
    if not s.statesVisited[r] then s.statesVisited[r] = os.date("%Y-%m-%d"); isNew = true end
  end
  -- a state you've never been to: +STATE_XP
  if isNew and core() and core().addXp then core().addXp(STATE_XP) end
  if first then   -- loading in: no welcome sign, just note where we are
    if isNew then msg(string.format("New state: %s!  (+%d XP)", r, STATE_XP), 6); if core() then core().writeSave() end end
    return
  end
  welcome = { name = r, nickname = NICKNAMES[r], country = loc and loc.country, isNew = isNew, xp = isNew and STATE_XP or nil, untilT = clock + 8 }
  msg("Welcome to " .. r .. "!" .. (NICKNAMES[r] and ("  " .. NICKNAMES[r]) or "") .. (isNew and string.format("  (first visit! +%d XP)", STATE_XP) or ""), 8)
  if core() then core().writeSave() end
end

function M.welcomeState()
  if welcome and clock < welcome.untilT then
    return { name = welcome.name, nickname = welcome.nickname, isNew = welcome.isNew, xp = welcome.xp }
  end
  return nil
end

function M.statesVisited()
  local s = core() and core().getSave()
  local n = 0
  for _ in pairs(s and s.statesVisited or {}) do n = n + 1 end
  return n
end

-- { {name, date}, ... } oldest first, for the Stats tab
function M.statesVisitedList()
  local s = core() and core().getSave()
  local out = {}
  for name, date in pairs(s and s.statesVisited or {}) do out[#out + 1] = { name = name, date = tostring(date) } end
  table.sort(out, function(a, b) if a.date ~= b.date then return a.date < b.date end return a.name < b.name end)
  return out
end

function M.onClientPostStartMission() regionNow, regionSeen, regionSeenCount = nil, nil, 0 end

-- reaching a stop moves the trip on (checked twice a second, any tab)
function M.onUpdate(dtReal)
  clock = clock + dtReal
  regionTimer = regionTimer + dtReal
  if regionTimer >= 2 then
    regionTimer = 0
    if core() and core().isRunning() then pcall(checkRegion) end
  end
  tripTimer = tripTimer + dtReal
  if tripTimer < 0.5 then return end
  tripTimer = 0
  local first = trip.stops[1]
  if not (first and E()) then return end
  local lat, lon = E().playerLatLon()
  if not lat then return end
  if E().miles(lat, lon, first.lat, first.lon) * 1609.34 <= STOP_REACHED_M then
    table.remove(trip.stops, 1)
    local nextName = trip.stops[1] and trip.stops[1].name or (trip.final and trip.final.name) or (jobActive() and "your job") or nil
    msg("Stop reached: " .. first.name .. (nextName and (". Next: " .. nextName) or ". Trip done."), 6)
    routeNext()
  end
end

-- ---------------------------------------------------------------------------
-- Search (BeamNG.Earth's geocoder: Photon, OpenStreetMap data)
-- ---------------------------------------------------------------------------
function M.search(q)
  q = tostring(q or ""):sub(1, 120)
  if #q < 3 then return { error = "Type at least 3 letters" } end
  local c = earthCore()
  if type(c) ~= "table" or type(c.requestGeocode) ~= "function" then return { error = "Search needs BeamNG.Earth" } end
  searchId = searchId + 1
  local lat, lon = nil, nil
  if E() then lat, lon = E().playerLatLon() end
  local ok, sent = pcall(c.requestGeocode, searchId, q, lat, lon)
  if not (ok and sent) then return { error = "Search unavailable (companion server not connected)" } end
  return { id = searchId }
end

-- nil while waiting; then { results = { {name, detail, kind, lat, lon} }, error }
function M.searchResult(id)
  local c = earthCore()
  if type(c) ~= "table" or type(c.takeGeocode) ~= "function" then return { error = "Search needs BeamNG.Earth" } end
  local ok, r = pcall(c.takeGeocode, tonumber(id))
  if ok and type(r) == "table" then return r end
  return { pending = true }
end

-- Offline search: the bundled US towns, so the map can always find a town even
-- when Earth's online search is down. "Marshall" or "Marshall, MI"; exact names
-- first, then nearest. { results = { {name, detail, kind, lat, lon} } }
function M.searchLocal(q)
  q = tostring(q or ""):lower():gsub("[%c]", ""):gsub("^%s+", ""):gsub("%s+$", "")
  local name, st = q:match("^(.-)%s*,%s*(%a%a)$")
  name = name or q
  if #name < 2 or not E() then return { results = nil } end
  local lat, lon = E().playerLatLon()
  local hits = {}
  for _, t in ipairs(E().towns()) do
    local tn = t.name:lower()
    if (not st or t.st:lower() == st) and tn:sub(1, #name) == name then
      local d = lat and E().miles(lat, lon, t.lat, t.lon) or 0
      hits[#hits + 1] = { t = t, d = d, exact = (tn == name) }
    end
  end
  table.sort(hits, function(a, b)
    if a.exact ~= b.exact then return a.exact end
    return a.d < b.d
  end)
  local out = {}
  for i = 1, math.min(8, #hits) do
    local h = hits[i]
    local size = (h.t.pop or 0) >= 100000 and "City" or "Town"
    out[i] = { name = h.t.name .. ", " .. h.t.st, detail = size .. (lat and string.format(" · %d mi", math.floor(h.d + 0.5)) or ""),
               kind = "town", lat = h.t.lat, lon = h.t.lon, offline = true }
  end
  return { results = (#out > 0) and out or nil }
end

-- Gas stations BeamNG.Earth has loaded around you (its real stations with pumps),
-- for the Gas button when the online search is down. Pumps grouped into stations.
function M.nearbyGas()
  local gs = package.loaded["beamngEarth/gasstations"]
  if type(gs) ~= "table" or type(gs.lightPoints) ~= "function" or not E() then return { results = nil } end
  local ok, pts = pcall(gs.lightPoints)
  if not (ok and type(pts) == "table") then return { results = nil } end
  local plat, plon = E().playerLatLon()
  local stations = {}
  for _, p in ipairs(pts) do
    local la, lo = E().toLatLon({ x = p[1], y = p[2], z = p[3] })
    if la then
      local found = false
      for _, s in ipairs(stations) do
        if E().miles(la, lo, s.lat, s.lon) < 0.05 then found = true break end   -- same station (~80 m)
      end
      if not found then stations[#stations + 1] = { lat = la, lon = lo } end
    end
  end
  local out = {}
  for _, s in ipairs(stations) do
    local d = plat and E().miles(plat, plon, s.lat, s.lon) or 0
    local t = E().nearestTown(s.lat, s.lon)
    out[#out + 1] = { name = "Gas station" .. (t and (", " .. t.name) or ""), detail = string.format("Loaded nearby · %.1f mi", d),
                      kind = "fuel", lat = s.lat, lon = s.lon, d = d, offline = true }
  end
  table.sort(out, function(a, b) return a.d < b.d end)
  for i = #out, 9, -1 do out[i] = nil end
  for _, r in ipairs(out) do r.d = nil end
  return { results = (#out > 0) and out or nil }
end

-- the nearest town to a dropped pin, for its label
function M.placeName(lat, lon)
  lat, lon = tonumber(lat), tonumber(lon)
  if not (lat and lon and E()) then return { name = "Dropped pin" } end
  local t = E().nearestTown(lat, lon)
  if t and t._d then
    if t._d < 1.5 then return { name = t.name .. ", " .. t.st } end
    return { name = string.format("%.1f mi from %s, %s", t._d, t.name, t.st) }
  end
  return { name = string.format("%.4f, %.4f", lat, lon) }
end

function M.onCareerReset() freeNav = false; trip.stops, trip.final = {}, nil end

return M
