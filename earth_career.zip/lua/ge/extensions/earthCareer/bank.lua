-- ============================================================================
-- Earth Career  -  bank (loans, rental billing, the career day clock)
--
-- A career "day" is DAY_MINUTES of play with the career running. Loans are
-- paid in fixed installments (amortized: interest on what's left + principal),
-- daily or weekly. Rental cars bill once a day. If you can't pay, the amount
-- goes overdue with a late fee and a share of every job's pay is taken until
-- it's caught up. Two missed rental payments and the car is repossessed.
-- ============================================================================

local M = {}

local DAY_MINUTES = 20
local PLANS = {
  daily  = { id = "daily",  name = "Daily",  periods = 10, rate = 0.012, days = 1 },
  weekly = { id = "weekly", name = "Weekly", periods = 6,  rate = 0.05,  days = 7 },
}
local AMOUNTS     = { 1000, 2500, 5000, 10000, 25000, 50000, 100000 }
local LATE_FEE    = 0.05    -- added to a missed payment
local GARNISH     = 0.30    -- share of job pay taken while anything's overdue
local MAX_LOANS   = 3
local REPO_MISSES = 2       -- rental payments missed before the car is taken back

local function core() return earthCareer_main end
local function garage() return earthCareer_garage end
local function S() return core() and core().getSave() end
local function msg(t, ttl) if core() then core().notify(t, ttl) end end
local function round(x) return math.floor(x + 0.5) end

local function B()
  local s = S()
  if not s then return nil end
  s.bank = s.bank or {}
  local b = s.bank
  b.minutes = b.minutes or 0
  b.nextId = b.nextId or 1
  b.loans = b.loans or {}
  b.rentals = b.rentals or {}
  b.overdue = b.overdue or 0
  b.missed = b.missed or 0
  b.paidOnTime = b.paidOnTime or 0
  return b
end

local function day(b) return math.floor((b.minutes or 0) / DAY_MINUTES) + 1 end

local function maxBorrow()
  local s, b = S(), B()
  if not (s and b) then return 0 end
  local owed = 0
  for _, l in ipairs(b.loans) do owed = owed + l.balance end
  return math.max(0, 3000 + (s.level or 1) * 3000 - owed - b.overdue)
end

local function paymentFor(amount, plan)
  local r, n = plan.rate, plan.periods
  return round(amount * r / (1 - (1 + r) ^ (-n)))
end

-- try to take `amount`; short = it goes overdue with a late fee
local function collect(amount, what)
  local b = B()
  if amount <= 0 then return true end
  if core().spend(amount) then
    b.paidOnTime = b.paidOnTime + 1
    return true
  end
  local owed = round(amount * (1 + LATE_FEE))
  b.overdue = b.overdue + owed
  b.missed = b.missed + 1
  msg(string.format("Missed payment: %s ($%d). $%d is now overdue, and %d%% of job pay goes to it until it's paid.",
      what, amount, owed, round(GARNISH * 100)), 9)
  return false
end

-- overdue money first, whenever there's cash
local function collectOverdue()
  local b = B()
  if b.overdue <= 0 then return end
  local s = S()
  local take = math.min(b.overdue, math.max(0, s.money))
  if take > 0 then
    s.money = s.money - take
    b.overdue = b.overdue - take
    if b.overdue <= 0 then msg("Overdue payments cleared. You're back in good standing.", 6) end
  end
end

local function processDay(d)
  local b = B()
  collectOverdue()
  -- loans
  for i = #b.loans, 1, -1 do
    local l = b.loans[i]
    if d >= l.nextDueDay then
      local plan = PLANS[l.plan]
      local interest = round(l.balance * plan.rate)
      local due = (l.periodsLeft <= 1) and (l.balance + interest) or math.min(l.payment, l.balance + interest)
      collect(due, "loan payment")
      l.balance = math.max(0, l.balance + interest - due)
      l.periodsLeft = l.periodsLeft - 1
      l.nextDueDay = l.nextDueDay + plan.days
      if l.balance <= 0 or l.periodsLeft <= 0 then
        table.remove(b.loans, i)
        msg("Loan of $" .. l.amount .. " paid off!", 6)
      end
    end
  end
  -- rental cars
  local list = {}
  for _, r in ipairs(b.rentals) do list[#list + 1] = r end   -- a repo removes from b.rentals
  for _, r in ipairs(list) do
    if d >= r.nextDueDay then
      if not collect(r.perDay, r.name .. " rental") then r.missed = (r.missed or 0) + 1 end
      r.nextDueDay = r.nextDueDay + 1
      if (r.missed or 0) >= REPO_MISSES and garage() then
        msg("Your " .. r.name .. " was repossessed for missed rental payments.", 9)
        garage().returnRental(true)
      end
    end
  end
  core().writeSave()
end

-- ---------------------------------------------------------------------------
-- API
-- ---------------------------------------------------------------------------
function M.takeLoan(amount, planId)
  local b = B()
  local plan = PLANS[planId]
  amount = tonumber(amount)
  if not (b and plan and amount and amount > 0) then return end
  if #b.loans >= MAX_LOANS then msg("You can have " .. MAX_LOANS .. " loans at a time.") return end
  if b.overdue > 0 then msg("The bank won't lend while you have overdue payments.") return end
  if amount > maxBorrow() then msg("That's over your limit ($" .. maxBorrow() .. ").") return end
  local l = {
    id = b.nextId, amount = amount, plan = plan.id, balance = amount,
    payment = paymentFor(amount, plan), periodsLeft = plan.periods,
    nextDueDay = day(b) + plan.days, takenDay = day(b),
  }
  b.nextId = b.nextId + 1
  b.loans[#b.loans + 1] = l
  core().earn(amount)
  msg(string.format("Loan approved: +$%d. %d %s payments of $%d.", amount, plan.periods, plan.name:lower(), l.payment), 7)
  core().writeSave(); core().pushState()
end

function M.payOff(id)
  local b = B()
  for i, l in ipairs(b.loans) do
    if l.id == id then
      if not core().spend(l.balance) then msg("You need $" .. l.balance .. " to pay this off.") return end
      table.remove(b.loans, i)
      msg("Loan paid off early. No more payments!", 6)
      core().writeSave(); core().pushState()
      return
    end
  end
end

function M.payOverdue()
  local b = B()
  if not b or b.overdue <= 0 then return end
  local before = b.overdue
  collectOverdue()
  if b.overdue < before then msg("Paid $" .. (before - b.overdue) .. " of overdue payments.", 4) end
  core().writeSave(); core().pushState()
end

-- rental cars (garage.lua): first day is paid up front
function M.openRental(name, perDay)
  local b = B()
  if not b then return nil end
  if not core().spend(perDay) then return nil end
  local r = { id = b.nextId, name = name, perDay = perDay, nextDueDay = day(b) + 1, missed = 0 }
  b.nextId = b.nextId + 1
  b.rentals[#b.rentals + 1] = r
  return r.id
end

function M.closeRental(id)
  local b = B()
  if not b then return end
  for i, r in ipairs(b.rentals) do if r.id == id then table.remove(b.rentals, i) return end end
end

-- money owed for something (damage on a returned rental you can't cover)
function M.addOverdue(amount, why)
  local b = B()
  if not b or amount <= 0 then return end
  b.overdue = b.overdue + round(amount)
  msg(string.format("$%d for %s is overdue.", round(amount), why or "charges"), 7)
end

-- jobs.lua: take a share of the pay while payments are overdue
function M.garnish(pay)
  local b = B()
  if not b or b.overdue <= 0 or pay <= 0 then return 0 end
  local take = math.min(b.overdue, math.floor(pay * GARNISH))
  b.overdue = b.overdue - take
  if b.overdue <= 0 then msg("Overdue payments cleared!", 5) end
  return take
end

function M.dayLength() return DAY_MINUTES end

-- ---------------------------------------------------------------------------
-- UI state
-- ---------------------------------------------------------------------------
function M.buildState()
  local b = B()
  if not b then return nil end
  local d = day(b)
  local minsIntoDay = (b.minutes or 0) - (d - 1) * DAY_MINUTES
  local function dueIn(dueDay) return round(((dueDay - 1) * DAY_MINUTES - b.minutes) * 10) / 10 end
  local loans, owed, nextDue = {}, 0, nil
  for _, l in ipairs(b.loans) do
    local plan = PLANS[l.plan]
    local due = (l.periodsLeft <= 1) and (l.balance + round(l.balance * plan.rate)) or l.payment
    loans[#loans + 1] = { id = l.id, amount = l.amount, plan = plan.name, balance = l.balance, payment = due,
                          left = l.periodsLeft, of = plan.periods, dueInMin = dueIn(l.nextDueDay) }
    owed = owed + l.balance
    if not nextDue or dueIn(l.nextDueDay) < nextDue.inMin then nextDue = { inMin = dueIn(l.nextDueDay), amount = due, what = "Loan" } end
  end
  local rentals = {}
  for _, r in ipairs(b.rentals) do
    rentals[#rentals + 1] = { id = r.id, name = r.name, perDay = r.perDay, dueInMin = dueIn(r.nextDueDay), missed = r.missed or 0 }
    if not nextDue or dueIn(r.nextDueDay) < nextDue.inMin then nextDue = { inMin = dueIn(r.nextDueDay), amount = r.perDay, what = r.name } end
  end
  local offers = {}
  local limit = maxBorrow()
  for _, a in ipairs(AMOUNTS) do
    offers[#offers + 1] = { amount = a, ok = a <= limit,
                            daily = paymentFor(a, PLANS.daily), weekly = paymentFor(a, PLANS.weekly),
                            dailyTotal = paymentFor(a, PLANS.daily) * PLANS.daily.periods,
                            weeklyTotal = paymentFor(a, PLANS.weekly) * PLANS.weekly.periods }
  end
  return {
    day = d, dayMinutes = DAY_MINUTES, minsLeftToday = round((DAY_MINUTES - minsIntoDay) * 10) / 10,
    loans = (#loans > 0) and loans or nil, rentals = (#rentals > 0) and rentals or nil,
    owed = owed, overdue = b.overdue, limit = limit, canBorrow = #b.loans < MAX_LOANS and b.overdue <= 0,
    nextDue = nextDue, offers = offers, garnishPct = round(GARNISH * 100),
    plans = { daily = { periods = PLANS.daily.periods, ratePct = PLANS.daily.rate * 100, days = 1 },
              weekly = { periods = PLANS.weekly.periods, ratePct = PLANS.weekly.rate * 100, days = 7 } },
  }
end

-- ---------------------------------------------------------------------------
-- The day clock: only runs while the career is running
-- ---------------------------------------------------------------------------
function M.onUpdate(dtReal)
  if not (core() and core().isRunning()) then return end
  if core().teleportPending() then return end
  local b = B()
  if not b then return end
  local before = day(b)
  b.minutes = b.minutes + dtReal / 60
  local now = day(b)
  if now > before then
    for d = before + 1, now do pcall(processDay, d) end
  end
end

return M
