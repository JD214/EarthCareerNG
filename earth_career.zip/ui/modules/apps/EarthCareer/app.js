angular.module('beamng.apps')
.directive('earthCareer', [function () {
  return {
    templateUrl: '/ui/modules/apps/EarthCareer/app.html',
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {
      scope.state = null;
      scope.page = 'home';          // 'home' | 'jobs' | 'garage' | 'settings'
      scope.garageView = 'car';     // 'car' | 'dealer'
      scope.form = { homeName: '' };
      scope.confirmExit = false;
      scope.confirmReset = false;
      scope.confirmSell = null;     // car id waiting for a second click

      // Lua sends an empty table as {} (not []): use this before any array method
      function arr(x) { return Array.isArray(x) ? x : []; }
      scope.arr = arr;
      function lua(cmd)  { bngApi.engineLua('earthCareer_main.' + cmd); }
      function gar(cmd)  { bngApi.engineLua('earthCareer_garage.' + cmd); }
      function job(cmd)  { bngApi.engineLua('earthCareer_jobs.' + cmd); }

      // Lua pushes state every half second and after every action
      scope.$on('EarthCareerUpdate', function (event, data) {
        scope.$evalAsync(function () {
          scope.state = data;
          rebuildJobList();
          requestDraw();
        });
      });

      // which screen to show
      scope.screen = function () {
        if (!scope.state) return 'loading';
        if (scope.state.picker) return 'profiles';
        if (!scope.state.homeTown) return 'setup';
        if (!scope.state.careerActive) return 'paused';
        return 'main';
      };

      // ---- navigation ----
      scope.go = function (p) {
        scope.page = p; scope.confirmExit = false; scope.confirmReset = false; scope.confirmSell = null; scope.confirmRelocate = false;
        if (p === 'jobs') { setTimeout(requestDraw, 30); }
        if (p === 'map') { setTimeout(gmStart, 30); } else { gmStop(); }
      };
      // show / hide the panel (remembered between sessions)
      scope.uiHidden = false;
      try { scope.uiHidden = localStorage.getItem('earthCareer.uiHidden') === '1'; } catch (e) {}
      scope.toggleUi = function () {
        scope.uiHidden = !scope.uiHidden;
        try { localStorage.setItem('earthCareer.uiHidden', scope.uiHidden ? '1' : '0'); } catch (e) {}
        if (scope.uiHidden) { gmStop(); }
        else if (scope.page === 'map') { setTimeout(gmStart, 30); }
        else if (scope.page === 'jobs') { setTimeout(requestDraw, 30); }
      };
      scope.garageTab = function (v) { scope.garageView = v; scope.confirmSell = null; scope.confirmSellTrailer = null; };

      // ---- jobs ----
      scope.acceptJob     = function (id, rent, vKey, tKey) {
        job('accept(' + Number(id) + ',' + (!!rent) + ',' + JSON.stringify(vKey || '') + ',' + JSON.stringify(tKey || '') + ')');
        scope.selJob = null; view.auto = true;
      };

      // ---- custom dispatch (level 15) ----
      scope.dsKinds = [
        { id: 'courier', label: '🚗 Car' }, { id: 'hotshot', label: '🛻 HotShot' }, { id: 'freight', label: '🚛 Freight' },
        { id: 'carTransfer', label: '🚗 Car transfer' }, { id: 'coach', label: '🚌 Coach' }, { id: 'transfer', label: '🚌 Bus transfer' }
      ];
      scope.ds = { kind: 'freight', cargo: '', weight: '', fragile: false, urgent: false, from: null, to: null,
                   q: { from: '', to: '' }, res: { from: [], to: [] }, searching: { from: false, to: false }, quote: null, msg: '' };
      var ds = scope.ds, dsQuoteTimer = null, dsSearchTimers = {};
      function txt(s, n) { return String(s || '').replace(/\s*·\s*/g, ' - ').replace(/[^A-Za-z0-9 \-_'.,&\/#()]/g, '').slice(0, n || 40); }
      function luaJson(o) { return 'jsonDecode(' + JSON.stringify(JSON.stringify(o)) + ')'; }
      function dsSpec() {
        return { kind: ds.kind, cargo: txt(ds.cargo), weight: Number(ds.weight) || 0, fragile: !!ds.fragile, urgent: !!ds.urgent,
                 from: ds.from, to: ds.to };
      }
      scope.dsMaxLb = function () {
        var m = scope.state && scope.state.jobs && scope.state.jobs.dispatch && scope.state.jobs.dispatch.maxLb;
        return (m && m[ds.kind]) || 0;
      };
      function dsQuote() {
        dsQuoteTimer = null; ds.msg = '';
        if (!ds.from || !ds.to) { ds.quote = null; return; }
        bngApi.engineLua('earthCareer_jobs.dispatchQuote(' + luaJson(dsSpec()) + ')', function (r) {
          scope.$evalAsync(function () { ds.quote = r || null; });
        });
      }
      scope.dsChanged = function () { if (dsQuoteTimer) { clearTimeout(dsQuoteTimer); } dsQuoteTimer = setTimeout(dsQuote, 250); };
      scope.dsSetKind = function (k) {
        ds.kind = k;
        if (k === 'coach') { ds.fragile = false; }
        var max = scope.dsMaxLb();
        if (max && Number(ds.weight) > max) { ds.weight = max; }
        scope.dsChanged();
      };
      scope.dsPreset = function (p) { ds.cargo = p.name; ds.weight = Math.min(p.lb || 0, scope.dsMaxLb() || p.lb || 0); ds.fragile = !!p.fragile; scope.dsChanged(); };
      scope.dsToggle = function (key) { ds[key] = !ds[key]; scope.dsChanged(); };
      scope.dsSearch = function (f) {
        var q = txt(ds.q[f], 60);
        if (dsSearchTimers[f]) { clearTimeout(dsSearchTimers[f]); }
        if (q.length < 2) { ds.res[f] = []; return; }
        dsSearchTimers[f] = setTimeout(function () {
          bngApi.engineLua('earthCareer_jobs.findPlaces(' + JSON.stringify(q) + ')', function (r) {
            scope.$evalAsync(function () { ds.res[f] = arr(r); });
          });
        }, 200);
      };
      // addresses and places anywhere, through BeamNG.Earth's search
      scope.dsAddressSearch = function (f) {
        var q = txt(ds.q[f], 60);
        if (q.length < 3) { return; }
        ds.searching[f] = true;
        luaCb('earthCareer_map.search(' + JSON.stringify(q) + ')', function (r) {
          if (!r || r.error) { ds.searching[f] = false; return; }
          var tries = 0;
          (function wait() {
            luaCb('earthCareer_map.searchResult(' + Number(r.id) + ')', function (res) {
              if (res && res.pending && tries++ < 40) { setTimeout(wait, 300); return; }
              ds.searching[f] = false;
              var extra = arr(res && res.results).map(function (x) { return { name: x.name, st: '', detail: x.detail, lat: x.lat, lon: x.lon }; });
              ds.res[f] = arr(ds.res[f]).concat(extra);
            });
          })();
        });
      };
      scope.dsPick = function (f, r) {
        ds[f] = { name: txt(r.name), st: txt(r.st, 3), lat: Number(r.lat), lon: Number(r.lon) };
        ds.q[f] = ''; ds.res[f] = []; ds.searching[f] = false;
        scope.dsChanged(); requestDraw();
      };
      scope.dsHere = function (f) { var h = scope.state.jobs.here; if (h) { scope.dsPick(f, h); } };
      scope.dsHome = function (f) {
        var h = scope.state.homeTown; if (!h || typeof h.lat !== 'number') { return; }
        var m = String(h.name).match(/^(.*?),\s*([A-Z]{2})$/);
        scope.dsPick(f, { name: m ? m[1] : h.name, st: m ? m[2] : '', lat: h.lat, lon: h.lon });
      };
      scope.dsClear = function (f) { ds[f] = null; ds.quote = null; requestDraw(); };
      scope.dsPost = function () {
        if (!ds.quote || ds.quote.error) { return; }
        bngApi.engineLua('earthCareer_jobs.dispatchPost(' + luaJson(dsSpec()) + ')', function (r) {
          scope.$evalAsync(function () {
            if (!r || r.error) { ds.msg = (r && r.error) || 'Could not post the load.'; return; }
            ds.cargo = ''; ds.weight = ''; ds.to = null; ds.quote = null; ds.msg = '';
            scope.jobCat = 'all'; rebuildJobList();
            scope.selJob = r.id; view.auto = true; requestDraw();
          });
        });
      };

      // rental picker: choose the truck / bus and the trailer
      scope.rentPick = null;
      scope.openRentPicker = function (o) {
        scope.rentPick = { jobId: o.id, title: o.title + ' · ' + o.from.name + ' → ' + o.to.name, loading: true };
        bngApi.engineLua('earthCareer_jobs.rentQuote(' + Number(o.id) + ')', function (q) {
          scope.$evalAsync(function () {
            if (!scope.rentPick) { return; }
            scope.rentPick.loading = false;
            if (!q || q.error) { scope.rentPick.error = (q && q.error) || 'Rentals unavailable.'; return; }
            scope.rentPick.kind = q.kind;
            scope.rentPick.what = q.what;
            scope.rentPick.vehicles = arr(q.vehicles);
            scope.rentPick.trailers = arr(q.trailers);
            // start on the cheapest of each
            if (scope.rentPick.vehicles.length) { scope.rentPick.selV = scope.rentPick.vehicles.slice().sort(function (a, b) { return a.fee - b.fee; })[0].key; }
            if (scope.rentPick.trailers.length) { scope.rentPick.selT = scope.rentPick.trailers.slice().sort(function (a, b) { return a.fee - b.fee; })[0].key; }
            if (!scope.rentPick.vehicles.length && !scope.rentPick.trailers.length) { scope.rentPick.error = 'No rental vehicles found in your game.'; }
          });
        });
      };
      scope.closeRentPicker = function () { scope.rentPick = null; };
      scope.pickRentV = function (k) { if (scope.rentPick) { scope.rentPick.selV = k; } };
      scope.pickRentT = function (k) { if (scope.rentPick) { scope.rentPick.selT = k; } };
      function feeOf(list, key) { var x = arr(list).filter(function (i) { return i.key === key; })[0]; return x ? x.fee : 0; }
      scope.rentTotal = function () {
        var r = scope.rentPick; if (!r) { return 0; }
        return feeOf(r.vehicles, r.selV) + feeOf(r.trailers, r.selT);
      };
      scope.rentReady = function () {
        var r = scope.rentPick; if (!r || r.loading || r.error) { return false; }
        return (!arr(r.vehicles).length || r.selV) && (!arr(r.trailers).length || r.selT);
      };
      scope.confirmRent = function () {
        var r = scope.rentPick; if (!scope.rentReady()) { return; }
        scope.acceptJob(r.jobId, r.kind !== 'provided', r.selV, r.selT);
        scope.rentPick = null;
      };

      // bank
      scope.bankOpen = false;
      scope.openBank = function () { scope.bankOpen = true; };
      scope.closeBank = function () { scope.bankOpen = false; };
      scope.takeLoan = function (amount, plan) { bngApi.engineLua('earthCareer_bank.takeLoan(' + Number(amount) + ',' + JSON.stringify(plan) + ')'); };
      scope.payOff = function (id) { bngApi.engineLua('earthCareer_bank.payOff(' + Number(id) + ')'); };
      scope.payOverdue = function () { bngApi.engineLua('earthCareer_bank.payOverdue()'); };
      scope.rentPending = function () { gar('rentPending()'); };
      scope.returnRental = function () { gar('returnRental()'); };
      scope.refreshMarket = function ()   { scope.selJob = null; view.auto = true; job('refreshMarket()'); };
      scope.cancel        = function ()   { job('cancel()'); };
      scope.deliver       = function ()   { job('deliver()'); };
      scope.regps         = function ()   { job('regps()'); };
      scope.dismissReport = function ()   { job('dismissReport()'); };
      scope.repinHome     = function ()   { lua('repinHome()'); };
      scope.confirmRelocate = false;
      scope.relocateHome = function () {
        if (!scope.confirmRelocate) { scope.confirmRelocate = true; return; }
        scope.confirmRelocate = false;
        lua('relocateHome()');
      };
      scope.teleportHome     = function () { lua('teleportHome()'); };
      scope.goHome           = function () { lua('goHome()'); };
      scope.gpsHome = function () {
        var h = scope.state && scope.state.homeTown;
        if (!h || typeof h.lat !== 'number') { return; }
        bngApi.engineLua('earthCareer_map.navigate(' + h.lat + ',' + h.lon + ',' + JSON.stringify(String(h.name).replace(/[\u0000-\u001f]/g, '')) + ')');
      };
      scope.teleportRelocate = function () { lua('teleportRelocate()'); };
      scope.teleportVisit    = function () { lua('teleportVisit()'); };

      // ---- career ----
      scope.saveGame = function ()   { lua('saveGame()'); };
      scope.resume   = function (mode) { scope.page = 'home'; lua('resumeCareer(' + (mode ? JSON.stringify(mode) : '') + ')'); };

      scope.exitCareer = function () {
        if (!scope.confirmExit) { scope.confirmExit = true; return; }
        scope.confirmExit = false;
        lua('exitCareer()');
      };

      scope.setHome = function () {
        var name = (scope.form.homeName || '').replace(/[^A-Za-z0-9 ,.'\-]/g, '').slice(0, 40);
        lua('setHomeTown(' + JSON.stringify(name) + ')');
        scope.typing(false);
      };

      // ---- profiles ----
      scope.profForm = { newName: '', rename: '' };
      scope.profEdit = null;      // profile id being renamed ('current' in Settings)
      scope.profDelete = null;    // profile id waiting for a second click
      function cleanName(s) { return String(s || '').replace(/[^A-Za-z0-9 _\-'.,&]/g, '').slice(0, 30); }
      scope.loadProfile = function (id) { scope.page = 'home'; scope.profDelete = null; lua('loadProfile(' + JSON.stringify(String(id)) + ')'); };
      scope.newProfile = function () {
        scope.page = 'home';
        lua('newProfile(' + JSON.stringify(cleanName(scope.profForm.newName)) + ')');
        scope.profForm.newName = ''; scope.typing(false);
      };
      scope.startRename = function (p, key) { scope.profEdit = key || p.id; scope.profForm.rename = p.name; scope.profDelete = null; };
      scope.cancelRename = function () { scope.profEdit = null; scope.typing(false); };
      scope.saveRename = function (id) {
        lua('renameProfile(' + JSON.stringify(String(id)) + ',' + JSON.stringify(cleanName(scope.profForm.rename)) + ')');
        scope.profEdit = null; scope.typing(false);
      };
      scope.deleteProfile = function (id) {
        if (scope.profDelete !== id) { scope.profDelete = id; return; }
        scope.profDelete = null;
        lua('deleteProfile(' + JSON.stringify(String(id)) + ')');
      };
      scope.switchProfile = function () { gmStop(); scope.page = 'home'; lua('switchProfile()'); };

      // ---- settings ----
      scope.askReset = function (on) { scope.confirmReset = !!on; };
      scope.resetCareer = function () {
        scope.confirmReset = false;
        scope.page = 'home';
        scope.form.homeName = '';
        lua('resetCareer()');
      };
      scope.toggle = function (key) {
        var cur = scope.state && scope.state.settings ? !!scope.state.settings[key] : false;
        lua('setSetting(' + JSON.stringify(key) + ',' + (!cur) + ')');
      };

      // ---- garage ----
      scope.spawnCar    = function ()      { gar('spawnMyCar()'); };
      scope.repair      = function ()      { gar('repair()'); };
      scope.claim       = function ()      { gar('claim()'); };
      scope.scrap       = function ()      { gar('scrap()'); };
      scope.dismissCrash= function ()      { gar('dismissCrash()'); };
      scope.tutorialDone = function ()     { lua('dismissTutorial()'); };
      scope.tutorialGarage = function ()   { scope.go('garage'); lua('dismissTutorial()'); };
      scope.tutorialParts = function ()    { scope.go('garage'); gar('openParts()'); lua('dismissTutorial()'); };
      scope.crashCause  = function (c)     { gar('crashCause(' + JSON.stringify(c === 'bug' ? 'bug' : 'me') + ')'); };
      scope.recover     = function ()      { gar('recover()'); };
      scope.refuel      = function (gal)   { gar('refuel(' + Number(gal || 0) + ')'); };
      scope.openParts   = function ()      { gar('openParts()'); };
      scope.payParts    = function ()      { gar('payParts()'); };
      scope.revertParts = function ()      { gar('revertParts()'); };
      scope.startShopping  = function (k) { gar('startShopping(' + JSON.stringify(k === 'trailer' ? 'trailer' : 'car') + ')'); };
      scope.spawnTrailer   = function (id) { gar('spawnTrailer(' + Number(id) + ')'); };
      scope.storeTrailer   = function (id) { gar('storeTrailer(' + Number(id) + ')'); };
      scope.confirmSellTrailer = null;
      scope.sellTrailer = function (id) {
        if (scope.confirmSellTrailer !== id) { scope.confirmSellTrailer = id; return; }
        scope.confirmSellTrailer = null;
        gar('sellTrailer(' + Number(id) + ')');
      };
      scope.reopenSelector = function ()  { gar('reopenSelector()'); };
      scope.openSelectorAgain = function () { gar('reopenSelector()'); };
      scope.stopShopping   = function ()  { gar('stopShopping()'); };
      scope.buyPending     = function (t) { gar('buyPending(' + (!!t) + ')'); };
      scope.revertPending  = function ()  { gar('revertPending()'); };
      scope.testDriveUsed  = function (id) { gar('testDriveUsed(' + Number(id) + ')'); };
      scope.drive       = function (id)    { gar('driveCar(' + Number(id) + ')'); };
      scope.sell = function (id) {
        if (scope.confirmSell !== id) { scope.confirmSell = id; return; }
        scope.confirmSell = null;
        gar('sellCar(' + Number(id) + ')');
      };

      // stop car/camera keybinds from firing while typing in a text box
      scope.typing = function (on) {
        bngApi.engineLua('if setCEFTyping then setCEFTyping(' + (on ? 'true' : 'false') + ') end');
      };

      // ---- freight market: filter, sort, select ----
      var CAT_COLORS = { cars: '#2f81f7', hotshot: '#f2a900', freight: '#e5534b', bus: '#57d68d' };
      scope.catColor = function (c) { return CAT_COLORS[c] || '#8b949e'; };
      scope.rigName = function (c) { return { car: 'Car', truck: 'Pickup / truck', semi: 'Semi', bus: 'Bus', trailer: 'Trailer' }[c] || 'Car'; };
      scope.jobCat = 'all';
      scope.jobSort = 'pay';
      scope.selJob = null;
      scope.jobList = [];

      function rebuildJobList() {
        var j = scope.state && scope.state.jobs;
        var list = (j && j.market) ? arr(j.market).filter(function (o) {
          if (scope.jobCat === 'hot') { return !!o.hot; }
          return scope.jobCat === 'all' || o.cat === scope.jobCat;
        }) : [];
        var key = { pay: function (o) { return -o.pay; }, rate: function (o) { return -o.perMile; }, dist: function (o) { return o.miles; } }[scope.jobSort];
        list.sort(function (a, b) {
          if (a.locked !== b.locked) { return a.locked ? 1 : -1; }   // locked jobs at the bottom
          return key(a) - key(b);
        });
        scope.jobList = list;
      }
      scope.setCat  = function (c) { scope.jobCat = c; scope.selJob = null; view.auto = true; rebuildJobList(); requestDraw(); };
      scope.hotCount = function () {
        var j = scope.state && scope.state.jobs;
        return arr(j && j.market).filter(function (o) { return !!o.hot && !o.locked; }).length;
      };
      scope.setSort = function (s) { scope.jobSort = s; rebuildJobList(); };
      scope.selectJob = function (id) { scope.selJob = (scope.selJob === id) ? null : id; requestDraw(); };

      // ---- the map (canvas): US states, jobs, you ----
      var view = { auto: true, cx: -96, cy: 38, span: 60 };   // span = degrees of longitude across
      var statesPath = null;
      var drawQueued = false;

      function loadStates() {
        if (window.EarthCareerStates) { return; }
        var s = document.createElement('script');
        s.src = '/ui/modules/apps/EarthCareer/states.js';
        s.onload = requestDraw;
        document.head.appendChild(s);
      }
      loadStates();

      function canvasEl() { return element[0].querySelector('.ec-canvas'); }

      function requestDraw() {
        if (drawQueued) { return; }
        drawQueued = true;
        window.requestAnimationFrame(function () { drawQueued = false; drawMap(); });
      }

      function mapPoints() {
        var j = scope.state && scope.state.jobs;
        var pts = [];
        if (!j) { return pts; }
        if (j.player) { pts.push(j.player); }
        if (j.active) {
          pts.push(j.active.from, j.active.to);
          pts = pts.concat(arr(j.active.stops));
        } else if (scope.jobCat === 'dispatch') {
          pts.push(scope.ds.from, scope.ds.to);
        } else {
          var list = scope.jobList;
          if (scope.selJob) { list = list.filter(function (o) { return o.id === scope.selJob; }); }
          list.forEach(function (o) { pts.push(o.from, o.to); pts = pts.concat(arr(o.stops)); });
        }
        return pts.filter(function (p) { return p && typeof p.lat === 'number'; });
      }

      function fitView(W, H) {
        var pts = mapPoints();
        if (!pts.length) { return; }
        var minLat = 90, maxLat = -90, minLon = 180, maxLon = -180;
        pts.forEach(function (p) {
          minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
          minLon = Math.min(minLon, p.lon); maxLon = Math.max(maxLon, p.lon);
        });
        view.cx = (minLon + maxLon) / 2;
        view.cy = (minLat + maxLat) / 2;
        var cosL = Math.cos(view.cy * Math.PI / 180);
        view.span = Math.max((maxLon - minLon) * 1.3, (maxLat - minLat) * 1.35 * W / (H * cosL), 0.12);
      }

      function drawMap() {
        var c = canvasEl();
        if (!c || !scope.state) { return; }
        var W = c.clientWidth, H = c.clientHeight;
        if (!W || !H) { return; }
        var dpr = window.devicePixelRatio || 1;
        if (c.width !== Math.round(W * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
        var ctx = c.getContext('2d');
        if (view.auto) { fitView(W, H); }
        var cosL = Math.cos(view.cy * Math.PI / 180);
        var k = W / (view.span * cosL);                // px per degree of latitude
        function P(p) { return [W / 2 + (p.lon - view.cx) * k * cosL, H / 2 - (p.lat - view.cy) * k]; }

        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.fillStyle = '#0d1117';
        ctx.fillRect(0, 0, W, H);

        // states
        if (window.EarthCareerStates && window.Path2D) {
          if (!statesPath) { statesPath = new Path2D(window.EarthCareerStates); }
          ctx.save();
          ctx.setTransform(dpr * k * cosL, 0, 0, dpr * k, dpr * (W / 2 - view.cx * k * cosL), dpr * (H / 2 + view.cy * k));
          ctx.fillStyle = '#1b212b';
          ctx.fill(statesPath);
          ctx.lineWidth = 1 / k;
          ctx.strokeStyle = '#39424f';
          ctx.stroke(statesPath);
          ctx.restore();
        }

        var j = scope.state.jobs || {};
        function dot(p, r, fill, ring) {
          var q = P(p);
          ctx.beginPath(); ctx.arc(q[0], q[1], r, 0, Math.PI * 2);
          ctx.fillStyle = fill; ctx.fill();
          if (ring) { ctx.lineWidth = 1.5; ctx.strokeStyle = ring; ctx.stroke(); }
        }
        function line(a, b, color, width, dash) {
          var p = P(a), q = P(b);
          ctx.beginPath(); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]);
          ctx.setLineDash(dash || []); ctx.lineWidth = width; ctx.strokeStyle = color; ctx.stroke(); ctx.setLineDash([]);
        }
        function label(p, text, color) {
          var q = P(p);
          ctx.font = '600 10px Segoe UI, Roboto, sans-serif';
          ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(13,17,23,.9)'; ctx.strokeText(text, q[0] + 6, q[1] - 6);
          ctx.fillStyle = color || '#e9ecef'; ctx.fillText(text, q[0] + 6, q[1] - 6);
        }
        function stopsLine(stops, color, width) {
          for (var i = 1; i < stops.length; i++) { line(stops[i - 1], stops[i], color, width); }
        }

        // home
        var h = scope.state.homeTown;
        if (h && typeof h.lat === 'number') {
          var hq = P(h);
          ctx.font = '13px sans-serif'; ctx.fillStyle = '#f2a900'; ctx.fillText('⌂', hq[0] - 5, hq[1] + 5);
        }

        if (j.active) {
          var a = j.active, col = scope.catColor(a.cat);
          if (arr(a.stops).length) {
            stopsLine(arr(a.stops), col, 2.5);
            arr(a.stops).forEach(function (s, i) { dot(s, 4, i + 1 < a.stopIndex ? '#555' : col, '#0d1117'); });
          } else {
            line(a.from, a.to, col, 2.5);
            dot(a.from, 4, a.stage === 'pickup' ? col : '#555', '#0d1117');
            dot(a.to, 5, col, '#fff');
            label(a.from, a.from.name, '#8b949e');
            label(a.to, a.to.name);
          }
          if (j.player && a.target) { line(j.player, a.target, '#ffffff', 1.5, [4, 4]); }
        } else if (scope.jobCat === 'dispatch') {
          var df = scope.ds.from, dt = scope.ds.to;
          if (df && dt) { line(df, dt, '#f2a900', 2.5, [6, 4]); }
          if (df) { dot(df, 4.5, '#8b949e', '#fff'); label(df, df.name, '#8b949e'); }
          if (dt) { dot(dt, 6, '#f2a900', '#fff'); label(dt, dt.name); }
        } else {
          var sel = null;
          scope.jobList.forEach(function (o) {
            if (o.id === scope.selJob) { sel = o; return; }
            var faded = scope.selJob ? 0.18 : (o.locked ? 0.25 : 0.55);
            ctx.globalAlpha = faded;
            if (arr(o.stops).length) { stopsLine(arr(o.stops), scope.catColor(o.cat), 1.5); } else { line(o.from, o.to, scope.catColor(o.cat), 1.5); }
            dot(o.to, 3.5, scope.catColor(o.cat));
            ctx.globalAlpha = 1;
          });
          if (sel) {
            var sc = scope.catColor(sel.cat);
            if (arr(sel.stops).length) { stopsLine(arr(sel.stops), sc, 3); arr(sel.stops).forEach(function (s) { dot(s, 3.5, sc, '#0d1117'); }); }
            else { line(sel.from, sel.to, sc, 3); dot(sel.from, 4, '#8b949e', '#0d1117'); }
            dot(sel.to, 6, sc, '#fff');
            label(sel.from, sel.from.name, '#8b949e');
            label(sel.to, sel.to.name + (sel.to.st ? ', ' + sel.to.st : ''));
          }
        }

        // you
        if (j.player) { dot(j.player, 5, '#2f81f7', '#ffffff'); }
        if (!j.player && !j.active) {
          ctx.fillStyle = '#8b949e'; ctx.font = '11px sans-serif'; ctx.fillText('Waiting for your position…', 10, 18);
        }
      }

      // pan (drag), zoom (wheel / buttons), pick a pin (click)
      var drag = null;
      element[0].addEventListener('mousedown', function (e) {
        if (!e.target.classList || !e.target.classList.contains('ec-canvas')) { return; }
        drag = { x: e.clientX, y: e.clientY, cx: view.cx, cy: view.cy, moved: false };
      });
      window.addEventListener('mousemove', function (e) {
        if (!drag) { return; }
        var c = canvasEl(); if (!c) { return; }
        var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 4) { drag.moved = true; view.auto = false; }
        if (!drag.moved) { return; }
        var cosL = Math.cos(view.cy * Math.PI / 180);
        var k = c.clientWidth / (view.span * cosL);
        view.cx = drag.cx - dx / (k * cosL);
        view.cy = drag.cy + dy / k;
        requestDraw();
      });
      window.addEventListener('mouseup', function (e) {
        if (!drag) { return; }
        var wasClick = !drag.moved;
        drag = null;
        if (!wasClick) { return; }
        var c = canvasEl(); if (!c || !scope.state || !scope.state.jobs || scope.state.jobs.active) { return; }
        var r = c.getBoundingClientRect();
        var mx = e.clientX - r.left, my = e.clientY - r.top;
        var W = c.clientWidth, H = c.clientHeight;
        var cosL = Math.cos(view.cy * Math.PI / 180), k = W / (view.span * cosL);
        var best = null, bestD = 14;
        scope.jobList.forEach(function (o) {
          var x = W / 2 + (o.to.lon - view.cx) * k * cosL, y = H / 2 - (o.to.lat - view.cy) * k;
          var d = Math.sqrt((x - mx) * (x - mx) + (y - my) * (y - my));
          if (d < bestD) { best = o; bestD = d; }
        });
        if (best) { scope.$evalAsync(function () { scope.selJob = best.id; requestDraw(); }); }
      });
      element[0].addEventListener('wheel', function (e) {
        if (!e.target.classList || !e.target.classList.contains('ec-canvas')) { return; }
        e.preventDefault();
        view.auto = false;
        view.span = Math.min(80, Math.max(0.05, view.span * (e.deltaY > 0 ? 1.25 : 0.8)));
        requestDraw();
      }, { passive: false });
      scope.mapZoom = function (f) { view.auto = false; view.span = Math.min(80, Math.max(0.05, view.span * f)); requestDraw(); };
      scope.mapFit  = function () { view.auto = true; requestDraw(); };

      // ---- the Map tab (careermap.js does the drawing) ----
      var gm = null, gmTimer = null, gmBusy = false, gmRouteAsked = null, gmSearchTimer = null, gmSearchSeq = 0, gmDiscVersion = null;
      scope.gmData = null; scope.gmFull = false; scope.gmFollow = true; scope.gmPin = null;
      scope.gmQ = { text: '' }; scope.gmResults = []; scope.gmSearchMsg = '';

      (function loadMapScript() {
        if (window.EarthCareerMap) { return; }
        var s = document.createElement('script');
        s.src = '/ui/modules/apps/EarthCareer/careermap.js';
        document.head.appendChild(s);
      })();

      function luaCb(cmd, cb) {
        bngApi.engineLua(cmd, function (r) { scope.$evalAsync(function () { cb(r); }); });
      }

      function gmStart() {
        if (!window.EarthCareerMap) { setTimeout(gmStart, 200); return; }
        if (!gm) {
          var root = element[0].querySelector('.ecm');
          if (!root) { return; }
          gm = window.EarthCareerMap(root, {
            lua: function (cmd, cb) { bngApi.engineLua(cmd, cb); },
            onPick: function (lat, lon) {
              scope.$evalAsync(function () {
                scope.gmResults = []; scope.gmSearchMsg = '';
                scope.gmPin = { lat: lat, lon: lon, name: 'Dropped pin' };
                gm.setPin(scope.gmPin);
                luaCb('earthCareer_map.placeName(' + lat + ',' + lon + ')', function (r) {
                  if (scope.gmPin && r && r.name) { scope.gmPin.name = r.name; }
                });
              });
            },
            onFollow: function (on) { scope.$evalAsync(function () { scope.gmFollow = on; }); }
          });
        } else {
          gm.resize();
        }
        if (!gmTimer) { gmTimer = setInterval(gmPoll, 250); }
        gmPoll();
      }
      function gmStop() { if (gmTimer) { clearInterval(gmTimer); gmTimer = null; } }

      function gmPoll() {
        if (gmBusy || !gm) { return; }
        gmBusy = true;
        bngApi.engineLua('earthCareer_map.poll()', function (d) {
          gmBusy = false;
          if (!d || !gm) { return; }
          scope.$evalAsync(function () { scope.gmData = d; });
          try { gm.update(d); } catch (e) { if (window.console) { console.error('EarthCareer map', e); } }
          // fetch the route when Earth's GPS has a new one
          if (d.gps && d.gps.version !== gm.routeVersion() && d.gps.version !== gmRouteAsked) {
            gmRouteAsked = d.gps.version;
            bngApi.engineLua('earthCareer_map.route(' + gm.routeVersion() + ')', function (r) {
              if (r && r.points && gm) { gm.setRoute(r); }
            });
          }
          if (!d.gps) { gmRouteAsked = null; }
          // discovered towns: fetch the list when it changed
          if (d.discVersion && d.discVersion !== gmDiscVersion) {
            gmDiscVersion = d.discVersion;
            bngApi.engineLua('earthCareer_discovery.points(-1)', function (r) {
              if (r && gm) { gm.setDiscovered(arr(r.pts)); }
            });
          }
        });
      }

      scope.gmZoom = function (dz) { if (gm) { gm.zoomBy(dz); } };
      scope.gmFollowMe = function () { scope.gmFollow = true; if (gm) { gm.setFollow(true); } };
      var LAYERS = ['map', 'sat', 'dark'], LAYER_NAMES = { map: 'MAP', sat: 'SAT', dark: 'DARK' };
      scope.gmLayer = 'map';
      try { var saved = localStorage.getItem('earthCareer.mapLayer'); if (LAYERS.indexOf(saved) >= 0) { scope.gmLayer = saved; } } catch (e) {}
      scope.gmLayerName = function () { return LAYER_NAMES[scope.gmLayer]; };
      scope.gmCycleLayer = function () {
        scope.gmLayer = LAYERS[(LAYERS.indexOf(scope.gmLayer) + 1) % LAYERS.length];
        try { localStorage.setItem('earthCareer.mapLayer', scope.gmLayer); } catch (e) {}
        if (gm) { gm.setLayer(scope.gmLayer); }
      };
      scope.gmToggleFull = function () { scope.gmFull = !scope.gmFull; setTimeout(function () { if (gm) { gm.resize(); } }, 60); };
      scope.gmCredit = function () {
        var osm = '© OpenStreetMap contributors';
        if (scope.gmLayer === 'sat') { return 'Imagery: EOX Sentinel-2 cloudless & others via BeamNG.Earth · Labels: EOX, ' + osm; }
        return 'Map: EOX Terrain Light & Overlay (maps.eox.at), ' + osm;
      };
      scope.gmGoHome = function () { var h = scope.state && scope.state.homeTown; if (gm && h) { gm.centre(h.lat, h.lon, 13); } };
      scope.gmShowJob = function () {
        var j = scope.gmData && scope.gmData.job; if (!gm || !j) { return; }
        var pts = [scope.gmData.player, j.from, j.to].concat(arr(j.stops));
        gm.fit(pts);
      };
      scope.gmOverview = function () {
        var d = scope.gmData; if (!gm || !d || !d.gps) { return; }
        gm.fit([d.player, { lat: d.gps.lat, lon: d.gps.lon }]);
      };
      scope.gmDropPin = function () { scope.gmPin = null; if (gm) { gm.setPin(null); } };
      scope.gmNavigate = function () {
        var p = scope.gmPin; if (!p) { return; }
        luaCb('earthCareer_map.navigate(' + p.lat + ',' + p.lon + ',' + JSON.stringify(String(p.name).replace(/[\u0000-\u001f]/g, '')) + ')', function () {});
        scope.gmDropPin();
        scope.gmFollowMe();
      };
      scope.gmClear = function () { luaCb('earthCareer_map.clearNav()', function () {}); };
      scope.gmPinMiles = function () {
        var p = scope.gmPin, me = scope.gmData && scope.gmData.player;
        if (!p || !me) { return null; }
        var r = Math.PI / 180, dLat = (p.lat - me.lat) * r, dLon = (p.lon - me.lon) * r;
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(me.lat * r) * Math.cos(p.lat * r) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var mi = 2 * 3958.8 * Math.asin(Math.min(1, Math.sqrt(a)));
        return mi < 10 ? mi.toFixed(1) : Math.round(mi).toLocaleString('en-US');
      };

      // search through BeamNG.Earth's geocoder
      scope.gmSearch = function () {
        var q = (scope.gmQ.text || '').replace(/[\u0000-\u001f]/g, '').trim();
        if (q.length < 3) { scope.gmSearchMsg = 'Type at least 3 letters.'; return; }
        scope.gmResults = []; scope.gmSearchMsg = 'Searching…';
        if (gmSearchTimer) { clearTimeout(gmSearchTimer); gmSearchTimer = null; }
        var mySearch = ++gmSearchSeq;
        var isGas = /^gas( station)?$|^fuel$/i.test(q);
        var offline = [];
        function show(online, failed) {
          if (mySearch !== gmSearchSeq) { return; }
          // online results first (nearest first), then offline ones not already listed
          var list = arr(online).slice().sort(function (x, y) { return (scope.gmMilesTo(x) || 0) - (scope.gmMilesTo(y) || 0); });
          offline.forEach(function (o) {
            var dup = list.some(function (x) { return Math.abs(x.lat - o.lat) < 0.01 && Math.abs(x.lon - o.lon) < 0.01; });
            if (!dup) { list.push(o); }
          });
          scope.gmResults = list;
          if (failed) {
            scope.gmSearchMsg = list.length
              ? 'Address & business search is down on BeamNG.Earth\'s side right now: showing ' + (isGas ? 'gas stations loaded nearby and towns.' : 'towns only.')
              : 'BeamNG.Earth\'s online search is down right now (' + failed + '). Town names still work, or drop a pin on the map.';
          } else {
            scope.gmSearchMsg = list.length ? '' : 'Nothing found.';
          }
        }
        // offline first: towns (and loaded gas stations for "gas"), instantly
        luaCb('earthCareer_map.searchLocal(' + JSON.stringify(q) + ')', function (loc) {
          offline = arr(loc && loc.results);
          var then = function () {
            if (mySearch !== gmSearchSeq) { return; }
            if (offline.length) { scope.gmResults = offline.slice(); scope.gmSearchMsg = 'Searching online too…'; }
            luaCb('earthCareer_map.search(' + JSON.stringify(q) + ')', function (r) {
              if (!r || r.error) { show([], (r && r.error) || 'not connected'); return; }
              var tries = 0;
              (function waitResult() {
                luaCb('earthCareer_map.searchResult(' + Number(r.id) + ')', function (res) {
                  if (mySearch !== gmSearchSeq) { return; }
                  if (res && res.pending && tries++ < 40) { gmSearchTimer = setTimeout(waitResult, 300); return; }
                  if (!res || res.pending) { show([], 'no answer'); return; }
                  if (res.error) {
                    var e = String(res.error);
                    show([], /403/.test(e) ? 'the search service refused it, HTTP 403' : e.slice(0, 60));
                    return;
                  }
                  show(res.results, null);
                });
              })();
            });
          };
          if (isGas) {
            luaCb('earthCareer_map.nearbyGas()', function (g) { offline = arr(g && g.results).concat(offline); then(); });
          } else { then(); }
        });
      };
      // trip stops
      scope.gmNearby = [
        { icon: '🅿', label: 'Rest areas', q: 'rest area' },
        { icon: '⛽', label: 'Gas', q: 'gas station' },
        { icon: '🍔', label: 'Food', q: 'restaurant' },
        { icon: '🚚', label: 'Truck stops', q: 'truck stop' }
      ];
      scope.gmStopMode = false;
      scope.gmStartStopSearch = function () {
        scope.gmStopMode = !scope.gmStopMode;
        scope.gmSearchOpen = scope.gmStopMode || false;
        scope.gmResults = []; scope.gmSearchMsg = ''; scope.gmQ.text = '';
        if (scope.gmStopMode) { scope.gmDropPin(); }
      };
      scope.gmCancelStopMode = function () { scope.gmStopMode = false; scope.gmSearchOpen = false; scope.gmClearSearch(); };
      scope.gmFindNearby = function (c) { scope.gmQ.text = c.q; scope.gmSearch(); };
      scope.gmAddStop = function () {
        var p = scope.gmPin; if (!p) { return; }
        luaCb('earthCareer_map.addStop(' + p.lat + ',' + p.lon + ',' + JSON.stringify(String(p.name).replace(/[\u0000-\u001f]/g, '').slice(0, 80)) + ')', function () {});
        scope.gmDropPin();
      };
      scope.gmRemoveStop = function (i) { luaCb('earthCareer_map.removeStop(' + Number(i) + ')', function () {}); };
      scope.gmClearStops = function () { luaCb('earthCareer_map.clearStops()', function () {}); };
      scope.gmMilesTo = function (r) {
        var me = scope.gmData && scope.gmData.player;
        if (!me || !r) { return null; }
        var rad = Math.PI / 180, dLat = (r.lat - me.lat) * rad, dLon = (r.lon - me.lon) * rad;
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(me.lat * rad) * Math.cos(r.lat * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var mi = 2 * 3958.8 * Math.asin(Math.min(1, Math.sqrt(a)));
        return mi < 10 ? mi.toFixed(1) : Math.round(mi);
      };
      scope.gmClearSearch = function () { gmSearchSeq++; scope.gmQ.text = ''; scope.gmResults = []; scope.gmSearchMsg = ''; };
      scope.gmPickResult = function (r) {
        gmSearchSeq++; scope.gmResults = []; scope.gmSearchMsg = '';
        if (scope.gmStopMode) {
          // straight onto the trip
          var nm = (r.name + (r.detail ? ', ' + r.detail : '')).replace(/[\u0000-\u001f]/g, '').slice(0, 80);
          luaCb('earthCareer_map.addStop(' + r.lat + ',' + r.lon + ',' + JSON.stringify(nm) + ')', function () {});
          scope.gmStopMode = false; scope.gmSearchOpen = false; scope.gmQ.text = '';
          return;
        }
        scope.gmPin = { lat: r.lat, lon: r.lon, name: r.name + (r.detail ? ', ' + r.detail : '') };
        if (gm) { gm.setPin(scope.gmPin); gm.centre(r.lat, r.lon, 15); }
      };

      // ---- turn-by-turn ----
      var NAV_PATHS = {
        straight:   'M12 20V5 M7 10l5-5 5 5',
        slight:     'M8 20v-7l8-8 M10 5h6v6',
        turn:       'M7 20v-8a4 4 0 0 1 4-4h8 M15 4l4 4-4 4',
        sharp:      'M8 20V6 M8 6l9 12 M11 18h6v-6',
        uturn:      'M8 20V9a4 4 0 0 1 8 0v8 M12 13l4 4 4-4',
        roundabout: 'M12 21v-5 M12 16a3.5 3.5 0 1 0 0-7a3.5 3.5 0 0 0 0 7 M14.5 9.5L19 5 M15 5h4v4',
        arrive:     'M7 21V4 M7 4h10l-2 4 2 4H7'
      };
      scope.gmSearchOpen = false;
      scope.gmToggleSearch = function () { scope.gmSearchOpen = !scope.gmSearchOpen; if (!scope.gmSearchOpen) { scope.gmStopMode = false; } };
      scope.navPath = function (n) { return NAV_PATHS[(n && n.kind) || 'straight'] || NAV_PATHS.straight; };
      scope.navFlip = function (n) {
        if (!n || n.kind === 'arrive') { return ''; }
        if (n.kind === 'uturn') { return n.dir === 'right' ? '' : 'translate(24,0) scale(-1,1)'; }
        return n.dir === 'left' ? 'translate(24,0) scale(-1,1)' : '';
      };
      scope.navText = function (n) {
        if (!n) { return ''; }
        var d = n.dir === 'left' ? 'left' : 'right';
        switch (n.kind) {
          case 'slight': return 'Slight ' + d;
          case 'turn': return 'Turn ' + d;
          case 'sharp': return 'Sharp ' + d;
          case 'uturn': return 'Make a U-turn';
          case 'roundabout': return 'At the roundabout, ' + (Math.abs(n.deg || 0) < 30 ? 'go straight' : 'exit ' + d);
          case 'arrive': return 'Arrive' + (n.toward ? ' at ' + n.toward : '');
          default: return 'Continue';
        }
      };
      // "Interstate 69" -> "I-69", "US Highway 12" -> "US-12" (other names as they are)
      scope.roadName = function (s) {
        if (!s) { return ''; }
        s = String(s);
        var m = s.match(/^Interstate\s+(?:Highway\s+)?(\d+[A-Z]?)\b(.*)$/i);
        if (m) { return 'I-' + m[1] + m[2]; }
        m = s.match(/^I\s+(\d+[A-Z]?)\b(.*)$/);
        if (m) { return 'I-' + m[1] + m[2]; }
        m = s.match(/^U\.?\s?S\.?\s+(?:Highway|Hwy|Route|Rte)\s+(\d+[A-Z]?)\b(.*)$/i);
        if (m) { return 'US-' + m[1] + m[2]; }
        m = s.match(/^US\s+(\d+[A-Z]?)\b(.*)$/);
        if (m) { return 'US-' + m[1] + m[2]; }
        return s;
      };
      // what the banner says: a long stretch is "Continue on I-69", a near turn is the turn itself
      var CONTINUE_M = 1609;
      scope.navView = function (n) {
        if (!n) { return null; }
        var road = scope.roadName(n.street);
        if (n.kind !== 'arrive' || n.distM > CONTINUE_M) {
          if (n.distM > CONTINUE_M) {
            return { icon: { kind: 'straight' }, dist: scope.navDist(n.distM),
                     text: road ? 'Continue on ' + road : 'Continue straight',
                     sub: 'then ' + scope.navText(n).replace(/^Arrive/, 'arrive'), long: true };
          }
        }
        return { icon: n, dist: scope.navDist(n.distM), text: scope.navText(n),
                 sub: road ? 'on ' + road : (n.toward ? 'toward ' + n.toward : ''), long: false };
      };
      // arrival time on this computer's clock (weekday added if it's not today)
      scope.arrivalTime = function (etaMin) {
        if (etaMin === null || etaMin === undefined) { return ''; }
        var at = new Date(Date.now() + etaMin * 60000), now = new Date();
        var t = at.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        if (at.toDateString() !== now.toDateString()) { t = at.toLocaleDateString('en-US', { weekday: 'short' }) + ' ' + t; }
        return t;
      };
      scope.navDist = function (m) {
        m = Number(m || 0);
        if (m < 161) { return Math.max(50, Math.round(m * 3.28084 / 50) * 50) + ' ft'; }
        var mi = m / 1609.34;
        return (mi < 10 ? mi.toFixed(1) : Math.round(mi)) + ' mi';
      };

      // ---- stats tab ----
      var ABBR = { AL: 'Alabama', AK: 'Alaska', AZ: 'Arizona', AR: 'Arkansas', CA: 'California', CO: 'Colorado', CT: 'Connecticut',
        DE: 'Delaware', DC: 'District of Columbia', FL: 'Florida', GA: 'Georgia', HI: 'Hawaii', ID: 'Idaho', IL: 'Illinois',
        IN: 'Indiana', IA: 'Iowa', KS: 'Kansas', KY: 'Kentucky', LA: 'Louisiana', ME: 'Maine', MD: 'Maryland', MA: 'Massachusetts',
        MI: 'Michigan', MN: 'Minnesota', MS: 'Mississippi', MO: 'Missouri', MT: 'Montana', NE: 'Nebraska', NV: 'Nevada',
        NH: 'New Hampshire', NJ: 'New Jersey', NM: 'New Mexico', NY: 'New York', NC: 'North Carolina', ND: 'North Dakota',
        OH: 'Ohio', OK: 'Oklahoma', OR: 'Oregon', PA: 'Pennsylvania', RI: 'Rhode Island', SC: 'South Carolina', SD: 'South Dakota',
        TN: 'Tennessee', TX: 'Texas', UT: 'Utah', VT: 'Vermont', VA: 'Virginia', WA: 'Washington', WV: 'West Virginia',
        WI: 'Wisconsin', WY: 'Wyoming' };
      scope.Math = Math;
      scope.stateShapes = [];
      var shapeTries = 0;
      function buildStateShapes() {
        var s = window.EarthCareerStateShapes;
        if (!s) { if (shapeTries++ < 60) { setTimeout(buildStateShapes, 300); } return; }
        scope.$evalAsync(function () {
          scope.stateShapes = Object.keys(s).filter(function (n) { return n !== 'Alaska' && n !== 'Hawaii'; })
            .map(function (n) { return { name: n, d: s[n] }; });
        });
      }
      buildStateShapes();
      function homeState() {
        var h = scope.state && scope.state.homeTown;
        if (!h) { return null; }
        var m = String(h.name).match(/,\s*([A-Z]{2})\b/);
        if (m && ABBR[m[1]]) { return ABBR[m[1]]; }
        // "Marshall Township, Michigan"
        var names = Object.keys(ABBR).map(function (k) { return ABBR[k]; });
        for (var i = 0; i < names.length; i++) { if (String(h.name).indexOf(names[i]) >= 0) { return names[i]; } }
        return null;
      }
      scope.stateClass = function (name) {
        if (name === homeState()) { return 'home'; }
        var list = arr(scope.state && scope.state.statesList);
        for (var i = 0; i < list.length; i++) { if (list[i].name === name) { return 'visited'; } }
        return '';
      };
      scope.achGroups = ['All', 'Distance', 'Jobs', 'States', 'Landmarks', 'Career'];
      scope.achGroup = 'All';
      scope.setAchGroup = function (g) { scope.achGroup = g; };
      scope.achList = function () {
        var list = arr(scope.state && scope.state.achievements && scope.state.achievements.list);
        return scope.achGroup === 'All' ? list : list.filter(function (a) { return a.group === scope.achGroup; });
      };
      scope.catStat = function (id) {
        var st = scope.state && scope.state.jobs && scope.state.jobs.stats;
        return (st && st[id]) || { jobs: 0, miles: 0, earned: 0 };
      };
      scope.totalEarned = function () {
        var st = (scope.state && scope.state.jobs && scope.state.jobs.stats) || {}, t = 0;
        Object.keys(st).forEach(function (k) { t += Number(st[k].earned || 0); });
        return t;
      };

      // ---- formatting ----
      scope.money = function (n) { return '$' + Math.round(Number(n || 0)).toLocaleString('en-US'); };
      scope.dist = function (km) {
        var v = (km || 0) * 0.621371;
        return v.toFixed(v < 10 ? 2 : 1);
      };
      scope.miles = function (km) { return Math.round((km || 0) * 0.621371).toLocaleString('en-US'); };
      scope.commas = function (n) { return Math.round(Number(n || 0)).toLocaleString('en-US'); };
      scope.pct = function (r) { return Math.max(0, Math.min(100, Math.round((r || 0) * 100))); };
      scope.num1 = function (n) { return Number(n || 0).toFixed(1); };
      scope.abs = function (n) { return Math.abs(Number(n || 0)); };
      scope.hm = function (sec) {
        sec = Math.max(0, Math.round(sec || 0));
        var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
        return h > 0 ? h + 'h ' + (m < 10 ? '0' : '') + m + 'm' : m + ' min';
      };
      scope.xpPct = function () {
        if (!scope.state || !scope.state.xpNext) return 0;
        return Math.min(100, Math.round(scope.state.xp / scope.state.xpNext * 100));
      };
      scope.clock = function (s) {
        s = Math.floor(s || 0);
        var m = Math.floor(s / 60), r = s % 60;
        return m + ':' + (r < 10 ? '0' : '') + r;
      };
      // green / yellow / red for bars
      scope.level3 = function (r) { return r > 0.5 ? 'good' : (r > 0.2 ? 'warn' : 'bad'); };

      scope.$on('$destroy', function () { scope.typing(false); gmStop(); if (gm) { gm.destroy(); } });

      lua('requestState()');
    }
  };
}]);
