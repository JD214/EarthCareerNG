// Earth Career - the Map tab's map: Web Mercator tiles from BeamNG.Earth's companion server
// (files in /temp/beamngEarth/maptiles/, asked for through earthCareer_map.tiles), with a canvas
// overlay for the GPS route, markers and your car. Plain ES5 so it runs in BeamNG's UI.
(function () {
  var TILE = 256, MIN_Z = 3, MAX_Z = 18;
  var DIR = '/temp/beamngEarth/maptiles/';
  var EXT = { sat: 'jpg', map: 'jpg', labels: 'png' };
  var CAT = { cars: '#2f81f7', hotshot: '#f2a900', freight: '#e5534b', bus: '#57d68d' };

  // Lua sends an empty table as {} (not []): treat anything that isn't an array as empty
  function arr(x) { return Array.isArray(x) ? x : []; }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function worldSize(z) { return TILE * Math.pow(2, z); }
  function project(lat, lon, z) {
    var s = worldSize(z);
    var sin = Math.sin(clamp(lat, -85.05, 85.05) * Math.PI / 180);
    return { x: (lon + 180) / 360 * s, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s };
  }
  function unproject(x, y, z) {
    var s = worldSize(z);
    var lon = x / s * 360 - 180;
    var n = Math.PI - 2 * Math.PI * y / s;
    return { lat: 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lon: lon };
  }
  function tilePath(layer, z, x, y) {
    return layer === 'sat' ? DIR + z + '/' + x + '/' + y + '.jpg' : DIR + layer + '/' + z + '/' + x + '/' + y + '.' + EXT[layer];
  }

  window.EarthCareerMap = function (root, opts) {
    var tilesEl = root.querySelector('.ecm-tiles');
    var canvas = root.querySelector('.ecm-canvas');
    var view = { lat: 39.5, lon: -96, z: 5 };
    var follow = true, centredOnce = false;
    var layer = 'map';
    var ready = {};            // "layer/z/x/y" -> true
    var imgs = {};             // key -> <img>
    var data = {};             // last poll
    var route = null;          // { version, points: [[lat, lon]...] }
    var pin = null;            // { lat, lon }
    var discovered = [];       // [[lat, lon, size, name], ...]
    var lastAsk = 0, missingCount = 0, asking = false;
    var dead = false;

    function size() { return { w: root.clientWidth || 300, h: root.clientHeight || 300 }; }
    function baseLayer() { return layer === 'dark' ? 'map' : layer; }

    // ---- which tiles we need ----
    function wantedTiles() {
      var sz = size(), z = view.z, n = Math.pow(2, z);
      var c = project(view.lat, view.lon, z);
      var x0 = Math.floor((c.x - sz.w / 2) / TILE), x1 = Math.floor((c.x + sz.w / 2) / TILE);
      var y0 = Math.max(0, Math.floor((c.y - sz.h / 2) / TILE)), y1 = Math.min(n - 1, Math.floor((c.y + sz.h / 2) / TILE));
      var out = [];
      for (var y = y0; y <= y1; y++) {
        for (var x = x0; x <= x1; x++) {
          var cx = x * TILE + TILE / 2 - c.x, cy = y * TILE + TILE / 2 - c.y;
          out.push({ x: x, wx: ((x % n) + n) % n, y: y, z: z, d: cx * cx + cy * cy,
                     left: Math.round(x * TILE - (c.x - sz.w / 2)), top: Math.round(y * TILE - (c.y - sz.h / 2)) });
        }
      }
      out.sort(function (a, b) { return a.d - b.d; });
      return out;
    }

    function askTiles(force) {
      if (asking || dead) { return; }
      var now = Date.now();
      if (!force && now - lastAsk < (missingCount ? 300 : 1500)) { return; }
      lastAsk = now;
      var layers = [baseLayer(), 'labels'];
      var list = [];
      wantedTiles().forEach(function (t) {
        layers.forEach(function (L) {
          if (!ready[L + '/' + t.z + '/' + t.wx + '/' + t.y]) { list.push([t.z, t.wx, t.y, L]); }
        });
      });
      missingCount = list.length;
      if (!list.length) { return; }
      asking = true;
      opts.lua('earthCareer_map.tiles(jsonDecode(' + JSON.stringify(JSON.stringify(list.slice(0, 128))) + '))', function (r) {
        asking = false;
        var changed = false;
        (Array.isArray(r) ? r : []).forEach(function (k) { if (!ready[k]) { ready[k] = true; changed = true; } });
        if (changed) { render(); }
      });
    }

    // ---- tiles in the DOM ----
    function drawTiles() {
      var keep = {};
      var layers = [baseLayer(), 'labels'];
      wantedTiles().forEach(function (t) {
        layers.forEach(function (L, li) {
          var k = L + '/' + t.z + '/' + t.wx + '/' + t.y;
          if (!ready[k]) { return; }
          var domKey = k + '@' + t.x;   // the same tile can show twice across the date line
          keep[domKey] = true;
          var img = imgs[domKey];
          if (!img) {
            img = document.createElement('img');
            img.className = 'ecm-tile' + (li === 0 && layer === 'dark' ? ' dark' : '') + (li === 1 ? ' lbl' : '');
            img.draggable = false;
            img.src = tilePath(L, t.z, t.wx, t.y);
            imgs[domKey] = img;
            tilesEl.appendChild(img);
          }
          img.style.left = t.left + 'px';
          img.style.top = t.top + 'px';
          img.style.zIndex = li + 1;
        });
      });
      Object.keys(imgs).forEach(function (k) {
        if (!keep[k]) { if (imgs[k].parentNode) { imgs[k].parentNode.removeChild(imgs[k]); } delete imgs[k]; }
      });
    }

    // ---- overlay: route, markers, you ----
    function toScreen(lat, lon) {
      var sz = size(), c = project(view.lat, view.lon, view.z), p = project(lat, lon, view.z);
      var ws = worldSize(view.z), dx = p.x - c.x;
      if (dx > ws / 2) { dx -= ws; } else if (dx < -ws / 2) { dx += ws; }
      return { x: sz.w / 2 + dx, y: sz.h / 2 + (p.y - c.y) };
    }

    function drawPin(ctx, s, color, label) {
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(-3, -9, -11, -14, -11, -22);
      ctx.arc(0, -22, 11, Math.PI, 0);
      ctx.bezierCurveTo(11, -14, 3, -9, 0, 0);
      ctx.fillStyle = color; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.stroke();
      ctx.beginPath(); ctx.arc(0, -22, 4, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
      ctx.restore();
      if (label) { text(ctx, label, s.x + 13, s.y - 22); }
    }
    function dot(ctx, s, r, fill, ring) {
      ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, Math.PI * 2); ctx.fillStyle = fill; ctx.fill();
      if (ring) { ctx.lineWidth = 2; ctx.strokeStyle = ring; ctx.stroke(); }
    }
    function text(ctx, t, x, y) {
      ctx.font = '600 11px Segoe UI, Roboto, sans-serif';
      ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.strokeText(t, x, y);
      ctx.fillStyle = '#202124'; ctx.fillText(t, x, y);
    }

    function drawOverlay() {
      var sz = size(), dpr = window.devicePixelRatio || 1;
      if (canvas.width !== Math.round(sz.w * dpr) || canvas.height !== Math.round(sz.h * dpr)) {
        canvas.width = Math.round(sz.w * dpr); canvas.height = Math.round(sz.h * dpr);
      }
      var ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, sz.w, sz.h);

      // discovered towns: green dots, bigger for bigger places; names when zoomed in
      if (discovered.length) {
        var sz = size();
        discovered.forEach(function (t) {
          var p = toScreen(t[0], t[1]);
          if (p.x < -20 || p.y < -20 || p.x > sz.w + 20 || p.y > sz.h + 20) { return; }
          var r = [2.5, 3.5, 4.5, 5.5][t[2] || 0] + (view.z >= 11 ? 1 : 0);
          ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(30,142,62,.85)'; ctx.fill();
          ctx.lineWidth = 1.2; ctx.strokeStyle = '#fff'; ctx.stroke();
          if (view.z >= 11 || (t[2] >= 2 && view.z >= 8)) {
            ctx.font = '600 10px Segoe UI, Roboto, sans-serif';
            ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.strokeText(t[3], p.x + r + 3, p.y + 3.5);
            ctx.fillStyle = '#137333'; ctx.fillText(t[3], p.x + r + 3, p.y + 3.5);
          }
        });
      }

      // the GPS route: Google-ish blue with a dark edge
      if (route && arr(route.points).length > 1 && data.gps) {
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        [[8, '#1a4fa3'], [5, '#4b8ef5']].forEach(function (st) {
          ctx.beginPath();
          route.points.forEach(function (p, i) {
            var s = toScreen(p[0], p[1]);
            if (i === 0) { ctx.moveTo(s.x, s.y); } else { ctx.lineTo(s.x, s.y); }
          });
          ctx.lineWidth = st[0]; ctx.strokeStyle = st[1]; ctx.stroke();
        });
      } else if (data.gps && data.player && data.gps.lat) {
        // still planning: a dashed straight line
        var a = toScreen(data.player.lat, data.player.lon), b = toScreen(data.gps.lat, data.gps.lon);
        ctx.setLineDash([6, 6]); ctx.lineWidth = 3; ctx.strokeStyle = '#4b8ef5';
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
      }

      // the job: stops / pickup / drop
      var j = data.job;
      if (j) {
        var col = CAT[j.cat] || '#8b949e';
        if (arr(j.stops).length) {
          arr(j.stops).forEach(function (st, i) {
            var s = toScreen(st.lat, st.lon);
            dot(ctx, s, 7, i + 1 < (j.stopIndex || 1) ? '#9aa0a6' : col, '#fff');
            ctx.fillStyle = '#fff'; ctx.font = '700 9px sans-serif'; ctx.textAlign = 'center';
            ctx.fillText(String(i + 1), s.x, s.y + 3); ctx.textAlign = 'left';
          });
        } else {
          if (j.stage === 'pickup' && j.from) { dot(ctx, toScreen(j.from.lat, j.from.lon), 7, col, '#fff'); text(ctx, 'Pickup: ' + j.from.name, toScreen(j.from.lat, j.from.lon).x + 10, toScreen(j.from.lat, j.from.lon).y + 4); }
          if (j.to) { var ts = toScreen(j.to.lat, j.to.lon); dot(ctx, ts, 8, col, '#fff'); text(ctx, 'Drop: ' + j.to.name, ts.x + 11, ts.y + 4); }
        }
      }

      // trip stops: numbered orange markers
      if (data.trip && arr(data.trip.stops).length) {
        arr(data.trip.stops).forEach(function (st, i) {
          var ss = toScreen(st.lat, st.lon);
          dot(ctx, ss, 9, '#f57c00', '#fff');
          ctx.fillStyle = '#fff'; ctx.font = '700 10px sans-serif'; ctx.textAlign = 'center';
          ctx.fillText(String(i + 1), ss.x, ss.y + 3.5); ctx.textAlign = 'left';
          if (i === 0) { text(ctx, st.name, ss.x + 12, ss.y + 4); }
        });
      }

      // home
      if (data.home) {
        var h = toScreen(data.home.lat, data.home.lon);
        dot(ctx, h, 9, '#f2a900', '#fff');
        ctx.fillStyle = '#111'; ctx.font = '700 12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('⌂', h.x, h.y + 4); ctx.textAlign = 'left';
      }

      // GPS destination (when it isn't the job's drop)
      if (data.gps && data.gps.lat && (data.freeNav || !j)) {
        drawPin(ctx, toScreen(data.gps.lat, data.gps.lon), '#ea4335', data.gps.name || null);
      }
      // a dropped pin
      if (pin) { drawPin(ctx, toScreen(pin.lat, pin.lon), '#d93025', null); }

      // you: blue dot with a heading cone
      if (data.player) {
        var me = toScreen(data.player.lat, data.player.lon);
        if (typeof data.player.heading === 'number') {
          var hd = (data.player.heading - 90) * Math.PI / 180;
          ctx.beginPath(); ctx.moveTo(me.x, me.y);
          ctx.arc(me.x, me.y, 26, hd - 0.45, hd + 0.45); ctx.closePath();
          var g = ctx.createRadialGradient(me.x, me.y, 4, me.x, me.y, 26);
          g.addColorStop(0, 'rgba(66,133,244,.55)'); g.addColorStop(1, 'rgba(66,133,244,0)');
          ctx.fillStyle = g; ctx.fill();
        }
        dot(ctx, me, 11, 'rgba(66,133,244,.18)');
        dot(ctx, me, 7, '#4285f4', '#fff');
      }
    }

    function render() {
      if (dead) { return; }
      try { drawTiles(); } catch (e) { if (window.console) { console.error('EarthCareer map tiles', e); } }
      try { drawOverlay(); } catch (e) { if (window.console) { console.error('EarthCareer map overlay', e); } }
      askTiles(false);
    }

    // ---- input: drag, wheel, double-click, click ----
    var drag = null;
    function onDown(e) {
      if (e.button !== undefined && e.button !== 0) { return; }
      var c = project(view.lat, view.lon, view.z);
      drag = { x: e.clientX, y: e.clientY, cx: c.x, cy: c.y, moved: false };
    }
    function onMove(e) {
      if (!drag) { return; }
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 4) {
        drag.moved = true;
        if (follow) { follow = false; if (opts.onFollow) { opts.onFollow(false); } }
      }
      if (!drag.moved) { return; }
      var ll = unproject(drag.cx - dx, clamp(drag.cy - dy, 0, worldSize(view.z)), view.z);
      view.lat = ll.lat; view.lon = ((ll.lon + 540) % 360) - 180;
      render();
    }
    function onUp(e) {
      if (!drag) { return; }
      var click = !drag.moved;
      drag = null;
      if (click && opts.onPick) {
        var r = root.getBoundingClientRect();
        var ll = screenToLatLon(e.clientX - r.left, e.clientY - r.top);
        opts.onPick(ll.lat, ll.lon);
      }
    }
    function screenToLatLon(sx, sy) {
      var sz = size(), c = project(view.lat, view.lon, view.z);
      var ll = unproject(c.x + sx - sz.w / 2, c.y + sy - sz.h / 2, view.z);
      ll.lon = ((ll.lon + 540) % 360) - 180;
      return ll;
    }
    function zoomAt(dz, sx, sy) {
      var nz = clamp(view.z + dz, MIN_Z, MAX_Z);
      if (nz === view.z) { return; }
      var sz = size();
      if (sx === undefined || follow) { sx = sz.w / 2; sy = sz.h / 2; }
      var at = screenToLatLon(sx, sy);
      view.z = nz;
      // keep the point under the cursor where it was
      var p = project(at.lat, at.lon, nz);
      var ll = unproject(p.x - (sx - sz.w / 2), p.y - (sy - sz.h / 2), nz);
      view.lat = ll.lat; view.lon = ((ll.lon + 540) % 360) - 180;
      lastAsk = 0;
      render();
    }
    function onWheel(e) {
      e.preventDefault();
      var r = root.getBoundingClientRect();
      zoomAt(e.deltaY < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top);
    }
    function onDbl(e) {
      var r = root.getBoundingClientRect();
      zoomAt(1, e.clientX - r.left, e.clientY - r.top);
    }
    root.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    root.addEventListener('wheel', onWheel, { passive: false });
    root.addEventListener('dblclick', onDbl);

    // ---- public ----
    return {
      update: function (d) {
        data = d || {};
        if (data.player && (follow || !centredOnce)) {
          view.lat = data.player.lat; view.lon = data.player.lon;
          if (!centredOnce) { view.z = 14; centredOnce = true; lastAsk = 0; }
        }
        if (!data.gps) { route = null; }
        render();
      },
      routeVersion: function () { return route ? route.version : -1; },
      setRoute: function (r) { if (r && arr(r.points).length) { route = r; render(); } },
      setPin: function (p) { pin = p; render(); },
      setDiscovered: function (pts) { discovered = arr(pts); render(); },
      setLayer: function (L) {
        layer = L;
        Object.keys(imgs).forEach(function (k) { if (imgs[k].parentNode) { imgs[k].parentNode.removeChild(imgs[k]); } });
        imgs = {}; lastAsk = 0; render();
      },
      layer: function () { return layer; },
      zoomBy: function (dz) { zoomAt(dz); },
      setFollow: function (on) { follow = on; if (on && data.player) { view.lat = data.player.lat; view.lon = data.player.lon; render(); } },
      following: function () { return follow; },
      centre: function (lat, lon, z) {
        follow = false; if (opts.onFollow) { opts.onFollow(false); }
        view.lat = lat; view.lon = lon; if (z) { view.z = clamp(z, MIN_Z, MAX_Z); }
        lastAsk = 0; render();
      },
      fit: function (pts) {
        pts = (pts || []).filter(function (p) { return p && typeof p.lat === 'number'; });
        if (!pts.length) { return; }
        follow = false; if (opts.onFollow) { opts.onFollow(false); }
        var minLat = 90, maxLat = -90, minLon = 180, maxLon = -180;
        pts.forEach(function (p) { minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat); minLon = Math.min(minLon, p.lon); maxLon = Math.max(maxLon, p.lon); });
        var sz = size(), z = MAX_Z;
        while (z > MIN_Z) {
          var a = project(maxLat, minLon, z), b = project(minLat, maxLon, z);
          if (b.x - a.x < sz.w * 0.8 && b.y - a.y < sz.h * 0.75) { break; }
          z--;
        }
        var c = unproject((project(maxLat, minLon, z).x + project(minLat, maxLon, z).x) / 2,
                          (project(maxLat, minLon, z).y + project(minLat, maxLon, z).y) / 2, z);
        view.lat = c.lat; view.lon = c.lon; view.z = Math.min(z, 16); lastAsk = 0; render();
      },
      view: function () { return { lat: view.lat, lon: view.lon, z: view.z }; },
      tilesMissing: function () { return missingCount; },
      resize: function () { lastAsk = 0; render(); },
      destroy: function () {
        dead = true;
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      },
      _math: { project: project, unproject: unproject, tilePath: tilePath }
    };
  };
})();
