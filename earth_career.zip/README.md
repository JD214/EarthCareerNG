# Earth Career (v1.1.5)

A freeroam career layer for BeamNG.drive, built for **BeamNG.Earth** (real-world 1:1 map). No vanilla career mode involved.

## Install
1. Drop `earth_career.zip` in your mods folder: `%LOCALAPPDATA%\BeamNG.drive\<version>\mods\` (leave it zipped).
2. Load the BeamNG.Earth map in **Freeroam**.
3. Escape menu → **UI Apps** → **Add app** → **Earth Career**.

## How it plays
- **Profiles:** every time the mod loads it asks which profile to play (*Continue as …* for the last one). Each profile is a separate career (money, cars, home town, states…). Create, load, rename, delete (a copy goes to `profiles/deleted/`). Settings → *Save & switch profile*. Saves live in `settings/earthCareer/profiles/` (the pre-profiles `save.json` was moved into the first profile and kept as a backup).
- **Setup:** teleport to your town with Earth's map (M). The setup screen suggests the town name; hit *Start my career here*. You get a $500 start and a beat-up Soliad Wendover. Right after, a tip pops up showing how to fit the radiator it's missing (Garage → Parts & tuning → Open parts shop → Radiator → pay the bill); it closes on its own once one is paid for.
- **Home:** money, level/XP, home town, car status, stats, Save, Exit career.
- **Hide / show:** *Hide ▾* (top right) shrinks the panel to a small pill with your money, level and job/repair icons; click the pill to bring it back. Pop-ups (crash, teleport, bills) and the turn-by-turn strip still show while it's hidden. Remembered between sessions.
- **Jobs (Freight Market):** a US map with every job drawn pickup → destination. Filter by category, sort by pay, $/mi or distance, tap a job (or a pin) for details, then accept.
  - **Tiers:** Local 0–75 mi · Regional 75–250 mi (Lv 5) · Long Haul 250+ mi, coast to coast (Lv 12).
  - **Cars:** dealer-to-dealer car transfers (car provided, pick any), courier/parcel runs in every tier incl. Long Haul (needs cargo-box parts on the vehicle), rideshare (rated on smooth driving → tips).
  - **HotShot Trucking** (bed loads need cargo boxes; a trailer replaces them): a pickup/truck bed = partial load at ~65% pay; any vehicle (even a car) with a trailer hitched = full load at ~125%. Rate locks in when you load; trailer loads must be hitched to deliver.
  - **Freight:** needs a semi with a trailer hitched (own, or rent just a trailer for ~8% of the pay, or rent the whole rig).
  - **Bus:** city routes (real stops around a nearby city, or a loop on local roads), commuter express (several towns), intercity coach, dealer bus transfers (pick any bus config, free).
  - **🔥 Hot jobs:** 2 towns at a time have a demand surge (25–60 min): every one boosts pay *and* XP (pay-heavy: +50–100% pay and 1.25–1.5× XP; XP-heavy: +25–50% pay and 1.75–2.5× XP; rare jackpot: 2× both). Rarely (~15% per refresh) a town within 30 mi heats up too. Hot jobs (cars, HotShot, freight, car transfers) have the boost baked in.
  - **Custom dispatch (Lv 15):** Jobs → 🎧 Dispatch. Book your own load: type (car, HotShot, freight, coach, bus transfer), cargo (or a preset), weight, urgent/fragile, pickup and drop-off (offline town search, Enter for addresses via Earth). Live quote from the standard rates (±15% by weight); posted loads join the board (max 3).
  - **Rentals:** from Lv 5, rent a semi or bus for a job if you don't own one (fee ≈ 22% of the pay). Your own car comes back afterwards.
  - **Flow:** drive to the pickup town (deadhead is unpaid) → stop there to load → Earth's GPS routes you to the destination → stop within 0.5 mi → Deliver. Buses: stop at each stop in order.
  - **Cargo damage** cuts pay (fragile = all of it); Settings → *Cargo damage* turns it off. **Urgent** jobs have a deadline (late = −25%). Each delivery shows a pay report.
- **Map:** a Google-Maps-style map of the real world (street map, satellite or dark), your car with its heading, home ⌂ and job markers. Drag, scroll to zoom, *follow me*. Search places/addresses (towns are searched offline from the bundled town list, so they always work; addresses and businesses come from BeamNG.Earth's online search when it's up, and the Gas button falls back to Earth's gas stations loaded around you), or click anywhere to drop a pin → *Navigate here*. The route (real roads, via BeamNG.Earth's GPS) is drawn in blue with ETA and miles left. Taking a job routes it automatically; a free route during a job has *Back to job route*. Fullscreen button.
- **Stops:** *+ Add stop* on any pin or search result, or the *Rest areas / Gas / Food / Truck stops* chips under the search bar (results sorted by distance). Stops go before the destination (or the job's next leg); the GPS takes them one at a time and moves on when you get within ~400 ft. Remove stops one by one or clear them. The 📍+ side button opens search in add-a-stop mode (picked results go straight onto the route).
- **State lines:** cross into a new state and a highway-style "WELCOME TO INDIANA · The Crossroads of America" sign pops up (plus a game message). The state comes from your GPS position checked against bundled US Census state outlines (accurate to ~300 m), so it works even when Earth's location bar is blank; the location bar is only a fallback outside the US. A new state must show on two checks in a row so borders don't flicker; lakes and the sea keep the last state. Your first visit to each state gives **+150 XP** (also when you teleport or load into a new one). The **Stats** tab shows states visited (x/50) on a US map (visited green, home gold) with first-visit dates, plus career stats, a per-job-type breakdown, and **25 achievements** (distance, jobs, states, landmarks, career; hidden ones show a hint) that pay cash + XP with a gold pop-up.
- **Town discovery:** drive into a town (small towns within ~1.5 km of the centre, cities 3–6 km) to discover it: 5 XP for a small town up to 10 XP for a big metro. Discovered towns are green dots on the Map; the Stats tab counts them.
- **Speedometer:** Google-style speed bubble (mph) with the road's speed limit sign (from BeamNG.Earth's road graph); turns red at 5+ mph over.
- **Turn-by-turn:** a green banner on the Map tab (and a slim one on every tab) with the next maneuver, the distance to it counting down along the route, "Then…" for close turns, your current road ("Continue on I-69 · 23 mi · then Turn right" on long stretches; Interstate/US highway names shortened to I-69 / US-12), off-route warnings, and the arrival time (this computer's clock) on the route card. Turns are read from the route's shape (Earth's router sends no instructions): bends are grouped and judged by their net change of direction; circling = roundabout. Next-street names need BeamNG.Earth's router to request OSRM steps (`steps=true`).
- **Bank (Home):** loans up to 3,000 + 3,000×level. Daily plan (10 payments, 1.2%/day) or weekly (6 payments, 5%/week), amortized. A career day = 20 min of play with the career running. Missed payments go overdue (+5%) and 30% of job pay is garnished until paid; no new loans while overdue. Pay off early anytime.
- **Rental cars:** *Rent it instead* on the dealer bill (≈0.4% of the car's value per day, first day up front). Return from the Garage; damage charged then. Two missed rental payments = repossessed.
- **Job rentals:** pick the exact semi/bus and trailer from the game's configs; bigger rigs cost more. Stock configs are listed first, then mod vehicles (tagged "Mod"; Settings → *Mod vehicles in rentals* turns them off). Your own saved configs are never used.
- **Garage:** your car (condition, repair bill, fuel, odometer), parts billing, owned cars, **New** cars (vehicle selector, +25% markup) and the **Used lot** (+30% markup, restocks every 3 deliveries).
- **Trailers:** Garage → Trailers → *Browse trailers* (vehicle selector, use *Spawn new*), then buy or remove it. Owned trailers spawn right behind your truck (back up, press L to hitch). The vehicle lock treats trailers as equipment; unowned ones are removed. With the lock on you can still get out and walk (BeamNG's walking mode) and get back in; climbing into a car you don't own puts you back on your feet. Loading and delivering need you back in the vehicle. Rental semis come with a trailer.
- **Fuel:** refuel from the Garage (delivery fee away from home) or pull into one of **BeamNG.Earth's real gas stations** and use the stock refuel prompt: billed at pump price.
- **Crashes:** damage goes on a repair bill: pay it, or file an insurance claim and pay just the deductible. A total loss first asks *I crashed it* or *Map bug*: a map bug (BeamNG.Earth glitch) resets the car in place and wipes that crash (no bill, no claim, no cargo damage). Even a totaled car gets fixed by insurance for the deductible (or sell it for scrap). Resets never clear the bill.
- **Teleport lock:** teleporting with Earth's map (or exiting the career, teleporting and resuming) pops up a choice: teleport back to your home town (free), stay for a visit and keep your base ($150, $300 from level 10; not during a job), or move your home base there ($500, $1,000 from level 10). Jobs wait until you choose. Home tab has *GPS home* (route home on the map) and *Teleport home* (free, not during a job) and *Relocate* for when you've driven to a new town.
- **Settings:** vehicle lock, crash pop-ups, cheap insurance (claims max $25), cargo damage on/off, mod vehicles in rentals, teleport lock, reset career.

## How it talks to BeamNG.Earth
`earth.lua` is the only file that touches Earth, read-only apart from setting the GPS destination:
- position: `beamngEarth_core._state().anchor:enuToGeodetic(x, y, z)` → lat/lon (Earth rebases the world as you drive, so the career stores only lat/lon)
- town name: `package.loaded['beamngEarth/statusbar'].location()`
- routing: `package.loaded['beamngEarth/gps'].setDestination(lat, lon, name)` (server-planned road route, in-game arrows)
- teleport home: `package.loaded['beamngEarth/places'].goTo(lat, lon, name)` (same checks as Earth's Go button)
Same approach as [Earth Enduro](https://github.com/MadMerick01/BeamNG-Earth-Enduro)'s adapter.

## Dev loop
- Console (`~`): `earthCareer_main.debugAddMoney(5000)`, `earthCareer_main.debugAddXp(500)`, `earthCareer_main.resetCareer()` (current profile), `earthCareer_main.switchProfile()`, `earthCareer_jobs.refreshMarket()`
- Ctrl+L reloads Lua, F5 reloads the UI. Logs are tagged `earthCareer`.

## Files
| File | Job |
|---|---|
| `scripts/earth_career/modScript.lua` | Loads the four extensions |
| `lua/ge/extensions/earthCareer/main.lua` | Save, money, XP, home town, settings, UI bridge |
| `lua/ge/extensions/earthCareer/jobs.lua` | Freight Market, categories, active job, buses, rentals |
| `lua/ge/extensions/earthCareer/garage.lua` | Cars, fuel, damage, insurance, dealers, job vehicles |
| `lua/ge/extensions/earthCareer/earth.lua` | BeamNG.Earth adapter + town lookups |
| `lua/ge/extensions/earthCareer/achievements.lua` | The 25 achievements, landmark checks, rewards |
| `lua/ge/extensions/earthCareer/bank.lua` | Loans, rental billing, the career day clock |
| `lua/ge/extensions/earthCareer/discovery.lua` | Town discovery: grid lookup, XP, map dots |
| `lua/ge/extensions/earthCareer/map.lua` | Map tab bridge: Earth's map tiles, GPS route, search |
| `earthCareer/states.json` | US state outlines for state-line detection (US Census, public domain, via BeamNG.Earth) |
| `earthCareer/towns.json` | ~30k US towns (name, state, lat, lon, population for the 1,000 largest) |
| `ui/modules/apps/EarthCareer/*` | HUD panel; `careermap.js` = the Map tab's tile map; `states.js` = US state outlines for the Jobs map |
| `vehicles/wendover/beamngearthcareerstartercar.*` | Starter car |

## Tuning knobs
- `jobs.lua`: `TIERS`, `RATES` (base + per mile per job type), `RENT_LEVEL`, `RENT_SHARE`, `URGENT/FRAGILE/HEAVY_BONUS`, `LATE_PENALTY`, `PER_CATEGORY`, `MARKET_MOVE_MI`
- `garage.lua`: `NEW_MARKUP`, `USED_MARKUP`, `FUEL_PRICE`, `DMG_TO_COST`, `TOTAL_RATIO`, `RECOVERY_FEE`, ...

## Data credits
- Map tiles (through BeamNG.Earth's companion server): EOX IT Services (maps.eox.at) Terrain Light, Overlay and Sentinel-2 cloudless; data © OpenStreetMap contributors and others
- Search: Photon by komoot, © OpenStreetMap contributors; routing: BeamNG.Earth (OSRM on OpenStreetMap)
- US towns: [kelvins/US-Cities-Database](https://github.com/kelvins/US-Cities-Database) (MIT)
- City populations: [plotly/datasets](https://github.com/plotly/datasets) `us-cities-top-1k.csv`
- State-line detection: US Census TIGERweb States 500K (public domain), as simplified by BeamNG.Earth
- State outlines (maps): US Census via [PublicaMundi/MappingAPI](https://github.com/PublicaMundi/MappingAPI)

## Roadmap
1. ~~Jobs, XP, home town, garage, dealers, crashes, Freight Market~~
2. Trailers for hot shot / freight (spawn at pickup, hitch to load)
3. Companies: apply/get hired (trucking firm, car dealer, bus dealer: parts runs, bus transfers)
4. Driver reputation per company, contracts
5. Optional external companion app (second monitor / phone)
